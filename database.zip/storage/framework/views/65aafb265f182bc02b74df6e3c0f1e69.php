
<?php $__env->startSection('title','Class List'); ?>
<?php $__env->startSection('class_list'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<form action="class_list_filter" method="get">
    <select name="field" id="field" onchange="this.form.submit()">
        <option value="all" <?php echo e($select=='all'?'selected':''); ?>>ALL</option>
        <option value="ITM" <?php echo e($select=='ITM'?'selected':''); ?>>ITM</option>
        <option value="BBA" <?php echo e($select=='BBA'?'selected':''); ?>>BBA</option>
        <option value="BCOM" <?php echo e($select=='BCOM'?'selected':''); ?>>BCOM</option>
        <option value="BCA" <?php echo e($select=='BCA'?'selected':''); ?>>BCA</option>
        <option value="MCOM" <?php echo e($select=='MCOM'?'selected':''); ?>>MCOM</option>
    </select>
</form>

<table class="table">
   <tr>
    <th>Class ID</th>
    <th>Stream</th>
    <th>Year</th>
    <th>Semeter Oder</th>
    <th>Division</th>
    <th>Counselor Name</th>
    <th>Last Updated</th>
    <th>Operation</th>
    </tr>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($class->id); ?></td>
        <td><?php echo e($class->stream); ?></td>
        <td><?php echo e($class->year); ?></td>
        <td><?php echo e($class->sem); ?></td>
        <td><?php echo e($class->devision); ?></td>
        <td><?php echo e($class->teacher->name); ?></td>
        <td><?php echo e($class->updated_at); ?></td>
        <td>
        <a href="<?php echo e('edit_class/'.$class->id); ?>"><button type="button" class="btn btn-info">Edit</button></a>
        <a href="<?php echo e('/delete_class/'.$class->id); ?>"><button type="button" class="btn btn-primary">Delete</button></a>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/counselor/class_list.blade.php ENDPATH**/ ?>