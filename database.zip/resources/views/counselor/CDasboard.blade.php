@extends('counselor.layoutcounselor') {{-- Adjusted path assuming 'counselor' is a directory in views --}}

@section('title', 'Counselor Dashboard')
@section('page_title', 'Counselor Dashboard')

@section('content')
<style>
    /* Styles for stat cards, similar to admin dashboard but can be tweaked if needed */
    .stat-card {
        background-color: #ffffff;
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
        display: flex;
        align-items: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        color: #333;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }

    .stat-card .stat-icon {
        font-size: 2.8rem;
        padding: 15px;
        border-radius: 50%;
        margin-right: 20px;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 70px;
        height: 70px;
    }

    .stat-card .stat-info h3 {
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0;
    }

    .stat-card .stat-info p {
        font-size: 0.95rem;
        color: #6c757d;
        margin-bottom: 0;
        text-transform: uppercase;
        font-weight: 500;
    }

    .stat-card.students .stat-icon { background-color: #007bff; }
    .stat-card.students .stat-info h3 { color: #007bff; }

    .stat-card.teachers .stat-icon { background-color: #28a745; }
    .stat-card.teachers .stat-info h3 { color: #28a745; }

    .stat-card.counselors .stat-icon { background-color: #17a2b8; }
    .stat-card.counselors .stat-info h3 { color: #17a2b8; }

    .stat-card.classes .stat-icon { background-color: #ffc107; }
    .stat-card.classes .stat-info h3 { color: #ffc107; }
    .stat-card.classes .stat-icon i { color: #333; }

    /* Card and table styles from admin panel for consistency */
    .card-custom {
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
        border: none;
        background-color: #fff; /* Ensure card background is white */
    }
    .card-custom .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
        font-weight: 600;
        color: #0056b3;
        font-size: 1.1rem;
        padding: 0.75rem 1.25rem;
    }
    .table thead th {
        background-color: #eef2f7;
        color: #495057;
        font-weight: 600;
        border-bottom-width: 1px;
        border-top: none;
    }
    .table tbody tr:hover {
        background-color: #f1f5f9;
    }
    .table td, .table th {
        vertical-align: middle;
    }
</style>

<div class="container-fluid">
    {{-- Top Stat Cards --}}
    <div class="row g-4">
        <div class="col-xl-3 col-md-6">
            <div class="stat-card students">
                <div class="stat-icon"><i class="bi bi-people-fill"></i></div>
                <div class="stat-info">
                    <h3>{{ $students ?? 0 }}</h3> <p>Total Students</p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card teachers">
                <div class="stat-icon"><i class="bi bi-person-video3"></i></div>
                <div class="stat-info">
                    <h3>{{ $teachers ?? 0 }}</h3> <p>Total Teachers</p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card counselors">
                <div class="stat-icon"><i class="bi bi-chat-left-dots-fill"></i></div>
                <div class="stat-info">
                    <h3>{{ $counselors ?? 0 }}</h3> <p>Total Counselors</p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card classes">
                <div class="stat-icon"><i class="bi bi-easel2-fill"></i></div>
                <div class="stat-info">
                    <h3>{{ $classes ?? 0 }}</h3> <p>Total Classes</p>
                </div>
            </div>
        </div>
    </div>

    {{-- Counselor's Assigned Classes --}}
    <div class="row mt-4">
        <div class="col-12">
            <div class="card card-custom">
                <div class="card-header">
                    <i class="bi bi-person-workspace me-2"></i>Your Assigned Classes
                </div>
                <div class="card-body p-0">
                    @php
                        $counselorClassesFound = false;
                    @endphp
                    @if(isset($class_name) && $class_name->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Program</th>
                                    <th>Division</th>
                                    <th>Semester</th>
                                    <th>Batch Year</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($class_name as $class)
                                    @if(isset(Auth::user()->id) && $class->coundelor_id == Auth::user()->id) {{-- Assuming coundelor_id typo is consistent --}}
                                        @php $counselorClassesFound = true; @endphp
                                        <tr>
                                            <td>{{ $class->id }}</td>
                                            <td>{{ $class->program->name ?? 'N/A' }}</td>
                                            <td>{{ $class->devision }}</td>
                                            <td>{{ $class->sem }}</td>
                                            <td>{{ $class->year }}</td>
                                        </tr>
                                    @endif
                                @endforeach
                                @if(!$counselorClassesFound)
                                    <tr>
                                        <td colspan="5" class="text-center text-muted p-3">You are not currently assigned as a counselor to any class.</td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                    @else
                        <div class="text-center p-4">
                            <p class="text-muted mb-0">No class data available.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- Total Lecture of Each Unit --}}
    <div class="row mt-4">
        <div class="col-12">
            <div class="card card-custom">
                <div class="card-header">
                    <i class="bi bi-bar-chart-line-fill me-2"></i>Total Lectures Per Unit (for your subjects)
                </div>
                <div class="card-body p-0">
                     @if(isset($subjects) && $subjects->count() > 0 && isset($units))
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Subject / Class Context</th>
                                    <th>Unit Lecture Counts</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($subjects as $subject_item) {{-- Renamed $subject to $subject_item --}}
                                <tr>
                                    <td>
                                        {{ $subject_item->subject->short_name ?? 'N/A' }} /
                                        {{ $subject_item->subject->student_class->program->name ?? 'N/A' }} /
                                        Sem {{ $subject_item->subject->student_class->sem ?? 'N/A' }} /
                                        Div {{ $subject_item->subject->student_class->devision ?? 'N/A' }}
                                        (Batch: {{ $subject_item->subject->student_class->year ?? 'N/A' }})
                                    </td>
                                    <td>
                                        @php
                                            // This logic is complex for a Blade view and prone to N+1 issues.
                                            // It's highly recommended to pre-calculate this in the controller.
                                            // For now, adapting your existing logic:
                                            $unit_counts = array_fill(1, 6, 0); // [1=>0, 2=>0, ..., 6=>0]
                                            $first_student_id_for_subject = null;

                                            // Find the first student associated with this staff_id (subject assignment)
                                            // This assumption (first student represents all for unit count) might be flawed.
                                            foreach ($units as $unit_entry_check) {
                                                if ($subject_item->id == $unit_entry_check->staff_id) {
                                                    $first_student_id_for_subject = $unit_entry_check->student_id;
                                                    break;
                                                }
                                            }

                                            if ($first_student_id_for_subject !== null) {
                                                foreach ($units as $unit_entry) {
                                                    if ($unit_entry->student_id == $first_student_id_for_subject && $subject_item->id == $unit_entry->staff_id) {
                                                        if (isset($unit_counts[$unit_entry->unit])) {
                                                            $unit_counts[$unit_entry->unit]++;
                                                        }
                                                    }
                                                }
                                            }

                                            $unitOutput = [];
                                            foreach ($unit_counts as $unit_num => $count) {
                                                if ($count > 0) {
                                                    $unitOutput[] = "Unit " . $unit_num . " = " . $count . " lectures";
                                                }
                                            }
                                        @endphp

                                        @if (!empty($unitOutput))
                                            {!! implode('<br>', $unitOutput) !!}
                                        @else
                                            No unit data available for this subject.
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                     @else
                        <div class="text-center p-4">
                            <p class="text-muted mb-0">No subject or unit data available to display lecture counts.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection