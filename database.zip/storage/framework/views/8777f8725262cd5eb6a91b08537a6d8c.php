
<?php $__env->startSection('title','Student List'); ?>
<?php $__env->startSection('student_table'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<!-- 🔍 Search Input -->
<div class="mb-3">
    <input type="text" id="searchInput" class="form-control" placeholder="Search by Name or Enrollment Number">
</div>

<table class="table" id="studentTable">
    <thead>
        <tr>
            <th>Name</th>
            <th>Roll No.</th>
            <th>Student Phone Number</th>
            <th>Email ID</th>
            <th>Parent Phone Number</th>
            <th>Parent Email ID</th>
            <th>Class</th>
            <th>Last Updated</th>
            <th>Operation</th>
        </tr>
    </thead>
    <tbody>
        <?php $src = 0; ?>
        <?php if($students): ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($student->class->coundelor_id == Auth::user()->id): ?>
                    <tr>
                        <td><?php echo e($student->name); ?></td>
                        <td><?php echo e($student->enrollment_number); ?></td>
                        <td><?php echo e($student->phone_number); ?></td>
                        <td><?php echo e($student->email); ?></td>
                        <td><?php echo e($student->parents_phone_number); ?></td>
                        <td><?php echo e($student->parents_email); ?></td>
                        <td><?php echo e($student->class->program->name.'/'.$student->class->year.'/'.$student->class->sem); ?></td>
                        <td><?php echo e($student->updated_at); ?></td>
                        <td>
                            <a href="<?php echo e('/edit_student/'.$student->student_id); ?>"><button type="button" class="btn btn-info">Edit</button></a>
                            <a href="<?php echo e('delete_student/'.$student->student_id); ?>"><button type="button" class="btn btn-primary">Delete</button></a>
                        </td>
                    </tr>
                    <?php $src = 1; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>

<?php if(!$src): ?>
    <center><h2>no data found</h2></center>
<?php endif; ?>

<!-- 🔍 JS Search Script -->
<script>
    document.getElementById('searchInput').addEventListener('keyup', function () {
        let filter = this.value.toLowerCase();
        let rows = document.querySelectorAll('#studentTable tbody tr');

        rows.forEach(function (row) {
            let name = row.cells[0].textContent.toLowerCase();
            let enrollment = row.cells[1].textContent.toLowerCase();

            if (name.includes(filter) || enrollment.includes(filter)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/student_list.blade.php ENDPATH**/ ?>