

<?php $__env->startSection('title','Whatsapp List'); ?>
<?php $__env->startSection('subject_table'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<form action="whatsapp" method="get">
    <label for="add">Name OF device</label>
    <input type="text" id="add" name="device">
    <label for="number">Mobile Number</label>
    <input type="number" id="number" name="number">
    <input type="submit" value="add">
</form>

<table class="table">
    <tr>
        <th>Name</th>
        <th>Number</th>
        <th>Remain Message</th>
        <th>Status</th>
        <th>token</th>

    </tr>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($row['name']); ?></td>
        <td><?php echo e($row['device']); ?></td>
        <td><?php echo e($row['quota']); ?></td>
        <?php if($row['status']=='disconnect'): ?>
        <td>  <a href="<?php echo e('/whatsapp_img/'.$row['token'].'/'.$row['device']); ?>"><button><?php echo e($row['status']); ?></button></a></td>
        <?php endif; ?>
        <?php if($row['status']=='connect'): ?>
        <td><?php echo e($row['status']); ?></td>
        <?php endif; ?>
        <td><?php echo e($row['token']); ?></td>
        <?php if($otp_message=='yes'): ?>
        
<?php if($otp): ?>
<p><?php echo e($otp); ?></p>
<?php endif; ?>
        <td>
            <form action="<?php echo e('/otp_whatsapp/'.$row['name']); ?>" method="get">
            <label for="otp">OTP</label>
            <input type="number" name="otp" id="otp">
            <input type="hidden" value="<?php echo e($row['token']); ?>" name="token">
            <input type="submit" value="submit">
        </form>
        </td>
        <?php endif; ?>  
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php if(isset($img)): ?>
<img src="data:image/png;base64,<?php echo e($img); ?>" alt="QR Code">
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/admin/whatsapp_message.blade.php ENDPATH**/ ?>