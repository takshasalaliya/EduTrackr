
<?php $__env->startSection('title', 'Subject and Teaching Staff'); ?>
<?php $__env->startSection('teachingstaff'); ?>

<head>
    <style>
        .gradient-custom {
            background: #ffffff;
        }

        .card-registration .select-input.form-control[readonly]:not([disabled]) {
            font-size: 1rem;
            line-height: 2.15;
            padding-left: .75em;
            padding-right: .75em;
        }

        .card-registration .select-arrow {
            top: 13px;
        }
    </style>
</head>

<body>
    <section class="vh-100 gradient-custom">
        <div>
            <div>
                <div>
                    <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
                        <div class="card-body p-4 p-md-5">
                            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Subject Techer Maping</h3>
                            <?php if(session('success')): ?>
                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                                    <use xlink:href="#check-circle-fill" />
                                </svg>
                                <div>
                                    <?php echo e(session('success')); ?>

                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Error:">
                                    <use xlink:href="#exclamation-circle-fill" />
                                </svg>
                                <div>
                                    <?php echo e(session('error')); ?>

                                </div>
                            </div>
                            <?php endif; ?>

                            <form action="subjectallocated" method="GET">
                                <?php echo csrf_field(); ?>
                                <label for="program">Program</label>
                                <select name="program" id="program" onchange="Functionreset(); this.form.submit()">
                                    <option value="">Select Program</option>
                                    <option value="ITM" <?php echo e(request('program') == 'ITM' ? 'selected' : ''); ?>>ITM</option>
                                    <option value="BBA" <?php echo e(request('program') == 'BBA' ? 'selected' : ''); ?>>BBA</option>
                                    <option value="BCOM" <?php echo e(request('program') == 'BCOM' ? 'selected' : ''); ?>>BCOM</option>
                                    <option value="BCA" <?php echo e(request('program') == 'BCA' ? 'selected' : ''); ?>>BCA</option>
                                    <option value="MCOM" <?php echo e(request('program') == 'MCOM' ? 'selected' : ''); ?>>MCOM</option>
                                </select>

                                <label for="sem">Semester</label>
                                <select name="sem" id="sem" onchange="this.form.submit()">
                                    <?php if(isset($sem)): ?>
                                    <option value="">Select Semester</option>   
                                    <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($semester->sem); ?>" <?php echo e(request('sem') == $semester->sem ? 'selected' : ''); ?>>
                                        Semester <?php echo e($semester->sem); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <label for="year">Year</label>
                          
                                <select name="year" id="year" onchange="this.form.submit()">
                                <option value="">Select Year</option>
                                    <?php if(isset($year)): ?>
                                    <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semyear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($semyear->year); ?>" <?php echo e(request('year') == $semyear->year ? 'selected' : ''); ?>>
                                         <?php echo e($semyear->year); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <label for="devision">Division</label>
                                  <select name="devision" id="devision" onchange="this.form.submit()">
                                      <option value="">Select Division</option>
                                      <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($div->devision); ?>" <?php echo e(request('devision')==$div->devision?'selected':''); ?>>
                                              <?php echo e($div->devision); ?>

                                          </option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                 
                                  <label for="teacher">Teacher</label>
                                  <select name="teacher" id="teacher">
                                      <option value="">Select Teacher</option>
                                      <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($teacher->id); ?>">
                                              <?php echo e($teacher->name); ?>

                                          </option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>

                                  <div id="subject-section">
                                  <?php if(isset($year) && isset($devision) && request('program') && request('sem') && request('year') && request('devision')): ?>
                                  <br><br>
                                  <label for="subject">Subject</label>
                                  <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(request('program')==$subject->student_class->stream): ?>
                                 
                                  <br>
                                  <h6><?php echo e($subject->subject_name); ?> <input type="checkbox" value="<?php echo e($subject->subject_id); ?>" name="subject[]" id="subject"></h6>
                                
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                                 </div>
                                <button type="submit" class="btn btn-primary mt-3">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
      function Functionreset(){
        document.getElementById('sem').selectedIndex = 0;
        document.getElementById('year').selectedIndex = 0;
        document.getElementById('devision').selectedIndex = 0;
        document.getElementById('teacher').selectedIndex = 0;
        const subjectSection = document.getElementById('subject-section');
        if (subjectSection) {
            subjectSection.innerHTML = '';
        }
      }
    </script>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/subject_allocated.blade.php ENDPATH**/ ?>