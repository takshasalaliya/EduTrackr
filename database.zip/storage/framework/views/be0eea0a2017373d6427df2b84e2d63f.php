
<?php $__env->startSection('title','Teacher Dashboard'); ?>
<?php $__env->startSection('dashboard'); ?>

               <!-- Main Content -->
            <main class="col-md ms-sm-auto px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Welcome, Teacher</h1>
                </div>

                <div class="row">
                    <!-- Card 1 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Manage Attendance</h5>
                                <p class="card-text">Track and manage attendance records for your students.</p>
                                <a href="/select" class="btn btn-primary">Go to Attendance</a>
                            </div>
                        </div>
                    </div>

                    
                    <!-- Card 2 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Generate Reports</h5>
                                <p class="card-text">Create detailed reports for analysis and review.</p>
                                <a href="/attendent_list" class="btn btn-primary">View Reports</a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <center><h1>Total Lecture Of Each Unit</h1></center>
   
                     <table class="table">
                        <tr>
                            <th>Class</th>
                            <th>Unit No. = Total Lecture</th>
                        </tr>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                     <?php echo e($subject->subject->short_name.'/'.$subject->subject->student_class->program->name.'/'.$subject->subject->student_class->sem.'/'.$subject->subject->student_class->devision.'/'.$subject->subject->student_class->year); ?>

                            </td>
                            <td>
                                <?php
                                $unit_total=0;
                                $a1=0;
                                $a2=0;
                                $a3=0;
                                $a4=0;
                                $a5=0;
                                $a6=0;
                               foreach($units as $unit){
                                if($subject->id==$unit->staff_id){
                                    $unit_total++;
                                    if($unit->unit==1){
                                        $a1++;
                                    }if($unit->unit==2){
                                        $a2++;
                                    }if($unit->unit==3){
                                        $a3++;
                                    }if($unit->unit==4){
                                        $a4++;
                                    }if($unit->unit==5){
                                        $a5++;
                                    }if($unit->unit==6){
                                        $a6++;
                                    }
                                }
                                $student=0;
                                foreach($class_student as $std){
                                    if($std->class_id==$subject->subject->class_id){
                                        $student++;
                                    }
                                }
                               }

                               $a1==0?$a1t=0:$a1t=$student/$a1;
                               $a2==0?$a2t=0:$a2t=$student/$a2;
                               $a3==0?$a3t=0:$a3t=$student/$a3;
                               $a4==0?$a4t=0:$a4t=$student/$a4;
                               $a5==0?$a5t=0:$a5t=$student/$a5;
                               $a6==0?$a6t=0:$a6t=$student/$a6;


                                ?>
                                <?php echo $a1==0?'':'unit 1 ='.$a1t."<br>"; ?><?php echo $a2==0?'':'unit 2 ='.$a2t."<br>"; ?><?php echo $a3==0?'':'unit 3 ='.$a3t."<br>"; ?><?php echo $a4==0?'':'unit 4 ='.$a4t."<br>"; ?><?php echo $a5==0?'':'unit 5 ='.$a5t."<br>"; ?><?php echo $a6==0?'':'unit 6 ='.$a6t."<br>"; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                     </table>
        </div>
    </div>

    

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher/layout_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/teacher/dashboard_teacher.blade.php ENDPATH**/ ?>