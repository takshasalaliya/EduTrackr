
<?php $__env->startSection('title','Class List'); ?>
<?php $__env->startSection('add_field'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<form action="field" method="post">
    <?php echo csrf_field(); ?>
    <label for="field">Field</label>
    <input type="text" name="field" id="field">
    <input type="submit" value="submit">
</form>

<table class="table">
   <tr>
    <th>Program</th>
    <th>Delete</th>
    </tr>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($data->name); ?></td>
        <td><a href="<?php echo e('/delete_program/'.$data->program_id); ?>"><button type="button" class="btn btn-primary">Delete</button></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/admin/add_program.blade.php ENDPATH**/ ?>