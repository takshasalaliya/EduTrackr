 

<?php $__env->startSection('title', 'Student - Optional Subject Mapping (My Classes)'); ?>
<?php $__env->startSection('page_title', 'Assign Optional Subjects to Students in My Classes'); ?>

<?php $__env->startSection('optional_subject'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Assign optional subjects to students within the classes you counsel.</p>
    </div>
    
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo session('success'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert"> 
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo session('error'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-filter-circle-fill me-2"></i>Select Class to Map Optional Subjects
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('optionalgroup')); ?>" method="get" id="filterOptionalSubjectFormCounselor"> 
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label for="filter_program_counselor" class="form-label">Program (Your Classes)</label>
                        <select name="field" id="filter_program_counselor" class="form-select" onchange="document.getElementById('filterOptionalSubjectFormCounselor').submit()">
                            <option value="">Select Program</option>
                            
                            <?php if(isset($programs)): ?>
                               <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <?php if($program->coundelor_id == Auth::user()->id): ?>
              
              <option value="<?php echo e($program->program->program_id); ?>" <?php echo e($program->program->program_id == request('field') ? 'selected' : ''); ?>><?php echo e($program->program->name); ?></option>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <?php if(isset($sem)): ?>
                    <div class="col-md-2">
                        <label for="filter_sem_counselor" class="form-label">Semester</label>
                        <select name="sem" id="filter_sem_counselor" class="form-select" onchange="document.getElementById('filterOptionalSubjectFormCounselor').submit()">
                            <option value="">Select Semester</option>
                            
                            <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($sem->coundelor_id == Auth::user()->id): ?>
    <option value="<?php echo e($sem->sem); ?>" <?php echo e($sem->sem==request('sem') ? 'selected':''); ?>><?php echo e('Semester'.$sem->sem); ?></option>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($year)): ?>
                    <div class="col-md-2">
                        <label for="filter_year_counselor" class="form-label">Batch Year</label>
                        <select name="year" id="filter_year_counselor" class="form-select" onchange="document.getElementById('filterOptionalSubjectFormCounselor').submit()">
                            <option value="">Select Year</option>
                             
                             <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($year->coundelor_id == Auth::user()->id): ?>
    <option value="<?php echo e($year->year); ?>" <?php echo e($year->year==request('year') ? 'selected':''); ?>><?php echo e($year->year); ?></option>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($devision)): ?>
                    <div class="col-md-2">
                        <label for="filter_devision_counselor" class="form-label">Division</label>
                        <select name="devision" id="filter_devision_counselor" class="form-select" onchange="document.getElementById('filterOptionalSubjectFormCounselor').submit()">
                            <option value="">Select Division</option>
                            
                            <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($devision->coundelor_id == Auth::user()->id): ?>
    <option value="<?php echo e($devision->devision); ?>" <?php echo e($devision->devision==request('devision') ? 'selected':''); ?>><?php echo e($devision->devision); ?></option>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                     <div class="col-md-3">
                        <a href="<?php echo e(url('optionalgroup')); ?>" class="btn btn-outline-secondary w-100 mt-md-4">Reset Filters</a>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <?php if($valid): ?> 
    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-ui-checks me-2"></i>Assign Optional Subjects to Students
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('optionalgroup')); ?>" method="post">
                <?php echo csrf_field(); ?>
                
                <input type="hidden" name="field" value="<?php echo e(request('field')); ?>">
                <input type="hidden" name="sem" value="<?php echo e(request('sem')); ?>">
                <input type="hidden" name="year" value="<?php echo e(request('year')); ?>">
                <input type="hidden" name="devision" value="<?php echo e(request('devision')); ?>">
                <?php if(isset($class_id_from_filters)): ?> <input type="hidden" name="class_id" value="<?php echo e($class_id_from_filters); ?>"> <?php endif; ?>


                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Select Optional Subjects <span class="text-danger">*</span></label>
                        <div class="border p-2 rounded" style="max-height: 300px; overflow-y: auto;">
                            <?php if(isset($subject) && count($subject) > 0): ?> 
                                <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="subject[]" value="<?php echo e($subject_item->subject_id); ?>" id="c_subject_<?php echo e($subject_item->subject_id); ?>"
                                           <?php echo e((is_array(old('subject')) && in_array($subject_item->subject_id, old('subject'))) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="c_subject_<?php echo e($subject_item->subject_id); ?>">
                                        <?php echo e($subject_item->subject_name); ?> (<?php echo e($subject_item->subject_code); ?>)
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-muted m-0">No optional subjects found for the selected class.</p>
                            <?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['subject.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Select Students (who have not opted yet) <span class="text-danger">*</span></label>
                        <div class="border p-2 rounded" style="max-height: 300px; overflow-y: auto;">
                             <?php if(isset($students) && count($students) > 0): ?>
                                <?php $studentAvailableForOpting = false; ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($student_item->optional == 'no'): ?>
                                        <?php $studentAvailableForOpting = true; ?>
                                        <div class="form-check">
                                            <input class="form-check-input <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="student[]" value="<?php echo e($student_item->student_id); ?>" id="c_student_<?php echo e($student_item->student_id); ?>"
                                                   <?php echo e((is_array(old('student')) && in_array($student_item->student_id, old('student'))) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="c_student_<?php echo e($student_item->student_id); ?>">
                                                <?php echo e($student_item->name); ?> (<?php echo e($student_item->enrollment_number); ?>)
                                            </label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$studentAvailableForOpting): ?>
                                     <p class="text-muted m-0">All students in this class have already opted for subjects or no eligible students found.</p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-muted m-0">No students found for the selected class.</p>
                            <?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['student.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mt-4 pt-2">
                    <button class="btn btn-primary btn-lg" type="submit">
                        <i class="bi bi-check2-all me-2"></i>Assign Selected Subjects to Students
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php elseif(!(isset($valid) && $valid) && (request('field') || request('sem') || request('year') || request('devision'))): ?>
        <div class="alert alert-info mt-4">
            <i class="bi bi-info-circle-fill me-2"></i>Please complete all filters (Program, Semester, Batch Year, and Division) to load students and subjects for assignment.
        </div>
    <?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/optional_subject_group.blade.php ENDPATH**/ ?>