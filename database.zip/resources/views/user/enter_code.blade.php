<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - {{ $data->name ?? 'User' }}</title>
    <!-- Bootstrap CSS (using 5.3.2 for consistency with other designs) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #eef2f7; /* Consistent light background */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            padding-top: 20px;
            padding-bottom: 40px;
        }
        .logo-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-header img {
            max-width: 300px; /* Adjust as needed, was 50% which can be too large */
            height: auto;
        }
        .dashboard-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
            margin-bottom: 25px;
        }
        .card-header-custom {
            background-color: #0A2540; /* Dark blue from admin/counselor panels */
            color: #ffffff;
            font-size: 1.25rem;
            font-weight: 600;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
            padding: 1rem 1.5rem;
        }
        .profile-details .row > div {
            padding-bottom: 0.75rem;
        }
        .profile-details dt {
            font-weight: 600;
            color: #555;
        }
        .profile-details dd {
            margin-bottom: 0;
            color: #333;
        }
        .table thead th {
            background-color: #f8f9fa; /* Lighter header for table */
            font-weight: 600;
            color: #495057;
        }
        .table tfoot th, .table tfoot td {
            font-weight: bold;
            background-color: #e9ecef;
        }
        .attendance-percentage.high { color: #198754; /* Bootstrap success green */ }
        .attendance-percentage.medium { color: #ffc107; /* Bootstrap warning yellow */ }
        .attendance-percentage.low { color: #dc3545; /* Bootstrap danger red */ }

        @media (max-width: 767.98px) {
            .logo-header img {
                max-width: 200px;
            }
        }
    </style>
</head>
<body>

    <div class="logo-header">
        <img src="https://i.ibb.co/yFhzNxBJ/3-removebg-preview.png" alt="Semcom Logo">
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-8">

                <!-- Session Messages -->
                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i>
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <div class="dashboard-card">
                    <div class="card-header-custom text-center">
                        Student Dashboard
                    </div>
                    <div class="card-body p-4 p-md-5">

                        <h4 class="mb-3"><i class="bi bi-person-circle me-2"></i>Welcome, {{ $data->name ?? 'Student' }}!</h4>

                        {{-- Student Information Section --}}
                        <div class="profile-details mb-4 p-3 bg-light border rounded">
                            <h5 class="mb-3 border-bottom pb-2">Your Profile</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <dl class="row mb-0">
                                        <dt class="col-sm-5">Enrollment No.:</dt>
                                        <dd class="col-sm-7">{{ $data->enrollment_number ?? 'N/A' }}</dd>
                                        <dt class="col-sm-5">Name:</dt>
                                        <dd class="col-sm-7">{{ $data->name ?? 'N/A' }}</dd>
                                    </dl>
                                </div>
                                <div class="col-md-6">
                                    <dl class="row mb-0">
                                        <dt class="col-sm-5">Class/Program:</dt>
                                        <dd class="col-sm-7">{{ $data->class->program->name ?? 'N/A' }}</dd>
                                        <dt class="col-sm-5">Semester:</dt>
                                        <dd class="col-sm-7">Sem {{ $data->class->sem ?? 'N/A' }}</dd>
                                        <dt class="col-sm-5">Batch:</dt>
                                        <dd class="col-sm-7">{{ $data->class->year ?? 'N/A' }}</dd>
                                        <dt class="col-sm-5">Division:</dt>
                                        <dd class="col-sm-7">{{ $data->class->devision ?? 'N/A' }}</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>

                        {{-- Enter Attendance Code Form --}}
                        <div class="mb-4 p-3 border rounded">
                            <h5 class="mb-3 border-bottom pb-2"><i class="bi bi-qr-code-scan me-2"></i>Mark Lecture Attendance</h5>
                            <form action="{{ url('code_enter') }}" method="get">
                                <div class="row g-2 align-items-end">
                                    <div class="col">
                                        <label for="attendance_code" class="form-label visually-hidden">Enter Code</label>
                                        <input type="number" class="form-control form-control-lg @error('code') is-invalid @enderror" name="code" id="attendance_code" placeholder="Enter Lecture Attendance Code" required>
                                        @error('code') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" class="btn btn-primary btn-lg">Submit Code</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        
                        {{-- Lecture Attendance Summary Table --}}
                        <div class="attendance-summary mb-5">
                            <h5 class="mb-3 border-bottom pb-2"><i class="bi bi-card-checklist me-2"></i>Your Lecture Attendance Summary</h5>
                            @if(isset($attend) && (is_array($attend) || $attend instanceof \Illuminate\Support\Collection) && count($attend) > 0)
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col">Subject Name</th>
                                            <th scope="col" class="text-center">Total Lectures</th>
                                            <th scope="col" class="text-center">Lectures Attended</th>
                                            <th scope="col" class="text-center">Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $processedAttendData = [];
                                            if (is_array($attend) || $attend instanceof \Illuminate\Support\Collection) {
                                                foreach($attend as $atte_string) {
                                                    $parts = explode('@', $atte_string);
                                                    $processedAttendData[] = (object)[
                                                        'subject_name' => $parts[0] ?? 'N/A',
                                                        'total_lectures' => (int)($parts[3] ?? 0),
                                                        'lectures_attended' => (int)($parts[1] ?? 0),
                                                        'percentage_string' => $parts[2] ?? '0%',
                                                        'percentage_numeric' => (float)rtrim($parts[2] ?? '0', '%')
                                                    ];
                                                }
                                            }
                                        @endphp
                                        @forelse($processedAttendData as $summary)
                                        <tr>
                                            <td>{{ $summary->subject_name }}</td>
                                            <td class="text-center">{{ $summary->total_lectures }}</td>
                                            <td class="text-center">{{ $summary->lectures_attended }}</td>
                                            <td class="text-center attendance-percentage
                                                @if($summary->percentage_numeric >= 75) high
                                                @elseif($summary->percentage_numeric >= 50) medium
                                                @else low @endif">
                                                <strong>{{ $summary->percentage_string }}</strong>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr><td colspan="4" class="text-center text-muted">No lecture attendance data available.</td></tr>
                                        @endforelse
                                    </tbody>
                                    @if(isset($lecture) && isset($present) && count($processedAttendData) > 0)
                                    <tfoot class="table-group-divider">
                                        <tr>
                                            <th>Overall Lecture Total</th>
                                            <td class="text-center">{{ $lecture }}</td>
                                            <td class="text-center">{{ $present }}</td>
                                            @php
                                                $overall_percentage_numeric = ($lecture > 0) ? ($present / $lecture) * 100 : 0;
                                            @endphp
                                            <td class="text-center attendance-percentage
                                                @if($overall_percentage_numeric >= 75) high
                                                @elseif($overall_percentage_numeric >= 50) medium
                                                @else low @endif">
                                                <strong>{{ number_format($overall_percentage_numeric, 2) }}%</strong>
                                            </td>
                                        </tr>
                                    </tfoot>
                                    @endif
                                </table>
                            </div>
                            @else
                            <p class="text-muted">No lecture attendance summary available at the moment.</p>
                            @endif
                        </div>


                        {{-- Activity Log Table --}}
                        <div class="activity-log">
                            <h5 class="mb-3 border-bottom pb-2"><i class="bi bi-calendar-event me-2"></i>Your Activity Log</h5>
                            @if(isset($activity_participation) && $activity_participation->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Activity Name</th>
                                            <th scope="col" class="text-center">Session No.</th>
                                            <th scope="col">From Date</th>
                                            <th scope="col">To Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $total_activity_sessions_attended = 0; // Initialize counter for total sessions
                                        @endphp
                                        @foreach($activity_participation as $index => $participation)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $participation->activity->name ?? ($participation->name ?? 'N/A') }}</td>
                                            <td class="text-center">{{ $participation->session }}</td>
                                            <td>{{ isset($participation->activity->date_from) ? \Carbon\Carbon::parse($participation->activity->date_from)->format('d M Y') : (isset($participation->from_date) ? \Carbon\Carbon::parse($participation->from_date)->format('d M Y') : 'N/A') }}</td>
                                            <td>{{ isset($participation->activity->date_to) ? \Carbon\Carbon::parse($participation->activity->date_to)->format('d M Y') : (isset($participation->to_date) ? \Carbon\Carbon::parse($participation->to_date)->format('d M Y') : 'N/A') }}</td>
                                            @php
                                                // Sum up the session numbers
                                                // Ensure 'session_number' or 'session' exists and is numeric
                                                $total_activity_sessions_attended += $participation->session;
                                            @endphp
                                        </tr>
                                        @endforeach
                                    </tbody>
                                    <tfoot class="table-group-divider">
                                        <tr>
                                            <th colspan="2" class="text-start">Total Distinct Activities:</th>
                                            <th class="text-center">{{ $activity_participation->count() }}</th>
                                            <th class="text-end">Total Sessions Attended:</th>
                                            <th class="text-center">{{ $total_activity_sessions_attended }}</th>
                                        </tr>
                                        @php
                                                $presentslecture=$present+$total_activity_sessions_attended;
                                                $overall_percentage_numeric = ($present=+$total_activity_sessions_attended > 0) ? ($presentslecture / $lecture   ) * 100 : 0;
                                            @endphp
                                        @if($overall_percentage_numeric<=100)
                                        <tr>
                                            <th colspan="2" class="text-start">Overall Attendance:</th>
                                            <td class="text-center attendance-percentage
                                                @if($overall_percentage_numeric >= 75) high
                                                @elseif($overall_percentage_numeric >= 50) medium
                                                @else low @endif">
                                                <strong>{{ number_format($overall_percentage_numeric, 2) }}%</strong>
                                            </td>
                                        </tr>
                                        @endif
                                    </tfoot>
                                </table>
                            </div>
                            @else
                            <p class="text-muted">You have not participated in any logged activities yet.</p>
                            @endif
                        </div>


                        <hr class="my-4">
                        <div class="text-center">
                            <a href="{{ url('/logout') }}" class="btn btn-outline-danger btn-lg">
                                <i class="bi bi-box-arrow-right me-2"></i>Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>