
<?php $__env->startSection('title','Attendent List'); ?>
<?php $__env->startSection('subject_table_attendent'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<a href="<?php echo e('generate_pdf_counselor/'.request('subject')); ?>"><button type="button" class="btn btn-info">PDF</button></a>
    <a href="<?php echo e('generate_excel_counselor/'.request('subject')); ?>"><button type="button" class="btn btn-info">Excel</button></a></td>

<form action="attendent_list_counselor" method="get">
    <label for="subject">Subject</label>
    <select name="subject" id="subject" onchange="this.form.submit()">
        <option value="">Select Subject</option>
        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <option value="<?php echo e($subj->id); ?>" <?php echo e(request('subject')==$subj->id?'selected':''); ?>><?php echo e($subj->subject->short_name.'/'.$subj->subject->student_class->program->name.'/'.$subj->subject->student_class->sem.'/'.$subj->subject->student_class->devision.'/'.$subj->subject->student_class->year); ?></option>
                     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>

<?php if($student): ?>

<table class="table">

    <th>Enrollment Number</th>
    <th>Name</th>
    <th>Total Class</th>
    <th>From</th>
    <th>To</th>
    <th>Present</th>
    <th>Pertentage</th>
    <th>Message</th>
</tr>   
<?php $__currentLoopData = $valid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
    
    <?php
    $sum=0;
    $present=0;
    $enter=0;
    $date=[];
    foreach ($student as $d) {
        if ($d->student->enrollment_number == $data && $d->staff_id == $id) {
            $date[]=$d->created_at;
            $sum++;
            $to=explode(" ",$d->created_at);
            $name=$d->student->name;
            $message=$d->student->student_id;
            if($d->attendance=='present'){
                $present++;
            }
        }

        
    }
    sort($date);
    $from=$date[0]; 
    $from=explode(" ",$from);
    $to = end($date);
    $to=explode(" ",$to);
    $pertentage=number_format($present/$sum*100,2);
    ?>
    <td><?php echo e($data); ?></td>
    <td><?php echo e($name); ?></td>
    <td><?php echo e($sum); ?></td>
    <td><?php echo e($from[0]); ?></td>
    <td><?php echo e($to[0]); ?></td>
   <td><?php echo e($present); ?></td>
   <td><?php echo e($pertentage); ?>%</td>
   <td>
   <a href="<?php echo e('send-watsapp/'.$message.'/'.$pertentage.'/'.$subject_id); ?>"><button type="button" class="btn btn-info">Send Message</button></a>
   </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/attendent_list.blade.php ENDPATH**/ ?>