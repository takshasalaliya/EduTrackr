

<?php $__env->startSection('title', 'Subject List'); ?>
 

<?php $__env->startSection('subject_table'); ?>


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Manage Subjects</h1>
    <div>
        <a href="<?php echo e(url('add_subject_admin')); ?>" class="btn btn-primary"> 
            <i class="bi bi-plus-circle-fill me-2"></i>Add New Subject
        </a>
    </div>
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card card-custom">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <i class="bi bi-journals me-2"></i>All Subjects
            </div>
            <form action="<?php echo e(url('subject_list_filter_admin')); ?>" method="get" class="d-flex align-items-center ms-auto">
                <label for="filter_category" class="form-label me-2 mb-0 visually-hidden">Filter by Category:</label>
                <select name="field" id="filter_category" class="form-select form-select-sm" onchange="this.form.submit()" style="min-width: 180px;">
                    <option value="all" <?php echo e(($select ?? 'all') == 'all' ? 'selected' : ''); ?>>All Categories</option>
                    <option value="required" <?php echo e(($select ?? '') == 'required' ? 'selected' : ''); ?>>Required</option>
                    <option value="optional" <?php echo e(($select ?? '') == 'optional' ? 'selected' : ''); ?>>Optional</option>
                </select>
                
            </form>
        </div>
        <div class="card-body p-0">
            <?php if(isset($subjects) && $subjects->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Subject Name</th>
                            <th scope="col">Short Name</th>
                            <th scope="col">Code</th>
                            <th scope="col">Category</th>
                            <th scope="col">Type (L/P)</th>
                            <th scope="col">Associated Classes</th> 
                            <th scope="col">Last Updated</th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1 + ($subjects instanceof \Illuminate\Pagination\LengthAwarePaginator ? ($subjects->currentPage() - 1) * $subjects->perPage() : 0)); ?></td>
                            <td><?php echo e($subject->subject_name); ?></td>
                            <td><?php echo e($subject->short_name ?? 'N/A'); ?></td>
                            <td><?php echo e($subject->subject_code); ?></td>
                            <td><span class="badge bg-info text-dark"><?php echo e(ucfirst($subject->category)); ?></span></td>
                            <td>
                                <?php if($subject->lecture_category == 'T'): ?>
                                    <span class="badge bg-primary">Theory (T)</span>
                                <?php elseif($subject->lecture_category == 'P'): ?>
                                    <span class="badge bg-success">Practical (P)</span>
                                <?php else: ?>
                                    <?php echo e($subject->l_category ?? 'N/A'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($subject->classes && $subject->classes->count() > 0): ?> 
                                    <?php $__currentLoopData = $subject->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-light text-dark mb-1 d-block">
                                            <?php echo e($class_item->program->name ?? 'N/A'); ?> / Sem <?php echo e($class_item->sem ?? 'N/A'); ?> / Div <?php echo e($class_item->devision ?? 'N/A'); ?> (<?php echo e($class_item->year ?? 'N/A'); ?>)
                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif($subject->student_class): ?> 
                                    <span class="badge bg-light text-dark">
                                    <?php echo e($subject->student_class->program->name ?? 'N/A Program'); ?> /
                                    <?php echo e($subject->student_class->year ?? 'N/A Batch'); ?> /
                                    Sem <?php echo e($subject->student_class->sem ?? 'N/A'); ?> /
                                    Div <?php echo e($subject->student_class->devision ?? 'N/A'); ?>

                                    </span>
                                <?php else: ?>
                                    Not Assigned
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($subject->updated_at ? $subject->updated_at->format('d M Y, h:i A') : 'N/A'); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(url('/edit_subject_admin/'.$subject->subject_id)); ?>" class="btn btn-sm btn-outline-warning me-1" title="Edit Subject">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Subject"
                                        data-bs-toggle="modal" data-bs-target="#deleteSubjectModal"
                                        data-subject-id="<?php echo e($subject->subject_id); ?>" data-subject-name="<?php echo e($subject->subject_name); ?>">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-journal-x display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">
                    <?php if(($select ?? 'all') != 'all'): ?>
                        No subjects found for the selected category.
                    <?php else: ?>
                        No subjects found in the system.
                    <?php endif; ?>
                </p>
                 <?php if(($select ?? 'all') != 'all'): ?>
                    <p class="small text-muted mt-2">Try selecting "All Categories" in the filter.</p>
                <?php else: ?>
                     <p class="small text-muted mt-2">You can <a href="<?php echo e(url('add_subject_admin')); ?>">add subjects</a> to populate this list.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php if(isset($subjects) && $subjects instanceof \Illuminate\Pagination\LengthAwarePaginator && $subjects->hasPages()): ?>
        <div class="card-footer bg-light border-top-0">
            <?php echo e($subjects->appends(request()->query())->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Subject Confirmation Modal -->
<div class="modal fade" id="deleteSubjectModal" tabindex="-1" aria-labelledby="deleteSubjectModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteSubjectModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete the subject: <strong id="subjectNameToDelete"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone and might affect class schedules or student records associated with this subject.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteSubjectForm" method="get" action=""> 

            <button type="submit" class="btn btn-danger">Yes, Delete Subject</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteSubjectModal = document.getElementById('deleteSubjectModal');
    if (deleteSubjectModal) {
        deleteSubjectModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var subjectId = button.getAttribute('data-subject-id');
            var subjectName = button.getAttribute('data-subject-name');

            var modalBodyStrong = deleteSubjectModal.querySelector('#subjectNameToDelete');
            var deleteForm = deleteSubjectModal.querySelector('#deleteSubjectForm');

            modalBodyStrong.textContent = subjectName;

            // For your current GET route: '<?php echo e(url("delete_subject_admin")); ?>/' + subjectId;
            // For RESTful DELETE (recommended): '<?php echo e(url("/admin/subjects")); ?>/' + subjectId;
            deleteForm.action = 'delete_subject_admin/' + subjectId; // Using your current GET route

            // If using GET, remove method spoofing and set form method to GET
            const methodInput = deleteForm.querySelector('input[name="_method"]');
            if (methodInput) {
                methodInput.remove();
            }
            deleteForm.method = 'GET';
        });
    }
});
</script>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/list_subject.blade.php ENDPATH**/ ?>