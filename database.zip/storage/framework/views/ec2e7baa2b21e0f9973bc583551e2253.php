

<?php $__env->startSection('title','TeachingStaff List'); ?>
<?php $__env->startSection('subject_table'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<form action="teachingstaff_list_filter_admin" method="get">
    <select name="teacher" id="teacher" onchange="this.form.submit()">
        <option value="all" <?php echo e($select=='all'?'selected':''); ?>>All</option>
        
        <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($teacher->role != 'admin' && $teacher->role != 'student'): ?>
        <option value="<?php echo e($teacher->id); ?>" <?php echo e($teacher->id==$select?'selected':''); ?>><?php echo e($teacher->name); ?></option>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>
<table class="table"> 
   
    <tr>
    <th>Subject Name</th>
    <th>Subject Short Name</th>
    <th>Subject Code</th>
    <th>Proffersor Name</th>
    <th>Short Name</th>
    <th>Email</th>
    <th>Class</th>
    <th>Last Updated</th>
    <th>Operation</th>
    </tr>
    <?php $__currentLoopData = $teachingstaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td><?php echo e($data->subject->subject_name); ?></td>
        <td><?php echo e($data->subject->short_name); ?></td>
        <td><?php echo e($data->subject->subject_code); ?></td>
        <td><?php echo e($data->teacher->name); ?></td>
        <td><?php echo e($data->teacher->short_name); ?></td>
        <td><?php echo e($data->teacher->email); ?></td>
        <td><?php echo e($data->subject->student_class->program->name.'/'.$data->subject->student_class->sem.'/'.$data->subject->student_class->devision); ?></td>
        <td><?php echo e($data->updated_at); ?></td>
        <td><a href="<?php echo e('delete_staff_admin/'.$data->id); ?>"><button type="button" class="btn btn-primary">Delete</button></a></td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/admin/list_teachingstaff.blade.php ENDPATH**/ ?>