
<?php $__env->startSection('title','TeachingStaff List'); ?>
<?php $__env->startSection('subject_table'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<table class="table">   <tr>
    <th>Subject Name</th>
    <th>Subject Short Name</th>
    <th>Subject Code</th>
    <th>Proffersor Name</th>
    <th>Short Name</th>
    <th>Email</th>
    <th>Last Updated</th>
    <th>Operation</th>
    </tr>
    <?php $__currentLoopData = $teachingstaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($data->subject->subject_name); ?></td>
        <td><?php echo e($data->subject->short_name); ?></td>
        <td><?php echo e($data->subject->subject_code); ?></td>
        <td><?php echo e($data->teacher->name); ?></td>
        <td><?php echo e($data->teacher->short_name); ?></td>
        <td><?php echo e($data->teacher->email); ?></td>
        <td><?php echo e($data->updated_at); ?></td>
        <td><a href="<?php echo e('/edit_staff/'.$data->id); ?>"><button type="button" class="btn btn-info">Edit</button></a>
        <a href="<?php echo e('delete_staff/'.$data->id); ?>"><button type="button" class="btn btn-primary">Delete</button></a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views//list_teachingstaff.blade.php ENDPATH**/ ?>