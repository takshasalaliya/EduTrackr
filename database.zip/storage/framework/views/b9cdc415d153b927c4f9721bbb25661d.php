 

<?php $__env->startSection('title', 'Assign Subjects to Teachers (My Classes)'); ?>
<?php $__env->startSection('page_title', 'Assign Subjects to Teachers for My Classes'); ?>

<?php $__env->startSection('teachingstaff'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Assign subjects to teachers specifically for the classes you counsel.</p>
    </div>
    
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo session('success'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo session('error'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-ui-checks-grid me-2"></i>Select Class & Teacher for Subject Assignment
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('subjectallocated')); ?>" method="GET" id="filterAssignmentFormCounselor">
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <label for="program_filter_c" class="form-label">Program (Your Classes)</label>
                        <select name="program" id="program_filter_c" class="form-select" onchange="document.getElementById('filterAssignmentFormCounselor').submit()">
                            <option value="">Select Program</option>
                            <?php if(isset($programs ) && $programs->count() > 0): ?> 
                                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($program->coundelor_id==Auth::user()->id): ?>
                                <option value="<?php echo e($program->program->program_id); ?>" <?php echo e(request('program')==$program->program->program_id?'selected':''); ?>><?php echo e($program->program->name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <?php if(isset($sem)): ?> 
                    <div class="col-md-2">
                        <label for="semester_filter_c" class="form-label">Semester</label>
                        <select name="sem" id="semester_filter_c" class="form-select" onchange="document.getElementById('filterAssignmentFormCounselor').submit()">
                            <option value="">Select Semester</option>
                            <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($sem->coundelor_id == Auth::user()->id): ?>
                                <option value="<?php echo e($sem->sem); ?>" <?php echo e(request('sem')==$sem->sem?'selected':''); ?>>Semester <?php echo e($sem->sem); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($year)): ?> 
                    <div class="col-md-2">
                        <label for="year_filter_c" class="form-label">Batch Year</label>
                        <select name="year" id="year_filter_c" class="form-select" onchange="document.getElementById('filterAssignmentFormCounselor').submit()">
                            <option value="">Select Year</option>
                            <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($year->coundelor_id==Auth::user()->id): ?>
                                <option value="<?php echo e($year->year); ?>" <?php echo e(request('year')==$year->year?'selected' : ''); ?>><?php echo e($year->year); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($devision)): ?> 
                    <div class="col-md-2">
                        <label for="devision_filter_c" class="form-label">Division</label>
                        <select name="devision" id="devision_filter_c" class="form-select" onchange="document.getElementById('filterAssignmentFormCounselor').submit()">
                            <option value="">Select Division</option>
                            <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($devision->coundelor_id == Auth::user()->id): ?>
                                <option value="<?php echo e($devision->devision); ?>" <?php echo e(request('devision')==$devision->devision?'selected':''); ?>><?php echo e($devision->devision); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($teacher)): ?> 
                    <div class="col-md-3">
                        <label for="teacher_filter_c" class="form-label">Teacher</label>
                        <select name="teacher" id="teacher_filter_c" class="form-select" onchange="document.getElementById('filterAssignmentFormCounselor').submit()">
                            <option value="">Select Teacher</option>
                            <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($teacher->role != 'admin' && $teacher->role != 'student'): ?>
                                <option value="<?php echo e($teacher->id); ?>" <?php echo e(request('teacher')==$teacher->id?'selected':''); ?>><?php echo e($teacher->name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
            </form>

            <?php if(isset($class_id) && $class_id && isset($subject)): ?>
            <hr class="my-4">
            <h5>Assign Subjects for Teacher: <strong><?php echo e($teacher->firstWhere('id', request('teacher'))->name ?? 'Selected Teacher'); ?></strong></h5>
            <p class="text-muted">
                For Class: <?php echo e($class_details_info ?? 'Details based on filters'); ?> 
            </p>
            <form action="<?php echo e(url('/subjectallocated')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(request('teacher')); ?>" name="teacher">
                <input type="hidden" value="<?php echo e($class_id); ?>" name="class_id">

                <div class="mb-3 border p-3 rounded">
                    <label class="form-label fw-bold">Available Subjects for the Selected Class:</label>
                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($subject->class_id == $class_id): ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox"value="<?php echo e($subject->subject_id); ?>" name="subject[]" id="<?php echo e($subject->subject_id); ?>">
                            <label class="form-check-label" for="<?php echo e($subject->subject_id); ?>">
                                <?php echo e($subject->subject_name); ?> (<?php echo e($subject->subject_code); ?>)
                                - <small class="text-muted"><?php echo e(ucfirst($subject->category)); ?>, <?php echo e($subject->lecture_category == 'T' ? 'Theory' : ($subject->lecture_category == 'P' ? 'Practical' : '')); ?></small>
                            </label>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check2-square me-2"></i>Save Assignments
                </button>
            </form>
            <?php elseif(request('program') && request('teacher') && !(request('sem') && request('year') && request('devision'))): ?>
                <div class="alert alert-info mt-3">
                    <i class="bi bi-info-circle-fill me-2"></i>Please complete all class filters (Semester, Batch Year, Division) to load subjects for assignment.
                </div>
             <?php elseif(request('program') && request('sem') && request('year') && request('devision') && request('teacher') && (!isset($subjects_for_class) || $subjects_for_class->count() == 0)): ?>
                <div class="alert alert-warning mt-3">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>No subjects found associated with the selected class. Please add subjects to this class configuration first.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/subject_allocated.blade.php ENDPATH**/ ?>