<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - <?php echo e($data->name ?? 'User'); ?></title>
    <!-- Bootstrap CSS (using 5.3.2 for consistency with other designs) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #eef2f7; /* Consistent light background */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            padding-top: 20px;
            padding-bottom: 40px;
        }
        .logo-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-header img {
            max-width: 300px; /* Adjust as needed, was 50% which can be too large */
            height: auto;
        }
        .dashboard-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
            margin-bottom: 25px;
        }
        .card-header-custom {
            background-color: #0A2540; /* Dark blue from admin/counselor panels */
            color: #ffffff;
            font-size: 1.25rem;
            font-weight: 600;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
            padding: 1rem 1.5rem;
        }
        .profile-details .row > div {
            padding-bottom: 0.75rem;
        }
        .profile-details dt {
            font-weight: 600;
            color: #555;
        }
        .profile-details dd {
            margin-bottom: 0;
            color: #333;
        }
        .table thead th {
            background-color: #f8f9fa; /* Lighter header for table */
            font-weight: 600;
            color: #495057;
        }
        .table tfoot th, .table tfoot td {
            font-weight: bold;
            background-color: #e9ecef;
        }
        .attendance-percentage.high { color: #198754; /* Bootstrap success green */ }
        .attendance-percentage.medium { color: #ffc107; /* Bootstrap warning yellow */ }
        .attendance-percentage.low { color: #dc3545; /* Bootstrap danger red */ }

        @media (max-width: 767.98px) {
            .logo-header img {
                max-width: 200px;
            }
        }
    </style>
</head>
<body>

    <div class="logo-header">
        <img src="https://i.ibb.co/yFhzNxBJ/3-removebg-preview.png" alt="Semcom Logo">
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-8">

                <!-- Session Messages -->
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="dashboard-card">
                    <div class="card-header-custom text-center">
                        Student Dashboard
                    </div>
                    <div class="card-body p-4 p-md-5">

                        <h4 class="mb-3"><i class="bi bi-person-circle me-2"></i>Welcome, <?php echo e($data->name ?? 'Student'); ?>!</h4>

                        
                        <div class="profile-details mb-4 p-3 bg-light border rounded">
                            <h5 class="mb-3 border-bottom pb-2">Your Profile</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <dl class="row mb-0">
                                        <dt class="col-sm-5">Enrollment No.:</dt>
                                        <dd class="col-sm-7"><?php echo e($data->enrollment_number ?? 'N/A'); ?></dd>
                                        <dt class="col-sm-5">Name:</dt>
                                        <dd class="col-sm-7"><?php echo e($data->name ?? 'N/A'); ?></dd>
                                    </dl>
                                </div>
                                <div class="col-md-6">
                                    <dl class="row mb-0">
                                        <dt class="col-sm-5">Class/Program:</dt>
                                        <dd class="col-sm-7"><?php echo e($data->class->program->name ?? 'N/A'); ?></dd>
                                        <dt class="col-sm-5">Semester:</dt>
                                        <dd class="col-sm-7">Sem <?php echo e($data->class->sem ?? 'N/A'); ?></dd>
                                        <dt class="col-sm-5">Batch:</dt>
                                        <dd class="col-sm-7"><?php echo e($data->class->year ?? 'N/A'); ?></dd>
                                        <dt class="col-sm-5">Division:</dt>
                                        <dd class="col-sm-7"><?php echo e($data->class->devision ?? 'N/A'); ?></dd>
                                    </dl>
                                </div>
                            </div>
                        </div>

                        
                        <div class="mb-4 p-3 border rounded">
                            <h5 class="mb-3 border-bottom pb-2"><i class="bi bi-qr-code-scan me-2"></i>Mark Lecture Attendance</h5>
                            <form action="<?php echo e(url('code_enter')); ?>" method="get">
                                <div class="row g-2 align-items-end">
                                    <div class="col">
                                        <label for="attendance_code" class="form-label visually-hidden">Enter Code</label>
                                        <input type="number" class="form-control form-control-lg <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="code" id="attendance_code" placeholder="Enter Lecture Attendance Code" required>
                                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" class="btn btn-primary btn-lg">Submit Code</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        
                        
                        <div class="attendance-summary mb-5">
                            <h5 class="mb-3 border-bottom pb-2"><i class="bi bi-card-checklist me-2"></i>Your Lecture Attendance Summary</h5>
                            <?php if(isset($attend) && (is_array($attend) || $attend instanceof \Illuminate\Support\Collection) && count($attend) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col">Subject Name</th>
                                            <th scope="col" class="text-center">Total Lectures</th>
                                            <th scope="col" class="text-center">Lectures Attended</th>
                                            <th scope="col" class="text-center">Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $processedAttendData = [];
                                            if (is_array($attend) || $attend instanceof \Illuminate\Support\Collection) {
                                                foreach($attend as $atte_string) {
                                                    $parts = explode('@', $atte_string);
                                                    $processedAttendData[] = (object)[
                                                        'subject_name' => $parts[0] ?? 'N/A',
                                                        'total_lectures' => (int)($parts[3] ?? 0),
                                                        'lectures_attended' => (int)($parts[1] ?? 0),
                                                        'percentage_string' => $parts[2] ?? '0%',
                                                        'percentage_numeric' => (float)rtrim($parts[2] ?? '0', '%')
                                                    ];
                                                }
                                            }
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $processedAttendData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($summary->subject_name); ?></td>
                                            <td class="text-center"><?php echo e($summary->total_lectures); ?></td>
                                            <td class="text-center"><?php echo e($summary->lectures_attended); ?></td>
                                            <td class="text-center attendance-percentage
                                                <?php if($summary->percentage_numeric >= 75): ?> high
                                                <?php elseif($summary->percentage_numeric >= 50): ?> medium
                                                <?php else: ?> low <?php endif; ?>">
                                                <strong><?php echo e($summary->percentage_string); ?></strong>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="4" class="text-center text-muted">No lecture attendance data available.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                    <?php if(isset($lecture) && isset($present) && count($processedAttendData) > 0): ?>
                                    <tfoot class="table-group-divider">
                                        <tr>
                                            <th>Overall Lecture Total</th>
                                            <td class="text-center"><?php echo e($lecture); ?></td>
                                            <td class="text-center"><?php echo e($present); ?></td>
                                            <?php
                                                $overall_percentage_numeric = ($lecture > 0) ? ($present / $lecture) * 100 : 0;
                                            ?>
                                            <td class="text-center attendance-percentage
                                                <?php if($overall_percentage_numeric >= 75): ?> high
                                                <?php elseif($overall_percentage_numeric >= 50): ?> medium
                                                <?php else: ?> low <?php endif; ?>">
                                                <strong><?php echo e(number_format($overall_percentage_numeric, 2)); ?>%</strong>
                                            </td>
                                        </tr>
                                    </tfoot>
                                    <?php endif; ?>
                                </table>
                            </div>
                            <?php else: ?>
                            <p class="text-muted">No lecture attendance summary available at the moment.</p>
                            <?php endif; ?>
                        </div>


                        
                        <div class="activity-log">
                            <h5 class="mb-3 border-bottom pb-2"><i class="bi bi-calendar-event me-2"></i>Your Activity Log</h5>
                            <?php if(isset($activity_participation) && $activity_participation->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Activity Name</th>
                                            <th scope="col" class="text-center">Session No.</th>
                                            <th scope="col">From Date</th>
                                            <th scope="col">To Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $total_activity_sessions_attended = 0; // Initialize counter for total sessions
                                        ?>
                                        <?php $__currentLoopData = $activity_participation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($participation->activity->name ?? ($participation->name ?? 'N/A')); ?></td>
                                            <td class="text-center"><?php echo e($participation->session); ?></td>
                                            <td><?php echo e(isset($participation->activity->date_from) ? \Carbon\Carbon::parse($participation->activity->date_from)->format('d M Y') : (isset($participation->from_date) ? \Carbon\Carbon::parse($participation->from_date)->format('d M Y') : 'N/A')); ?></td>
                                            <td><?php echo e(isset($participation->activity->date_to) ? \Carbon\Carbon::parse($participation->activity->date_to)->format('d M Y') : (isset($participation->to_date) ? \Carbon\Carbon::parse($participation->to_date)->format('d M Y') : 'N/A')); ?></td>
                                            <?php
                                                // Sum up the session numbers
                                                // Ensure 'session_number' or 'session' exists and is numeric
                                                $total_activity_sessions_attended += $participation->session;
                                            ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot class="table-group-divider">
                                        <tr>
                                            <th colspan="2" class="text-start">Total Distinct Activities:</th>
                                            <th class="text-center"><?php echo e($activity_participation->count()); ?></th>
                                            <th class="text-end">Total Sessions Attended:</th>
                                            <th class="text-center"><?php echo e($total_activity_sessions_attended); ?></th>
                                        </tr>
                                        <?php
                                                $presentslecture=$present+$total_activity_sessions_attended;
                                                $overall_percentage_numeric = ($present=+$total_activity_sessions_attended > 0) ? ($presentslecture / $lecture   ) * 100 : 0;
                                            ?>
                                        <?php if($overall_percentage_numeric<=100): ?>
                                        <tr>
                                            <th colspan="2" class="text-start">Overall Attendance:</th>
                                            <td class="text-center attendance-percentage
                                                <?php if($overall_percentage_numeric >= 75): ?> high
                                                <?php elseif($overall_percentage_numeric >= 50): ?> medium
                                                <?php else: ?> low <?php endif; ?>">
                                                <strong><?php echo e(number_format($overall_percentage_numeric, 2)); ?>%</strong>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tfoot>
                                </table>
                            </div>
                            <?php else: ?>
                            <p class="text-muted">You have not participated in any logged activities yet.</p>
                            <?php endif; ?>
                        </div>


                        <hr class="my-4">
                        <div class="text-center">
                            <a href="<?php echo e(url('/logout')); ?>" class="btn btn-outline-danger btn-lg">
                                <i class="bi bi-box-arrow-right me-2"></i>Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/user/enter_code.blade.php ENDPATH**/ ?>