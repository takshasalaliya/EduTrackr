
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('dashboard'); ?>


    <style>
        .info-box {
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .info-box i {
            font-size: 30px;
            margin-bottom: 10px;
        }
        
    </style>

<body>
    <center><img src="https://i.ibb.co/yFhzNxBJ/3-removebg-preview.png" alt="Semcom" width=50%></center>
    <div class="container mt-5">
        <div class="row g-3">
            <!-- Box 1 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #7A3B8E;">
                    <i class="bi bi-person-lines-fill"></i>
                    <h2><?php echo e($students); ?></h2>
                    <p>STUDENTS</p>
                </div>
            </div>
            <!-- Box 2 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #E74C3C;">
                    <i class="bi bi-people"></i>
                    <h2><?php echo e($teachers); ?></h2>
                    <p>TEACHER</p>
                </div>
            </div>
            <!-- Box 3 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #17A589;">
                    <i class="bi bi-book"></i>
                    <h2><?php echo e($counselors); ?> </h2>
                    <p>COUNCELOR</p>
                </div>
            </div>
            <!-- Box 4 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #2980B9;">
                    <i class="bi-classbi bi-hospital"></i>
                    <h2><?php echo e($classes); ?></h2>
                    <p>CLASS</p>
                </div>
            </div>
        </div>
    </div><br>
<center><h2>Your Class</h2></center>
    <table class="table">
        <tr>
        <th>ID</th>
        <th>Class</th>
        <th>Devision</th>
        <th>Semester</th>
        <th>Batch</th>

        </tr>
        <tr>
            <?php $__currentLoopData = $class_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($class->coundelor_id == Auth::user()->id): ?>
            <tr>
                <td><?php echo e($class->id); ?></td>
                <td><?php echo e($class->program->name); ?></td>
                <td><?php echo e($class->devision); ?></td>
                <td><?php echo e($class->sem); ?></td>
                <td><?php echo e($class->year); ?></td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
    
    <center><h1>Total Lecture Of Each Unit</h1></center>
   
                     <table class="table">
                        <tr>
                            <th>Class</th>
                            <th>Unit No. = Total Lecture</th>
                        </tr>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                     <?php echo e($subject->subject->short_name.'/'.$subject->subject->student_class->program->name.'/'.$subject->subject->student_class->sem.'/'.$subject->subject->student_class->devision.'/'.$subject->subject->student_class->year); ?>

                                                    </td>
                                                   <td>
                           <?php
    // Initialize unit counters
    $unit_total = 0;
    $a1 = $a2 = $a3 = $a4 = $a5 = $a6 = 0;
    $id=[];
    foreach ($units as $unit) {
        $id=$unit;
        break;
    }
     foreach ($units as $unit){
     if($id->student_id==$unit->student_id && $subject->id == $unit->staff_id){
                
            if ($unit->unit == 1) $a1++;
            if ($unit->unit == 2) $a2++;
            if ($unit->unit == 3) $a3++;
            if ($unit->unit == 4) $a4++;
            if ($unit->unit == 5) $a5++;
            if ($unit->unit == 6) $a6++;
            
            
        }
     }

    // Prepare output
    $unitOutput = [];
    if ($a1 > 0) $unitOutput[] = "unit 1 = " . $a1;
    if ($a2 > 0) $unitOutput[] = "unit 2 = " . $a2;
    if ($a3 > 0) $unitOutput[] = "unit 3 = " . $a3;
    if ($a4 > 0) $unitOutput[] = "unit 4 = " . $a4;
    if ($a5 > 0) $unitOutput[] = "unit 5 = " . $a5;
    if ($a6 > 0) $unitOutput[] = "unit 6 = " . $a6;
?>

<?php if(!empty($unitOutput)): ?>
    <?php echo implode('<br>', $unitOutput); ?>

<?php else: ?>
    No unit data available.
<?php endif; ?>

                        </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                     </table>
                    
                    
    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/CDasboard.blade.php ENDPATH**/ ?>