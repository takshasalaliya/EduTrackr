

<?php $__env->startSection('title', 'Add Students (Bulk Upload)'); ?>
 

<?php $__env->startSection('add_form'); ?>


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Add Students - Bulk Upload via Excel</h1>
    <div>
        <a href="https://docs.google.com/spreadsheets/d/13x9mSTJKIwwvh4rqK7FR_D7mCiCx7P8v/edit?usp=sharing&ouid=109161218020310229957&rtpof=true&sd=true" target="_blank" class="btn btn-outline-success">
            <i class="bi bi-file-earmark-spreadsheet me-2"></i>Download Sample Excel File
        </a>
        
        
    </div>
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo session('success'); ?> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo session('error'); ?> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-6"> 
            <div class="card card-custom">
                <div class="card-header">
                    <i class="bi bi-file-earmark-arrow-up-fill me-2"></i>Upload Student Data Excel
                </div>
                <div class="card-body p-4">
                    <p class="text-muted">
                        Use this form to add multiple students to the system by uploading an Excel file.
                        Please ensure your file adheres to the structure and format of the
                        <a href="https://docs.google.com/spreadsheets/d/13x9mSTJKIwwvh4rqK7FR_D7mCiCx7P8v/edit?usp=sharing&ouid=109161218020310229957&rtpof=true&sd=true" target="_blank">sample Excel file</a>.
                    </p>
                    <hr>
                    <form action="<?php echo e(url('add_student_excel_admin')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="excel_file_upload" class="form-label">Select Excel File <span class="text-danger">*</span></label>
                            <input type="file" class="form-control <?php $__errorArgs = ['excel_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="excel_file" id="excel_file_upload" required accept=".xlsx, .xls, .csv">
                            <?php $__errorArgs = ['excel_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-text">Accepted file types: .xlsx, .xls, .csv</div>
                        </div>

                        <div class="d-grid"> 
                            <button class="btn btn-primary btn-lg" type="submit">
                                <i class="bi bi-upload me-2"></i>Upload and Process File
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/add_student.blade.php ENDPATH**/ ?>