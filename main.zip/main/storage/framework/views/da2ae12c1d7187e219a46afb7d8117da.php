
<?php $__env->startSection('title', 'Subject and Teaching Staff'); ?>
<?php $__env->startSection('teachingstaff'); ?>

<head>
    <style>
        .gradient-custom {
            background: #ffffff;
        }

        .card-registration .select-input.form-control[readonly]:not([disabled]) {
            font-size: 1rem;
            line-height: 2.15;
            padding-left: .75em;
            padding-right: .75em;
        }

        .card-registration .select-arrow {
            top: 13px;
        }
    </style>
</head>

<body>
    <section class="vh-100 gradient-custom">
        <div>
            <div>
                <div>
                    <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
                        <div class="card-body p-4 p-md-5">
                            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Subject Techer Maping</h3>
                            <?php if(session('success')): ?>
                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                                    <use xlink:href="#check-circle-fill" />
                                </svg>
                                <div>
                                    <?php echo e(session('success')); ?>

                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Error:">
                                    <use xlink:href="#exclamation-circle-fill" />
                                </svg>
                                <div>
                                    <?php echo e(session('error')); ?>

                                </div>
                            </div>
                            <?php endif; ?>

                            <form action="subjectallocated" method="GET">
                                <?php echo csrf_field(); ?>

                                <label for="program">Program</label>
                                <select name="program" id="program" onchange="this.form.submit()">
                                    <option value="">Select Program</option>
                                    <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($program->coundelor_id==Auth::user()->id): ?>
                                    <option value="<?php echo e($program->program->program_id); ?>" <?php echo e(request('program')==$program->program->program_id?'selected':''); ?>><?php echo e($program->program->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($sem): ?>
                                <label for="semester">Semester</label>
                                <select name="sem" id="sem" onchange="this.form.submit()">
                                    <option value="">Select Semester</option>
                                    <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($sem->coundelor_id == Auth::user()->id): ?>
                                    <option value="<?php echo e($sem->sem); ?>" <?php echo e(request('sem')==$sem->sem?'selected':''); ?>>Semester<?php echo e($sem->sem); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>

                                <?php if($year): ?>
                                <label for="year">Batch</label>
                                <select name="year" id="year" onchange="this.form.submit()">
                                    <option value="">Select Year</option>
                                    <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($year->coundelor_id==Auth::user()->id): ?>
                                    <?php
                                    $ye=$year->year;
                                    $ye=explode('/',$ye);
                                    $year1=explode('-',$ye[0]);
                                    $year2=explode('-',$ye[1]);
                                    ?>
                                    <option value="<?php echo e($year->year); ?>" <?php echo e(request('year')==$year->year?'selected' : ''); ?>><?php echo e($year1[0].'/'.$year2[0]); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php endif; ?>

                                <?php if($devision): ?>
                                <label for="devision">Devision</label>
                                <select name="devision" id="devision" onchange="this.form.submit()">
                                    <option value="">Select Devision</option>
                                    <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($devision->coundelor_id == Auth::user()->id): ?>
                                    <option value="<?php echo e($devision->devision); ?>" <?php echo e(request('devision')==$devision->devision?'selected':''); ?>><?php echo e($devision->devision); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>

                                <?php if($teacher): ?>
                                <label for="teacher">Teacher</label>
                                <select name="teacher" id="teacher" onchange="this.form.submit()">
                                    <option value="">Select Teacher</option>
                                    <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($teacher->role != 'admin' && $teacher->role != 'student'): ?>
                                    <option value="<?php echo e($teacher->id); ?>" <?php echo e(request('teacher')==$teacher->id?'selected':''); ?>><?php echo e($teacher->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>   
                                <?php endif; ?>
                            </form>

                            <?php if($class_id): ?>
                            <form action="/subjectallocated" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="number" value="<?php echo e(request('teacher')); ?>" name="teacher" hidden>
                                <label for="subject">Subject</label>
                                <br>
                                <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($subject->class_id == $class_id): ?>
                                <label for="<?php echo e($subject->subject_id); ?>"><?php echo e($subject->subject_name.'/'.$subject->subject_code); ?></label>
                                <input type="checkbox" value="<?php echo e($subject->subject_id); ?>" name="subject[]" id="<?php echo e($subject->subject_id); ?>">
                                <br>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="submit" class="submit">
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/counselor/subject_allocated.blade.php ENDPATH**/ ?>