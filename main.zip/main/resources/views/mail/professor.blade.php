<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{$subject}}</title>
</head>
<body>
    <p>Name:- <b>{{ $name }}</b></p>
    <p>Phone:- <b>{{ $phone }}</b></p>
    <p>Short Name:- <b>{{ $shortname }}</b></p>
    <p>Counselor Statues:- <b>{{ $counselor }}</b></p>
    <p>Password(For Login):- <b>{{ $password }}</b></p>
</body>
</html>