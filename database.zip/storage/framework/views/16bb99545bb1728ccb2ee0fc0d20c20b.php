 

<?php $__env->startSection('title', 'Add New Activity'); ?>
<?php $__env->startSection('page_title', 'Log New Student Activity'); ?>

<?php $__env->startSection('content'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Log details of a new student activity or event.</p>
    </div>
    
    
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo session('success'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo session('error'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('/activity')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            
            <div class="col-lg-7 mb-4">
                <div class="card card-custom">
                    <div class="card-header">
                        <i class="bi bi-calendar-event-fill me-2"></i>Activity Details
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-12">
                                <label for="activity_name" class="form-label">Activity Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['activity_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="activity_name" name="activity_name" value="<?php echo e(old('activity_name')); ?>" placeholder="e.g., Seminar on Career Development" required>
                                <?php $__errorArgs = ['activity_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="date_from" class="form-label">From Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['date_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date_from" name="date_from" value="<?php echo e(old('date_from', date('Y-m-d'))); ?>" required>
                                <?php $__errorArgs = ['date_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="date_to" class="form-label">To Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['date_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date_to" name="date_to" value="<?php echo e(old('date_to', date('Y-m-d'))); ?>" required>
                                <?php $__errorArgs = ['date_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="session_number" class="form-label">Session Number (if applicable)</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['session_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="session_number" name="session_number" value="<?php echo e(old('session_number')); ?>" placeholder="e.g., 1, 2" min="1">
                                <?php $__errorArgs = ['session_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-5 mb-4">
                <div class="card card-custom">
                    <div class="card-header">
                        <i class="bi bi-people-fill me-2"></i>Select Participating Students <span class="text-danger">*</span>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-search"></i></span>
                                <input type="text" id="studentSearchInput" class="form-control" placeholder="Search by Name or Enrollment No...">
                            </div>
                        </div>

                        <div id="studentListContainer" class="border p-2 rounded" style="max-height: 350px; overflow-y: auto;">
                            <?php if(isset($students) && $students->count() > 0): ?> 
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check student-list-item mb-1">
                                    <input class="form-check-input student-checkbox <?php $__errorArgs = ['selected_students'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="selected_students[]" value="<?php echo e($student->student_id); ?>" id="student_<?php echo e($student->student_id); ?>">
                                    <label class="form-check-label" for="student_<?php echo e($student->student_id); ?>">
                                        <span class="student-name"><?php echo e($student->name); ?></span>
                                        <small class="text-muted">(Enroll: <?php echo e($student->enrollment_number); ?>) - <?php echo e($student->class->program->name ?? 'N/A'); ?> Sem <?php echo e($student->class->sem ?? 'N/A'); ?></small>
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-muted m-0">No students found. Please ensure students are added to your classes.</p>
                            <?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['selected_students'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text mt-2">Select all students who participated in this activity.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12 text-center mt-3">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="bi bi-plus-lg me-2"></i>Log Activity
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('studentSearchInput');
    const studentListContainer = document.getElementById('studentListContainer');
    const studentItems = studentListContainer ? studentListContainer.querySelectorAll('.student-list-item') : [];

    if (searchInput) {
        searchInput.addEventListener('keyup', function () {
            const filter = this.value.toLowerCase().trim();

            studentItems.forEach(function (item) {
                const studentName = item.querySelector('.student-name').textContent.toLowerCase();
                const labelText = item.querySelector('label').textContent.toLowerCase(); // Search entire label text

                if (labelText.includes(filter)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }
});
</script>

<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/activityform.blade.php ENDPATH**/ ?>