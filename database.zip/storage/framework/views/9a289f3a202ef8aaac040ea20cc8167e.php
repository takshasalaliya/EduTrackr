<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($subject); ?></title>
</head>
<body>
    <p>Name:- <b><?php echo e($name); ?></b></p>
    <p>Phone:- <b><?php echo e($phone); ?></b></p>
    <p>Short Name:- <b><?php echo e($shortname); ?></b></p>
    <p>Counselor Statues:- <b><?php echo e($counselor); ?></b></p>
    <p>Password(For Login):- <b><?php echo e($password); ?></b></p>
</body>
</html><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/mail/professor.blade.php ENDPATH**/ ?>