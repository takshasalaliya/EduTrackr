<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<center><img src="https://i.ibb.co/yFhzNxBJ/3-removebg-preview.png" alt="Semcom" width=50%></center>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white text-center">
                        <h4>User Details</h4>
                    </div>
                    <div class="card-body">
                        <!-- Display messages -->
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(session('error')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <!-- User Information -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Roll Number:</label>
                            <p class="form-control-plaintext"><?php echo e($data->enrollment_number); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Name:</label>
                            <p class="form-control-plaintext"><?php echo e($data->name); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Class/Semester:</label>
                            <p class="form-control-plaintext"><?php echo e($data->class->program->name.'/'.$data->class->sem); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Batch:</label>
                           
                            <p class="form-control-plaintext"><?php echo e($data->class->year); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Division:</label>
                            <p class="form-control-plaintext"><?php echo e($data->class->devision); ?></p>
                        </div>

                        <!-- Form -->
                        <form action="code_enter" method="get">
                            <div class="mb-3">
                                <label for="code" class="form-label">Enter Code</label>
                                <input type="number" class="form-control" name="code" id="code" placeholder="Enter your code" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>

                       <hr class="my-4">

<h5 class="text-center mb-3">Subjects</h5>

<table class="table table-bordered">
    <thead class="table-light">
        <tr>
            <th>Subject Name</th>
            <th>Total Lecture</th>
            <th>Leacture Attend</th>
            <th>Percentage</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $attend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $atte=explode('@',$atte);
        ?>
        <tr>
            <td><?php echo e($atte[0]); ?></td>
            <td><?php echo e($atte[3]); ?></td>
            <td><?php echo e($atte[1]); ?></td>
            <td><?php echo e($atte[2]); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <th>Total</th>
             <td><?php echo e($lecture); ?></td>
             <td><?php echo e($present); ?></td>
             <td><?php echo e($present==0?'0':number_format(($present/$lecture)*100,2)); ?></td>
         </tr>
    </tbody>
    
</table>


                        <div class="text-center">
                            <a href="/logout" class="btn btn-outline-danger">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/user/enter_code.blade.php ENDPATH**/ ?>