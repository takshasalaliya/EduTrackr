<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h4>Attendance Details</h4>
            </div>
            <div class="card-body">
                <!-- Subject Info -->
                <div class="mb-3">
                    <h5><strong>Subject Name:</strong> <?php echo e($subject); ?></h5>
                </div>
                <div class="mb-3">
                    <strong>Faculty Name(s):</strong>
                    <ul>
                        <?php $__currentLoopData = $facluty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($faculty); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- Attendance Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Status (A/P)</th>
                                <th>Marked By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $attend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($attendance==NULL): ?>
                            continue;
                            <?php endif; ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($attendance->created_at)->format('d-m-Y')); ?></td>
                                    <td><?php echo e($attendance->attendance); ?></td>
                                    <td><?php echo e($attendance->teaching_staff->teacher->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted">No attendance records available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Back Button -->
                <div class="text-center mt-4">
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Back</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/user/view_attendent.blade.php ENDPATH**/ ?>