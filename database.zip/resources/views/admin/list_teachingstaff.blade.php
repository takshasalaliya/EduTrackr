@extends('admin.layout')

@section('title', 'Teacher-Subject Assignments List')
{{-- @section('page_title', 'View Teacher-Subject Assignments') --}} {{-- Keeping this commented --}}

@section('subject_table') {{-- Keeping this section name as per your usage --}}

{{-- Manual Page Header --}}
<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Teacher-Subject Assignments</h1>
    <div>
        <a href="{{ url('subjectallocated_admin') }}" class="btn btn-primary"> {{-- Assuming this is the route for assigning subjects --}}
            <i class="bi bi-link-45deg me-2"></i>Assign Subject to Teacher
        </a>
    </div>
</div>

<div class="container-fluid">

    {{-- Session Messages --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card card-custom">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <i class="bi bi-person-check-fill me-2"></i>Assigned Subjects List
            </div>
            <form action="{{ url('teachingstaff_list_filter_admin') }}" method="get" class="d-flex align-items-center ms-auto">
                <label for="filter_teacher" class="form-label me-2 mb-0 visually-hidden">Filter by Teacher:</label>
                <select name="teacher" id="filter_teacher" class="form-select form-select-sm" onchange="this.form.submit()" style="min-width: 220px;">
                    <option value="all" {{ ($select ?? 'all') == 'all' ? 'selected' : '' }}>All Teachers</option>
                    @if(isset($teacher) && count($teacher) > 0) {{-- Assuming you pass $teacher_list from controller --}}
                        @foreach($teacher as $teacher_item)
                            @if($teacher_item->role != 'admin' && $teacher_item->role != 'student')
                            <option value="{{ $teacher_item->id }}" {{ ($select ?? '') == $teacher_item->id ? 'selected' : '' }}>{{ $teacher_item->name }} ({{ $teacher_item->short_name ?? '' }})</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </form>
        </div>
        <div class="card-body p-0">
            @if(isset($teachingstaffs) && $teachingstaffs->count() > 0)
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Subject Name</th>
                            <th scope="col">Subject Code</th>
                            <th scope="col">Teacher Name</th>
                            <th scope="col">Teacher Email</th>
                            <th scope="col">Assigned Class for Subject</th>
                            <th scope="col">Last Updated (Assignment)</th>
                            <th scope="col" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($teachingstaffs as $index => $assignment) {{-- Renamed $data to $assignment --}}
                        <tr>
                            <td>{{ $index + 1 + ($teachingstaffs instanceof \Illuminate\Pagination\LengthAwarePaginator ? ($teachingstaffs->currentPage() - 1) * $teachingstaffs->perPage() : 0) }}</td>
                            <td>{{ $assignment->subject->subject_name ?? 'N/A' }}</td>
                            <td>{{ $assignment->subject->subject_code ?? 'N/A' }}</td>
                            <td>{{ $assignment->teacher->name ?? 'N/A' }} ({{ $assignment->teacher->short_name ?? '' }})</td>
                            <td>{{ $assignment->teacher->email ?? 'N/A' }}</td>
                            <td>
                                @if($assignment->class_instance) {{-- Assuming the assignment model has a 'class_instance' relationship to the specific class this subject is taught in by this teacher --}}
                                    {{ $assignment->class_instance->program->name ?? 'N/A Program' }} /
                                    Sem {{ $assignment->class_instance->sem ?? 'N/A' }} /
                                    Div {{ $assignment->class_instance->devision ?? 'N/A' }}
                                    (Batch: {{ $assignment->class_instance->year ?? 'N/A' }})
                                @elseif($assignment->subject->student_class) {{-- Fallback to subject's primary class if direct assignment class isn't available --}}
                                    {{ $assignment->subject->student_class->program->name ?? 'N/A Program' }} /
                                    Sem {{ $assignment->subject->student_class->sem ?? 'N/A' }} /
                                    Div {{ $assignment->subject->student_class->devision ?? 'N/A' }}
                                    (Batch: {{ $assignment->subject->student_class->year ?? 'N/A' }})
                                @else
                                    Class info not specified
                                @endif
                            </td>
                            <td>{{ $assignment->updated_at ? $assignment->updated_at->format('d M Y, h:i A') : 'N/A' }}</td>
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Assignment"
                                        data-bs-toggle="modal" data-bs-target="#deleteAssignmentModal"
                                        data-assignment-id="{{ $assignment->id }}"
                                        data-assignment-info="Subject: {{ $assignment->subject->subject_name ?? 'N/A' }} to Teacher: {{ $assignment->teacher->name ?? 'N/A' }}">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            @else
            <div class="text-center p-4">
                <i class="bi bi-person-video3 display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">
                    @if(($select ?? 'all') != 'all')
                        No subject assignments found for the selected teacher.
                    @else
                        No subject assignments found.
                    @endif
                </p>
                 @if(($select ?? 'all') != 'all')
                    <p class="small text-muted mt-2">Try selecting "All Teachers" in the filter.</p>
                @else
                     <p class="small text-muted mt-2">You can <a href="{{ url('subjectallocated_admin') }}">assign subjects to teachers</a> to populate this list.</p>
                @endif
            </div>
            @endif
        </div>
        @if(isset($teachingstaffs) && $teachingstaffs instanceof \Illuminate\Pagination\LengthAwarePaginator && $teachingstaffs->hasPages())
        <div class="card-footer bg-light border-top-0">
            {{ $teachingstaffs->appends(request()->query())->links() }}
        </div>
        @endif
    </div>
</div>

<!-- Delete Assignment Confirmation Modal -->
<div class="modal fade" id="deleteAssignmentModal" tabindex="-1" aria-labelledby="deleteAssignmentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteAssignmentModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this assignment: <strong id="assignmentInfoToDelete"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteAssignmentForm" method="get" action=""> {{-- Action will be set by JS --}}
           
            <button type="submit" class="btn btn-danger">Yes, Delete Assignment</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteAssignmentModal = document.getElementById('deleteAssignmentModal');
    if (deleteAssignmentModal) {
        deleteAssignmentModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var assignmentId = button.getAttribute('data-assignment-id');
            var assignmentInfo = button.getAttribute('data-assignment-info');

            var modalBodyStrong = deleteAssignmentModal.querySelector('#assignmentInfoToDelete');
            var deleteForm = deleteAssignmentModal.querySelector('#deleteAssignmentForm');

            modalBodyStrong.textContent = assignmentInfo;

            // For your current GET route: '{{ url("delete_staff_admin") }}/' + assignmentId;
            // For RESTful DELETE (recommended): '{{ url("/admin/teacher-subject-assignments") }}/' + assignmentId;
            deleteForm.action = 'delete_staff_admin/' + assignmentId; // Using your current GET route

            // If using GET, remove method spoofing and set form method to GET
            const methodInput = deleteForm.querySelector('input[name="_method"]');
            if (methodInput) {
                methodInput.remove();
            }
            deleteForm.method = 'GET';
        });
    }
});
</script>
