 

<?php $__env->startSection('title', 'Mark Attendance'); ?>
<?php $__env->startSection('page_title', 'Mark Student Attendance'); ?>

<?php $__env->startSection('attendent'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <a href="<?php echo e(url('select_counselor')); ?>" class="btn btn-outline-secondary"> 
            <i class="bi bi-arrow-left-circle me-2"></i>Change Selection
        </a>
    </div>
    
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-9"> 
            <div class="card card-custom">
                <div class="card-header text-center">
                    <h4 class="mb-0"><i class="bi bi-calendar-check-fill me-2"></i>Fill Attendance</h4>
                </div>
                <div class="card-body p-4">
                    <?php
                        $headerInfoDisplayed = false;
                        $currentSubjectAssignment = null;
                        if (isset($datas) && isset($pervious->subject)) {
                            foreach($datas as $data_item) {
                                if($data_item->id == $pervious->subject) {
                                    $currentSubjectAssignment = $data_item;
                                    break;
                                }
                            }
                        }
                    ?>

                    <?php if($currentSubjectAssignment): ?>
                        <div class="alert alert-info mb-4">
                            <h5 class="alert-heading">Lecture Details:</h5>
                            <p class="mb-1">
                                <strong>Class:</strong>
                                <?php echo e($currentSubjectAssignment->subject->student_class->program->name ?? 'N/A'); ?> /
                                Batch: <?php echo e($currentSubjectAssignment->subject->student_class->year ?? 'N/A'); ?> /
                                Sem: <?php echo e($currentSubjectAssignment->subject->student_class->sem ?? 'N/A'); ?> /
                                Div: <?php echo e($currentSubjectAssignment->subject->student_class->devision ?? 'N/A'); ?>

                            </p>
                            <p class="mb-1"><strong>Subject:</strong> <?php echo e($currentSubjectAssignment->subject->subject_name ?? 'N/A'); ?> (<?php echo e($currentSubjectAssignment->subject->subject_code ?? 'N/A'); ?>)</p>
                            <p class="mb-1"><strong>Teacher:</strong> <?php echo e($currentSubjectAssignment->teacher->name ?? 'N/A'); ?></p>
                            <p class="mb-0">
                                <strong>Unit:</strong> <?php echo e($pervious->unit ?? 'N/A'); ?> |
                                <strong>Lecture No:</strong> <?php echo e($pervious->leacture ?? 'N/A'); ?> | 
                                <strong>Date:</strong> <?php echo e(isset($pervious->date) ? \Carbon\Carbon::parse($pervious->date)->format('d M Y') : 'N/A'); ?>

                            </p>
                        </div>
                        <?php $headerInfoDisplayed = true; ?>
                    <?php else: ?>
                        <div class="alert alert-warning">Could not load lecture details based on previous selection.</div>
                    <?php endif; ?>

                    <?php if($headerInfoDisplayed && isset($attendent) && $attendent == 'yes'): ?>
                        <form action="<?php echo e(url('final_attendent_counselor')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="staff_id" value="<?php echo e($pervious->subject ?? ''); ?>">
                            <input type="hidden" name="leacture" value="<?php echo e($pervious->leacture ?? ''); ?>"> 
                            <input type="hidden" name="date" value="<?php echo e($pervious->date ?? ''); ?>">
                            <input type="hidden" name="unit" value="<?php echo e($pervious->unit ?? ''); ?>">

                            <div class="mb-3 d-flex justify-content-end">
                                <button type="button" id="markAllPresentBtn" class="btn btn-sm btn-outline-success me-2"><i class="bi bi-check2-all"></i> Mark All Present</button>
                                <button type="button" id="markAllAbsentBtn" class="btn btn-sm btn-outline-danger"><i class="bi bi-x-lg"></i> Mark All Absent</button>
                            </div>

                            <?php $studentCount = 0; ?>

                            
                            <?php if($yes): ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($currentSubjectAssignment->subject->class_id == $student_item->class_id): ?>
                                        <?php $studentCount++; ?>
                                        <div class="row align-items-center mb-2 py-2 border-bottom student-attendance-row">
                                            <div class="col-md-1 text-end"><?php echo e($studentCount); ?>.</div>
                                            <div class="col-md-7 student-name-display">
                                                <?php echo e($student_item->name); ?> (<?php echo e($student_item->enrollment_number); ?>)
                                            </div>
                                            <div class="col-md-4 text-md-end text-center">
                                                <input type="hidden" name="student[]" value="<?php echo e($student_item->student_id); ?>">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="attendance_status[<?php echo e($student_item->student_id); ?>]" value="present" id="p_<?php echo e($student_item->student_id); ?>" required>
                                                    <label class="form-check-label" for="p_<?php echo e($student_item->student_id); ?>">Present</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="attendance_status[<?php echo e($student_item->student_id); ?>]" value="absent" id="a_<?php echo e($student_item->student_id); ?>" required>
                                                    <label class="form-check-label" for="a_<?php echo e($student_item->student_id); ?>">Absent</label>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            
                            <?php if(isset($optional)): ?>
                                <?php $__currentLoopData = $optional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optional_student_assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($optional_student_assignment && isset($optional_student_assignment->student)): ?>
                                        <?php $studentCount++; ?>
                                        <div class="row align-items-center mb-2 py-2 border-bottom student-attendance-row">
                                             <div class="col-md-1 text-end"><?php echo e($studentCount); ?>.</div>
                                            <div class="col-md-7 student-name-display">
                                                <?php echo e($optional_student_assignment->student->name); ?> (<?php echo e($optional_student_assignment->student->enrollment_number); ?>)
                                                <span class="badge bg-info text-dark ms-2">Optional</span>
                                            </div>
                                            <div class="col-md-4 text-md-end text-center">
                                                <input type="hidden" name="student[]" value="<?php echo e($optional_student_assignment->student->student_id); ?>">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="attendance_status[<?php echo e($optional_student_assignment->student->student_id); ?>]" value="present" id="p_opt_<?php echo e($optional_student_assignment->student->student_id); ?>" required>
                                                    <label class="form-check-label" for="p_opt_<?php echo e($optional_student_assignment->student->student_id); ?>">Present</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="attendance_status[<?php echo e($optional_student_assignment->student->student_id); ?>]" value="absent" id="a_opt_<?php echo e($optional_student_assignment->student->student_id); ?>" required>
                                                    <label class="form-check-label" for="a_opt_<?php echo e($optional_student_assignment->student->student_id); ?>">Absent</label>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="text-danger mt-2 mb-2 d-block">⚠️ <?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['attendance_status.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="text-danger mt-2 mb-2 d-block">⚠️ <?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                            <?php if($studentCount == 0): ?>
                                <div class="alert alert-warning text-center mt-3">
                                    <i class="bi bi-exclamation-circle-fill me-2"></i>
                                    No students are mapped to this subject/class combination for attendance, or all students are from optional subjects and none opted. Please check student-class and student-optional subject mappings.
                                </div>
                            <?php else: ?>
                                <div class="mt-4 pt-2 text-center">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        <i class="bi bi-check-lg me-2"></i>Submit Attendance
                                    </button>
                                </div>
                            <?php endif; ?>
                        </form>
                    <?php elseif(isset($attendent) && $attendent == 'no'): ?>
                        <div class="alert alert-danger text-center">
                            <h4 class="alert-heading"><i class="bi bi-calendar-x-fill me-2"></i>Attendance Already Submitted!</h4>
                            <p>Attendance has already been taken for this subject, unit, lecture, and date.</p>
                            <hr>
                            <p class="mb-0">If you need to make changes, please use the "Edit Attendance" option from the selection page.</p>
                        </div>
                    <?php elseif(!$headerInfoDisplayed): ?>
                        <div class="alert alert-danger text-center">
                             <h4 class="alert-heading"><i class="bi bi-exclamation-triangle-fill me-2"></i>Selection Error!</h4>
                             <p>Could not load details for the selected subject/lecture. Please go back and try selecting again.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const markAllPresentBtn = document.getElementById('markAllPresentBtn');
    const markAllAbsentBtn = document.getElementById('markAllAbsentBtn');
    const studentRows = document.querySelectorAll('.student-attendance-row');

    if (markAllPresentBtn) {
        markAllPresentBtn.addEventListener('click', function() {
            studentRows.forEach(row => {
                const presentRadio = row.querySelector('input[type="radio"][value="present"]');
                if (presentRadio) {
                    presentRadio.checked = true;
                }
            });
        });
    }

    if (markAllAbsentBtn) {
        markAllAbsentBtn.addEventListener('click', function() {
            studentRows.forEach(row => {
                const absentRadio = row.querySelector('input[type="radio"][value="absent"]');
                if (absentRadio) {
                    absentRadio.checked = true;
                }
            });
        });
    }
});
</script>

<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/main_attendent.blade.php ENDPATH**/ ?>