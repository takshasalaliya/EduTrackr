

<?php $__env->startSection('title', 'Optional Subject Maping'); ?>
<?php $__env->startSection('optional_subject'); ?>

<head>
    <style>.gradient-custom {
/* fallback for old browsers */
background: #ffffff;

/* Chrome 10-25, Safari 5.1-6 */
background: #ffffff;

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: #ffffff;
}

.card-registration .select-input.form-control[readonly]:not([disabled]) {
font-size: 1rem;
line-height: 2.15;
padding-left: .75em;
padding-right: .75em;
}
.card-registration .select-arrow {
top: 13px;
}</style>
</head>
<body>


<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Optional Subject</h3>
            <?php if(session('success')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
              <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                <use xlink:href="#check-circle-fill"/>
              </svg>
              <div>
                <?php echo e(session('success')); ?>

              </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
  <div>
    <?php echo e(session('error')); ?>

  </div>

</div>
<?php endif; ?>


<form action="optionalgroup_admin" method="get">

    <select name="field" id="field" onchange="this.form.submit()">
                  <option value="">Select Program</option>
                  <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                 
                  
                  <option value="<?php echo e($program->program->program_id); ?>" <?php echo e($program->program->program_id == request('field') ? 'selected' : ''); ?>><?php echo e($program->program->name); ?></option>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
    <?php if($sem): ?>
    <select name="sem" id="sem" onchange="this.form.submit()">
        <option value="">Select Semester</option>
        <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <option value="<?php echo e($sem->sem); ?>" <?php echo e($sem->sem==request('sem') ? 'selected':''); ?>><?php echo e('Semester'.$sem->sem); ?></option>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
    <?php if($year): ?>
    <select name="year" id="year" onchange="this.form.submit()">
        <option value="">Select Year</option>
        <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        <option value="<?php echo e($year->year); ?>" <?php echo e($year->year==request('year') ? 'selected':''); ?>><?php echo e($year->year); ?></option>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
    <?php if($devision): ?>
    <select name="devision" id="devision" onchange="this.form.submit()">
        <option value="">Select Devision</option>
        <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <option value="<?php echo e($devision->devision); ?>" <?php echo e($devision->devision==request('devision') ? 'selected':''); ?>><?php echo e($devision->devision); ?></option>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
</form>

            <?php if($valid): ?>
            <form action="optionalgroup_admin" method="post"> 
                <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-md-6 mb-4">

                  <div data-mdb-input-init class="form-outline">
                  <label class="form-label" for="subject">Subject Name</label><br>
                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($subject->subject_name); ?>  <input type="checkbox" name="subject[]" value="<?php echo e($subject->subject_id); ?>" id="subject">
                    <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="alert"><?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
                <div class="col-md-6 mb-4">

                  <div data-mdb-input-init class="form-outline">
                  <label class="form-label" for="student">Student Name</label><br>
                  <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($student->optional =='no'): ?>
                  
                    <?php echo e($student->name); ?>/<?php echo e($student->enrollment_number); ?> <input type="checkbox" name="student[]" value="<?php echo e($student->student_id); ?>" id="student">
                    <br>
                  <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="alert"><?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
              </div>


              

           
              <div class="mt-4 pt-2">
                <input data-mdb-ripple-init class="btn btn-primary btn-lg" type="submit" value="Submit" />
              </div>

            </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/admin/optional_subject_group.blade.php ENDPATH**/ ?>