
<?php $__env->startSection('title','Edit Attendent'); ?>
<?php $__env->startSection('edit_attendent'); ?>

<head>
    <style>
        .gradient-custom {
            background: #f7f9fc;
        }

        .card-registration {
            border-radius: 15px;
        }

        .user-box {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #fff;
        }

        label {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 0;
        }

        input[type="radio"] {
            margin-left: 10px;
            margin-right: 5px;
        }

        .alert {
            font-size: 14px;
        }

        .student-label {
            font-size: 18px;
            font-weight: bold;
            word-wrap: break-word;
        }

        @media (max-width: 768px) {
            .student-label {
                font-size: 16px;
            }

            label {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <section class="vh-100 gradient-custom">
        <div class="container py-5 h-100">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="card shadow-2-strong card-registration">
                        <div class="card-body p-4 p-md-5">
                            <h3 class="mb-4">Edit Attendance</h3>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data->id == $pervious->subject): ?>
                                    <div class="mb-4">
                                        <h6>
                                            <strong>Class:</strong> <?php echo e($data->subject->student_class->program->name); ?>/<?php echo e($data->subject->student_class->year); ?>/<?php echo e($data->subject->student_class->sem); ?><br>
                                            <strong>Division:</strong> <?php echo e($data->subject->student_class->devision); ?><br>
                                            <strong>Subject:</strong> <?php echo e($data->subject->subject_name); ?><br>
                                            <strong>Teacher:</strong> <?php echo e($data->teacher->name); ?><br>
                                            <strong>Lecture Number:</strong> <?php echo e($pervious->leacture); ?><br>
                                            <strong>Unit:</strong> <?php echo e($pervious->unit); ?><br>
                                            <strong>Date:</strong> <?php echo e($pervious->date); ?>

                                        </h6>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <form action="edit_attendendent_counselor" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <?php if($attendent): ?>
                                        <?php $__currentLoopData = $attendent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12">
                                                <div class="user-box">
                                                    <span class="student-label"><?php echo e(++$sum); ?>. <?php echo e($data->student->name); ?></span>
                                                    <input type="text" value="<?php echo e($data->student->student_id); ?>" name="student[]" hidden>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="<?php echo e($data->student->student_id); ?>" value="present" id="<?php echo e($sum.'p'); ?>" <?php echo e($data->attendance == 'present' ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="<?php echo e($sum.'p'); ?>">P</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="<?php echo e($data->student->student_id); ?>" value="absent" id="<?php echo e($sum.'a'); ?>" <?php echo e($data->attendance == 'absent' ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="<?php echo e($sum.'a'); ?>">A</label>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <?php if($sum == 0): ?>
                                        <div class="col-12 text-center">
                                            <h4>No attendance to edit for this day.</h4>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <input type="text" value="<?php echo e($pervious->subject); ?>" name="staff_id" hidden>
                                <input type="text" value="<?php echo e($pervious->unit); ?>" name="unit" hidden>
                                <input type="text" value="<?php echo e($pervious->leacture); ?>" name="leacture" hidden>
                                <input type="date" value="<?php echo e($pervious->date); ?>" name="date" hidden>

                                <div class="text-center mt-4">
                                    <button class="btn btn-primary btn-lg" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/edit_attendent.blade.php ENDPATH**/ ?>