
<?php $__env->startSection('title','Attendent List'); ?>
<?php $__env->startSection('after_code_attendent'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php if($students): ?>
<table class="table">
    <tr>
        <th>Name</th>
        <th>Status</th>
    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($student->attendance=='present'): ?>
    <tr>
        <td><?php echo e($student->student->name); ?></td>
        <td><?php echo e($student->attendance); ?></td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($student->attendance=='absent'): ?>
    <tr>
        <td><?php echo e($student->student->name); ?></td>
        <td><?php echo e($student->attendance); ?></td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<h2>Make Attendent Of another Student</h2>
<?php if($duplicated): ?>
<?php $__currentLoopData = $duplicated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h5><?php echo e($data->in_class); ?> Make a Attendent Of <?php echo e($data->out_class); ?></h5><br>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<h5>No one fill any one attendent</h5>
<a href="<?php echo e('/delete_code_counselor/'.$code); ?>"><button type="button" class="btn btn-info">Delete Code</button></a>
<?php endif; ?>
<?php if($students=='no'): ?>
<h1>no data found</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/after_code_attendent.blade.php ENDPATH**/ ?>