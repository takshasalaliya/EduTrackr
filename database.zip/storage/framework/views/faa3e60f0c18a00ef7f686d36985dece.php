

<?php $__env->startSection('title', 'Teacher-Subject Assignments List'); ?>
 

<?php $__env->startSection('subject_table'); ?> 


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Teacher-Subject Assignments</h1>
    <div>
        <a href="<?php echo e(url('subjectallocated_admin')); ?>" class="btn btn-primary"> 
            <i class="bi bi-link-45deg me-2"></i>Assign Subject to Teacher
        </a>
    </div>
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card card-custom">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <i class="bi bi-person-check-fill me-2"></i>Assigned Subjects List
            </div>
            <form action="<?php echo e(url('teachingstaff_list_filter_admin')); ?>" method="get" class="d-flex align-items-center ms-auto">
                <label for="filter_teacher" class="form-label me-2 mb-0 visually-hidden">Filter by Teacher:</label>
                <select name="teacher" id="filter_teacher" class="form-select form-select-sm" onchange="this.form.submit()" style="min-width: 220px;">
                    <option value="all" <?php echo e(($select ?? 'all') == 'all' ? 'selected' : ''); ?>>All Teachers</option>
                    <?php if(isset($teacher) && count($teacher) > 0): ?> 
                        <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($teacher_item->role != 'admin' && $teacher_item->role != 'student'): ?>
                            <option value="<?php echo e($teacher_item->id); ?>" <?php echo e(($select ?? '') == $teacher_item->id ? 'selected' : ''); ?>><?php echo e($teacher_item->name); ?> (<?php echo e($teacher_item->short_name ?? ''); ?>)</option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </form>
        </div>
        <div class="card-body p-0">
            <?php if(isset($teachingstaffs) && $teachingstaffs->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Subject Name</th>
                            <th scope="col">Subject Code</th>
                            <th scope="col">Teacher Name</th>
                            <th scope="col">Teacher Email</th>
                            <th scope="col">Assigned Class for Subject</th>
                            <th scope="col">Last Updated (Assignment)</th>
                            <th scope="col" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $teachingstaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                            <td><?php echo e($index + 1 + ($teachingstaffs instanceof \Illuminate\Pagination\LengthAwarePaginator ? ($teachingstaffs->currentPage() - 1) * $teachingstaffs->perPage() : 0)); ?></td>
                            <td><?php echo e($assignment->subject->subject_name ?? 'N/A'); ?></td>
                            <td><?php echo e($assignment->subject->subject_code ?? 'N/A'); ?></td>
                            <td><?php echo e($assignment->teacher->name ?? 'N/A'); ?> (<?php echo e($assignment->teacher->short_name ?? ''); ?>)</td>
                            <td><?php echo e($assignment->teacher->email ?? 'N/A'); ?></td>
                            <td>
                                <?php if($assignment->class_instance): ?> 
                                    <?php echo e($assignment->class_instance->program->name ?? 'N/A Program'); ?> /
                                    Sem <?php echo e($assignment->class_instance->sem ?? 'N/A'); ?> /
                                    Div <?php echo e($assignment->class_instance->devision ?? 'N/A'); ?>

                                    (Batch: <?php echo e($assignment->class_instance->year ?? 'N/A'); ?>)
                                <?php elseif($assignment->subject->student_class): ?> 
                                    <?php echo e($assignment->subject->student_class->program->name ?? 'N/A Program'); ?> /
                                    Sem <?php echo e($assignment->subject->student_class->sem ?? 'N/A'); ?> /
                                    Div <?php echo e($assignment->subject->student_class->devision ?? 'N/A'); ?>

                                    (Batch: <?php echo e($assignment->subject->student_class->year ?? 'N/A'); ?>)
                                <?php else: ?>
                                    Class info not specified
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($assignment->updated_at ? $assignment->updated_at->format('d M Y, h:i A') : 'N/A'); ?></td>
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Assignment"
                                        data-bs-toggle="modal" data-bs-target="#deleteAssignmentModal"
                                        data-assignment-id="<?php echo e($assignment->id); ?>"
                                        data-assignment-info="Subject: <?php echo e($assignment->subject->subject_name ?? 'N/A'); ?> to Teacher: <?php echo e($assignment->teacher->name ?? 'N/A'); ?>">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-person-video3 display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">
                    <?php if(($select ?? 'all') != 'all'): ?>
                        No subject assignments found for the selected teacher.
                    <?php else: ?>
                        No subject assignments found.
                    <?php endif; ?>
                </p>
                 <?php if(($select ?? 'all') != 'all'): ?>
                    <p class="small text-muted mt-2">Try selecting "All Teachers" in the filter.</p>
                <?php else: ?>
                     <p class="small text-muted mt-2">You can <a href="<?php echo e(url('subjectallocated_admin')); ?>">assign subjects to teachers</a> to populate this list.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php if(isset($teachingstaffs) && $teachingstaffs instanceof \Illuminate\Pagination\LengthAwarePaginator && $teachingstaffs->hasPages()): ?>
        <div class="card-footer bg-light border-top-0">
            <?php echo e($teachingstaffs->appends(request()->query())->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Assignment Confirmation Modal -->
<div class="modal fade" id="deleteAssignmentModal" tabindex="-1" aria-labelledby="deleteAssignmentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteAssignmentModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this assignment: <strong id="assignmentInfoToDelete"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteAssignmentForm" method="get" action=""> 
           
            <button type="submit" class="btn btn-danger">Yes, Delete Assignment</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteAssignmentModal = document.getElementById('deleteAssignmentModal');
    if (deleteAssignmentModal) {
        deleteAssignmentModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var assignmentId = button.getAttribute('data-assignment-id');
            var assignmentInfo = button.getAttribute('data-assignment-info');

            var modalBodyStrong = deleteAssignmentModal.querySelector('#assignmentInfoToDelete');
            var deleteForm = deleteAssignmentModal.querySelector('#deleteAssignmentForm');

            modalBodyStrong.textContent = assignmentInfo;

            // For your current GET route: '<?php echo e(url("delete_staff_admin")); ?>/' + assignmentId;
            // For RESTful DELETE (recommended): '<?php echo e(url("/admin/teacher-subject-assignments")); ?>/' + assignmentId;
            deleteForm.action = 'delete_staff_admin/' + assignmentId; // Using your current GET route

            // If using GET, remove method spoofing and set form method to GET
            const methodInput = deleteForm.querySelector('input[name="_method"]');
            if (methodInput) {
                methodInput.remove();
            }
            deleteForm.method = 'GET';
        });
    }
});
</script>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/list_teachingstaff.blade.php ENDPATH**/ ?>