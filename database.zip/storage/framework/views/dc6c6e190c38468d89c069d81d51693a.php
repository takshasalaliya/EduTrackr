
<?php $__env->startSection('title','Teacher List'); ?>
<?php $__env->startSection('teacher'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<form action="filter_teacher_list" method="get">
    <select name="filter" id="filter" onchange="this.form.submit()">
        <option value="all" <?php echo e($select=='all'?'selected':''); ?>>All</option>
        <option value="reader" <?php echo e($select=='reader'?'selected':''); ?>>Reader</option>
        <option value="counselor" <?php echo e($select=='counselor'?'selected':''); ?>>Counselor</option>
        <option value="admin" <?php echo e($select=='admin'?'selected':''); ?>>Admin</option>
    </select>
 
</form>

<table class="table">
   <tr>
    
    <th>Name</th>
    <th>Short Name</th>
    <th>Mobile No.</th>
    <th>Email</th>
    <th>Counselor</th>
    <th>Password</th>
    <th>Last Updated</th>
    <th>Operation</th>
    </tr>
    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($teacher->name); ?></td>
        <td><?php echo e($teacher->short_name); ?></td>
        <td><?php echo e($teacher->phone_number); ?></td>
        <td><?php echo e($teacher->email); ?></td>
        <td><?php echo e($teacher->role=='counselor'?'yes':'no'); ?></td>
        <td><?php echo e($teacher->plain_password); ?></td>
        <td><?php echo e($teacher->updated_at); ?></td>
        <td>
        <a href="<?php echo e('/edit_teacher/'.$teacher->id); ?>"><button type="button" class="btn btn-info">Edit</button></a>
        <a href="<?php echo e('/delete_teacher/'.$teacher->id); ?>"><button type="button" class="btn btn-primary">Delete</button></a>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/teacher_list.blade.php ENDPATH**/ ?>