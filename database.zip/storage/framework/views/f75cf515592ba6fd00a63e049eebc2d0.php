

<?php $__env->startSection('title', 'Manage Programs'); ?>
<?php $__env->startSection('page_title', 'Manage Programs'); ?> 

<?php $__env->startSection('add_field'); ?>

<div class="container-fluid">
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-plus-circle-fill me-2"></i>Add New Program
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('field')); ?>" method="post"> 
                <?php echo csrf_field(); ?>
                <div class="row g-3 align-items-end">
                    <div class="col-md-9">
                        <label for="program_name" class="form-label">Program Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['field'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="field" id="program_name" placeholder="e.g., Bachelor of Computer Applications" value="<?php echo e(old('field')); ?>" required>
                        <?php $__errorArgs = ['field'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-save-fill me-2"></i>Save Program
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-list-ul me-2"></i>Existing Programs
        </div>
        <div class="card-body p-0">
            <?php if(isset($datas) && $datas->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Program Name</th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1 + ($datas instanceof \Illuminate\Pagination\LengthAwarePaginator ? ($datas->currentPage() - 1) * $datas->perPage() : 0)); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td class="text-center">
                                
                                
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Program"
                                        data-bs-toggle="modal" data-bs-target="#deleteProgramModal"
                                        data-program-id="<?php echo e($data->program_id); ?>" data-program-name="<?php echo e($data->name); ?>">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <p class="text-muted mb-0">No programs found. Add one using the form above.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Program Confirmation Modal -->
<div class="modal fade" id="deleteProgramModal" tabindex="-1" aria-labelledby="deleteProgramModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteProgramModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete the program: <strong id="programNameToDelete"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteProgramForm" method="get" action=""> 
            
             
            <button type="submit" class="btn btn-danger">Yes, Delete Program</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteProgramModal = document.getElementById('deleteProgramModal');
    if (deleteProgramModal) {
        deleteProgramModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var programId = button.getAttribute('data-program-id');
            var programName = button.getAttribute('data-program-name');

            var modalTitle = deleteProgramModal.querySelector('.modal-title');
            var modalBodyStrong = deleteProgramModal.querySelector('#programNameToDelete');
            var deleteForm = deleteProgramModal.querySelector('#deleteProgramForm');

            modalBodyStrong.textContent = programName;

            // Adjust the action URL based on your route definition
            // If you are using a GET request for deletion as per your original code:
            deleteForm.action = '/delete_program/' + programId;
            // If you prefer a DELETE request (recommended RESTful practice):
            // deleteForm.action = '<?php echo e(url("/programs")); ?>/' + programId;
            // And ensure your route is Route::delete('/programs/{id}', ...);
        });
    }
});
</script>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/add_program.blade.php ENDPATH**/ ?>