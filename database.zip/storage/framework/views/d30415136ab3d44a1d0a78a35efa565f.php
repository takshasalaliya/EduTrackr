 

<?php $__env->startSection('title', 'Class Attendance Summary'); ?>
<?php $__env->startSection('page_title', 'Class Attendance Summary'); ?>

<?php $__env->startSection('classattendent'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Summary of student attendance for the selected class/period.</p>
        
    </div>
    <a href="<?php echo e(url('class_pdf')); ?>" class="btn btn-danger"> 
        <i class="bi bi-file-earmark-pdf-fill me-2"></i>Download PDF
    </a>
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    
    

    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-table me-2"></i>Attendance Data
        </div>
        <div class="card-body p-0">
            <?php if(isset($datas) && count($datas) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0"> 
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Enrollment Number</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">From Date</th>
                            <th scope="col">To Date</th>
                            <th scope="col" class="text-center">Total Lectures</th>
                            <th scope="col" class="text-center">Present Lectures</th>
                            <th scope="col" class="text-center">Attendance %</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data_string): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                // Data parsing should ideally be in the controller
                                $record = explode('&', $data_string);
                                $enrollment = $record[0] ?? 'N/A';
                                $name = $record[1] ?? 'N/A';
                                $from_date = isset($record[2]) ? \Carbon\Carbon::parse($record[2])->format('d M Y') : 'N/A';
                                $to_date = isset($record[3]) ? \Carbon\Carbon::parse($record[3])->format('d M Y') : 'N/A';
                                $total_class = $record[4] ?? 0;
                                $present = $record[5] ?? 0;
                                $percentage = $record[6] ?? 0;
                            ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($enrollment); ?></td>
                                <td><?php echo e($name); ?></td>
                                <td><?php echo e($from_date); ?></td>
                                <td><?php echo e($to_date); ?></td>
                                <td class="text-center"><?php echo e($total_class); ?></td>
                                <td class="text-center"><?php echo e($present); ?></td>
                                <td class="text-center fw-bold
                                    <?php if($percentage >= 75): ?> text-success
                                    <?php elseif($percentage >= 50): ?> text-warning
                                    <?php else: ?> text-danger <?php endif; ?>">
                                    <?php echo e($percentage); ?>%
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-bar-chart-steps display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">No attendance summary data found.</p>
                <p class="small text-muted mt-2">This might be because no attendance has been recorded for the selected criteria or class.</p>
            </div>
            <?php endif; ?>
        </div>
        
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/classattendent.blade.php ENDPATH**/ ?>