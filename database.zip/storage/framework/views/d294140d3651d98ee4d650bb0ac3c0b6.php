

<?php $__env->startSection('title', 'Student - Optional Subject Mapping'); ?>
 

<?php $__env->startSection('optional_subject'); ?>


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Student - Optional Subject Mapping</h1>
    <div>
        <a href="https://docs.google.com/spreadsheets/d/1BiWllOIRSZ8PdgCa5DpGI4c-dCbhRtPm/edit?usp=sharing&ouid=109161218020310229957&rtpof=true&sd=true" target="_blank" class="btn btn-outline-success">
            <i class="bi bi-file-earmark-spreadsheet me-2"></i>Sample Excel for Bulk Assign
        </a>
    </div>
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo session('success'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert"> 
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo session('error'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-filter-circle-fill me-2"></i>Select Class to Map Optional Subjects
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('optionalgroup_admin')); ?>" method="get" id="filterOptionalSubjectForm">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label for="filter_program_field" class="form-label">Program</label>
                        <select name="field" id="filter_program_field" class="form-select" onchange="document.getElementById('filterOptionalSubjectForm').submit()">
                            <option value="">Select Program</option>
                            <?php if(isset($programs)): ?>
                                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program_item_wrapper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <?php if(isset($program_item_wrapper->program)): ?>
                                        <option value="<?php echo e($program_item_wrapper->program->program_id); ?>" <?php echo e($program_item_wrapper->program->program_id == request('field') ? 'selected' : ''); ?>>
                                            <?php echo e($program_item_wrapper->program->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <?php if(isset($sem) && count($sem) > 0): ?>
                    <div class="col-md-2">
                        <label for="filter_sem" class="form-label">Semester</label>
                        <select name="sem" id="filter_sem" class="form-select" onchange="document.getElementById('filterOptionalSubjectForm').submit()">
                            <option value="">Select Semester</option>
                            <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sem_item->sem); ?>" <?php echo e($sem_item->sem == request('sem') ? 'selected' : ''); ?>>Semester <?php echo e($sem_item->sem); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($year) && count($year) > 0): ?>
                    <div class="col-md-2">
                        <label for="filter_year" class="form-label">Batch Year</label>
                        <select name="year" id="filter_year" class="form-select" onchange="document.getElementById('filterOptionalSubjectForm').submit()">
                            <option value="">Select Year</option>
                            <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year_item->year); ?>" <?php echo e($year_item->year == request('year') ? 'selected' : ''); ?>><?php echo e($year_item->year); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($devision) && count($devision) > 0): ?>
                    <div class="col-md-2">
                        <label for="filter_devision" class="form-label">Division</label>
                        <select name="devision" id="filter_devision" class="form-select" onchange="document.getElementById('filterOptionalSubjectForm').submit()">
                            <option value="">Select Division</option>
                            <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devision_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($devision_item->devision); ?>" <?php echo e($devision_item->devision == request('devision') ? 'selected' : ''); ?>><?php echo e($devision_item->devision); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <div class="col-md-3">
                        <a href="<?php echo e(url('optionalgroup_admin')); ?>" class="btn btn-outline-secondary w-100">Reset Filters</a>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <?php if(isset($valid) && $valid): ?>
    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-ui-checks me-2"></i>Assign Optional Subjects to Students for Selected Class
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('optionalgroup_admin')); ?>" method="post">
                <?php echo csrf_field(); ?>
                
                <input type="hidden" name="field" value="<?php echo e(request('field')); ?>">
                <input type="hidden" name="sem" value="<?php echo e(request('sem')); ?>">
                <input type="hidden" name="year" value="<?php echo e(request('year')); ?>">
                <input type="hidden" name="devision" value="<?php echo e(request('devision')); ?>">

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Select Optional Subjects <span class="text-danger">*</span></label>
                        <div class="border p-2 rounded" style="max-height: 300px; overflow-y: auto;">
                            <?php if(isset($subject) && count($subject) > 0): ?>
                                <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="form-check">
                                    <input class="form-check-input <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="subject[]" value="<?php echo e($subject_item->subject_id); ?>" id="subject_<?php echo e($subject_item->subject_id); ?>"
                                           <?php echo e((is_array(old('subject')) && in_array($subject_item->subject_id, old('subject'))) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="subject_<?php echo e($subject_item->subject_id); ?>">
                                        <?php echo e($subject_item->subject_name); ?> (<?php echo e($subject_item->subject_code); ?>)
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-muted m-0">No optional subjects found for the selected class criteria.</p>
                            <?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['subject.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Select Students (who have not opted yet) <span class="text-danger">*</span></label>
                        <div class="border p-2 rounded" style="max-height: 300px; overflow-y: auto;">
                            <?php if(isset($students) && count($students) > 0): ?>
                                <?php $studentAvailable = false; ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <?php if($student_item->optional == 'no'): ?>
                                        <?php $studentAvailable = true; ?>
                                        <div class="form-check">
                                            <input class="form-check-input <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="student[]" value="<?php echo e($student_item->student_id); ?>" id="student_<?php echo e($student_item->student_id); ?>"
                                                   <?php echo e((is_array(old('student')) && in_array($student_item->student_id, old('student'))) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="student_<?php echo e($student_item->student_id); ?>">
                                                <?php echo e($student_item->name); ?> (<?php echo e($student_item->enrollment_number); ?>)
                                            </label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$studentAvailable): ?>
                                     <p class="text-muted m-0">All students in this class have already opted for subjects or no students found.</p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-muted m-0">No students found for the selected class criteria.</p>
                            <?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['student.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mt-4 pt-2">
                    <button class="btn btn-primary btn-lg" type="submit">
                        <i class="bi bi-check2-all me-2"></i>Assign Selected Subjects to Selected Students
                    </button>
                </div>
            </form>
            
            <?php if(isset($class_id_for_download) && $class_id_for_download): ?>
            <div class="mt-3">
                <a href="<?php echo e(url('/excel_dowload/'.$class_id_for_download)); ?>" class="btn btn-info">
                    <i class="bi bi-download me-2"></i>Download Current Mappings for this Class
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if(!isset($valid) || !$valid): ?>
    
    <div class="card card-custom">
        <div class="card-header">
             <i class="bi bi-file-earmark-arrow-up-fill me-2"></i>Bulk Assign Optional Subjects via Excel
        </div>
        <div class="card-body">
            <?php if(!(request('field') && request('sem') && request('year') && request('devision'))): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle-fill me-2"></i>Please select Program, Semester, Batch Year, and Division above to enable manual assignment or to proceed with targeted bulk upload for a specific class.
                </div>
            <?php endif; ?>
            <form action="<?php echo e(url('excel_optional')); ?>" method="post" enctype="multipart/form-data" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                
                <input type="hidden" name="field_excel" value="<?php echo e(request('field')); ?>">
                <input type="hidden" name="sem_excel" value="<?php echo e(request('sem')); ?>">
                <input type="hidden" name="year_excel" value="<?php echo e(request('year')); ?>">
                <input type="hidden" name="devision_excel" value="<?php echo e(request('devision')); ?>">

                <div class="col-md-8">
                    <label for="excel_optional_file" class="form-label">Upload Excel File</label>
                    <input type="file" class="form-control <?php $__errorArgs = ['excel_optional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="excel_optional_file" name="excel_optional" required accept=".xlsx, .xls, .csv">
                    <?php $__errorArgs = ['excel_optional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-success w-100" type="submit">
                        <i class="bi bi-upload me-2"></i>Upload & Process
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/optional_subject_group.blade.php ENDPATH**/ ?>