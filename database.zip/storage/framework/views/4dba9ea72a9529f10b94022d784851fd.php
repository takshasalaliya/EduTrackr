
<?php $__env->startSection('title', 'Attendance'); ?>
<?php $__env->startSection('attendent'); ?>

<head>
    <style>
        .gradient-custom {
            background: linear-gradient(to bottom right, #ffffff, #f1f1f1);
        }

        .card-registration {
            border-radius: 15px;
        }

        .alert svg {
            margin-right: 10px;
        }

        label {
            font-weight: 500;
        }

        input[type="radio"] {
            margin-left: 10px;
        }

        .student-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .student-name {
            flex-grow: 1;
            padding: 5px 10px;
            background-color: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
</head>

<body>
    <section class="vh-100 gradient-custom">
        <div class="container py-5 h-100">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-12 col-lg-9 col-xl-7">
                    <div class="card shadow-2-strong card-registration">
                        <div class="card-body p-4 p-md-5">
                            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 text-center">Fill Attendance</h3>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success d-flex align-items-center" role="alert">
                                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                                        <use xlink:href="#check-circle-fill" />
                                    </svg>
                                    <div><?php echo e(session('success')); ?></div>
                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger d-flex align-items-center" role="alert">
                                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Error:">
                                        <use xlink:href="#exclamation-triangle-fill" />
                                    </svg>
                                    <div><?php echo e(session('error')); ?></div>
                                </div>
                            <?php endif; ?>

                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data->id == $pervious->subject): ?>
                                    <h6>
                                        Class: <?php echo e($data->subject->student_class->program->name); ?>/<?php echo e($data->subject->student_class->year); ?>/<?php echo e($data->subject->student_class->sem); ?><br>
                                        Division: <?php echo e($data->subject->student_class->devision); ?><br>
                                        Subject: <?php echo e($data->subject->subject_name); ?><br>
                                        Teacher: <?php echo e($data->teacher->name); ?><br>
                                        Lecture Number: <?php echo e($pervious->leacture); ?><br>
                                        Unit: <?php echo e($pervious->unit); ?><br>
                                        Date: <?php echo e($pervious->date); ?>

                                    </h6>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <form action="final_attendent_counselor" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="staff_id" value="<?php echo e($pervious->subject); ?>">
                                <input type="hidden" name="leacture" value="<?php echo e($pervious->leacture); ?>">
                                <input type="hidden" name="date" value="<?php echo e($pervious->date); ?>">
                                <input type="hidden" name="unit" value="<?php echo e($pervious->unit); ?>">
                                <?php if($attendent == 'yes'): ?>
                                    <?php if($yes): ?>
                                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data->id == $pervious->subject): ?>
                                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($data->subject->class_id == $student->class_id): ?>
                                                        <div class="student-row">
                                                            <span class="student-name"><?php echo e(++$sum); ?>. <?php echo e($student->name); ?></span>
                                                            <input type="hidden" name="student[]" value="<?php echo e($student->student_id); ?>">
                                                            <label for="<?php echo e($sum.'p'); ?>">P</label>
                                                            <input type="radio" name="<?php echo e($student->student_id); ?>" value="present" id="<?php echo e($sum.'p'); ?>"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <label for="<?php echo e($sum.'a'); ?>">A</label>
                                                            <input type="radio" name="<?php echo e($student->student_id); ?>" value="absent" id="<?php echo e($sum.'a'); ?>">
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <?php if($optional): ?>
                                        <?php $__currentLoopData = $optional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data): ?>
                                                <div class="student-row">
                                                    <span class="student-name"><?php echo e(++$sum); ?>. <?php echo e($data->student->name); ?></span>
                                                    <input type="hidden" name="student[]" value="<?php echo e($data->student->student_id); ?>">
                                                    <label for="<?php echo e($data->student->student_id.'p'); ?>">P</label>
                                                    <input type="radio" name="<?php echo e($data->student->student_id); ?>" value="present" id="<?php echo e($data->student->student_id.'p'); ?>">
                                                    <label for="<?php echo e($data->student->student_id.'a'); ?>">A</label>
                                                    <input type="radio" name="<?php echo e($data->student->student_id); ?>" value="absent" id="<?php echo e($data->student->student_id.'a'); ?>">
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
    <span class="text-danger"><?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>⚠️ <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

                                <div class="mt-4 pt-2 text-center">
                                    <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                                </div>
                                    <?php if($sum == 0): ?>
                                        <h2 class="text-center">No students are mapped, contact to class counselors.</h2>
                                        
                                    <?php endif; ?>
                                <?php elseif($attendent == 'no'): ?>
                                    <h1 class="text-center text-danger">Attendance is taken for this subject.</h1>
                                <?php endif; ?>

                            
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/main_attendent.blade.php ENDPATH**/ ?>