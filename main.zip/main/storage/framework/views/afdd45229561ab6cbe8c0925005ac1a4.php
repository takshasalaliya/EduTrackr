
<?php $__env->startSection('title','Teacher Dashboard'); ?>
<?php $__env->startSection('dashboard'); ?>
<h1>Teacher</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/dashboard_teacher.blade.php ENDPATH**/ ?>