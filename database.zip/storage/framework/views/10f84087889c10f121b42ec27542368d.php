 

<?php $__env->startSection('title', 'Attendance Log'); ?>
<?php $__env->startSection('page_title'); ?>
    Attendance Log for Code: <span class="text-primary"><?php echo e($code ?? 'N/A'); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_code_attendent'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <a href="<?php echo e(url('select_counselor')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left-circle me-2"></i>Back to Selection
        </a>
    </div>
    <?php if(isset($code) && $code): ?>
    <button type="button" class="btn btn-danger"
            data-bs-toggle="modal" data-bs-target="#deleteCodeAfterLogModalCounselor"
            data-code-to-delete-log="<?php echo e($code); ?>">
        <i class="bi bi-trash3-fill me-2"></i>Delete This Code (<?php echo e($code); ?>)
    </button>
    <?php endif; ?>
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(isset($students) && is_countable($students) && count($students) > 0): ?>
        <div class="row">
            
            <div class="col-md-6 mb-4">
                <div class="card card-custom">
                    <div class="card-header bg-success text-white">
                        <i class="bi bi-person-check-fill me-2"></i>Present Students
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Enrollment No.</th>
                                        <th scope="col">Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $presentCount = 0; ?>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($student_record->attendance == 'present'): ?>
                                            <?php $presentCount++; ?>
                                            <tr>
                                                <td><?php echo e($presentCount); ?></td>
                                                <td><?php echo e($student_record->student->enrollment_number ?? 'N/A'); ?></td>
                                                <td><?php echo e($student_record->student->name ?? 'N/A'); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($presentCount == 0): ?>
                                        <tr><td colspan="3" class="text-center text-muted p-3">No students marked present.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php if($presentCount > 0): ?>
                    <div class="card-footer text-end">
                        <strong>Total Present: <?php echo e($presentCount); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="col-md-6 mb-4">
                <div class="card card-custom">
                    <div class="card-header bg-danger text-white">
                        <i class="bi bi-person-x-fill me-2"></i>Absent Students
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Enrollment No.</th>
                                        <th scope="col">Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $absentCount = 0; ?>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($student_record->attendance == 'absent'): ?>
                                            <?php $absentCount++; ?>
                                            <tr>
                                                <td><?php echo e($absentCount); ?></td>
                                                <td><?php echo e($student_record->student->enrollment_number ?? 'N/A'); ?></td>
                                                <td><?php echo e($student_record->student->name ?? 'N/A'); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($absentCount == 0): ?>
                                        <tr><td colspan="3" class="text-center text-muted p-3">No students marked absent.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <?php if($absentCount > 0): ?>
                    <div class="card-footer text-end">
                        <strong>Total Absent: <?php echo e($absentCount); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <?php if(isset($duplicated) && $duplicated->count() > 0): ?>
        <div class="card card-custom mt-4">
            <div class="card-header bg-warning text-dark">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>Potential Irregular Attendance Marking
            </div>
            <div class="card-body">
                <h5 class="card-title">Instances of students potentially marking attendance for others:</h5>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $duplicated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        Student from Class/Device <strong><?php echo e($data->in_class ?? 'Unknown'); ?></strong> marked attendance for student <strong><?php echo e($data->out_class ?? 'Unknown'); ?></strong>.
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <p class="mt-3 text-muted small">Please review these instances. This detection is based on [explain your detection logic briefly, e.g., IP address, device ID, rapid succession from different students on same device, etc.].</p>
            </div>
        </div>
        <?php else: ?>
        <div class="card card-custom mt-4">
            <div class="card-header">
                <i class="bi bi-shield-check me-2"></i>Attendance Integrity
            </div>
            <div class="card-body">
                <p class="text-muted mb-0">No instances of students marking attendance for others were detected for this session.</p>
            </div>
        </div>
        <?php endif; ?>

    <?php elseif(isset($students) && $students == 'no'): ?>
        <div class="alert alert-warning text-center py-4">
            <h4 class="alert-heading"><i class="bi bi-info-circle-fill me-2"></i>No Data Found</h4>
            <p>No attendance data is available for the specified code: <strong><?php echo e($code ?? 'N/A'); ?></strong>.</p>
            <p>This might mean the code was deleted before any attendance was logged, or the code is invalid.</p>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center py-4">
            <p>Loading attendance data or no information to display.</p>
        </div>
    <?php endif; ?>
</div>

<!-- Delete Code Confirmation Modal -->
<?php if(isset($code) && $code): ?>
<div class="modal fade" id="deleteCodeAfterLogModalCounselor" tabindex="-1" aria-labelledby="deleteCodeAfterLogModalCounselorLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteCodeAfterLogModalCounselorLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Code Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete the attendance code: <strong id="codeToDeleteInLogCounselor"><?php echo e($code); ?></strong>?
        <p class="text-danger small mt-2">This will prevent further attendance marking with this code. Existing records will be kept.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <a href="#" id="confirmDeleteCodeLinkAfterLogCounselor" class="btn btn-danger">Yes, Delete Code</a>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php if(isset($code) && $code): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteModal = document.getElementById('deleteCodeAfterLogModalCounselor');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            // var button = event.relatedTarget; // data-code-to-delete-log is on the button
            // var codeToDelete = button.getAttribute('data-code-to-delete-log');

            var confirmDeleteLink = deleteModal.querySelector('#confirmDeleteCodeLinkAfterLogCounselor');
            // var modalStrong = deleteModal.querySelector('#codeToDeleteInLogCounselor');
            // modalStrong.textContent = codeToDelete; // Already set by Blade

            confirmDeleteLink.href = '/delete_code_counselor/' + '<?php echo e($code); ?>';
        });
    }
});
</script>
<?php endif; ?>

<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/after_code_attendent.blade.php ENDPATH**/ ?>