<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    @page {
        size: A4;
        margin: 20mm;
    }
    body {
        font-family: Arial, sans-serif;
        font-size: 12px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 5px;
        text-align: center;
        border: 1px solid #ccc;
    }
    .page-break {
        page-break-before: always;
    }
</style>

</head>
<body>
    <?php
$number=1;
$image=public_path('image/3-removebg-preview.png');
    ?>
   
<img src="<?php echo e('data:image/png;base64,'.base64_encode(file_get_contents($image))); ?>" alt="semcom" style="width:100%;">

    <table class="table table-bordered">
        <tr>
            <th>Class & Semester:</th>
            <td><?php echo e($student_class); ?></td>
        </tr>
        <tr>
            <th>Class Counselor:</th>
            <td><?php echo e(Auth::user()->name); ?></td>
        </tr>
            <th>Class Strength:</th>
            <td><?php echo e($count); ?></td>
        </tr>
    </table>
        <table class="table table-bordered">
            <thead class="text-center">
                <tr>
                    <th>Sr. No.</th>
                    <th>Enrollment Number</th>
                    <th>Name</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Total Classes</th>
                    <th>Present</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <?php
                 $data=explode('&',$data);
                ?>
                    <td class="text-center"><?php echo e($number++); ?></td>
                    <td class="text-center"><?php echo e($data[0]); ?></td>
                    <td class="text-center"><?php echo e($data[1]); ?></td>
                    <td class="text-center"><?php echo e($data[2]); ?></td>
                    <td class="text-center"><?php echo e($data[3]); ?></td>
                    <td class="text-center"><?php echo e($data[4]); ?></td>
                    <td class="text-center"><?php echo e($data[5]); ?></td>
                    <td class="text-center"><?php echo e($data[6]); ?>%</td>
                </tr>
              
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/class_pdf.blade.php ENDPATH**/ ?>