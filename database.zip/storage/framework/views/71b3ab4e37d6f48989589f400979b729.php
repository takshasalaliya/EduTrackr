 

<?php $__env->startSection('title', 'Edit Attendance'); ?>
<?php $__env->startSection('page_title', 'Edit Student Attendance'); ?>

<?php $__env->startSection('edit_attendent'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <a href="<?php echo e(url('select_counselor')); ?>" class="btn btn-outline-secondary"> 
            <i class="bi bi-arrow-left-circle me-2"></i>Change Selection
        </a>
    </div>
    
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-9"> 
            <div class="card card-custom">
                <div class="card-header text-center">
                    <h4 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Edit Attendance Records</h4>
                </div>
                <div class="card-body p-4">
                    <?php
                        $headerInfoDisplayed = false;
                        $currentSubjectAssignment = null;
                        if (isset($datas) && isset($pervious->subject)) { // $datas holds subject assignment info
                            foreach($datas as $data_item) {
                                if($data_item->id == $pervious->subject) {
                                    $currentSubjectAssignment = $data_item;
                                    break;
                                }
                            }
                        }
                    ?>

                    <?php if($currentSubjectAssignment): ?>
                        <div class="alert alert-info mb-4">
                            <h5 class="alert-heading">Lecture Details:</h5>
                            <p class="mb-1">
                                <strong>Class:</strong>
                                <?php echo e($currentSubjectAssignment->subject->student_class->program->name ?? 'N/A'); ?> /
                                Batch: <?php echo e($currentSubjectAssignment->subject->student_class->year ?? 'N/A'); ?> /
                                Sem: <?php echo e($currentSubjectAssignment->subject->student_class->sem ?? 'N/A'); ?> /
                                Div: <?php echo e($currentSubjectAssignment->subject->student_class->devision ?? 'N/A'); ?>

                            </p>
                            <p class="mb-1"><strong>Subject:</strong> <?php echo e($currentSubjectAssignment->subject->subject_name ?? 'N/A'); ?> (<?php echo e($currentSubjectAssignment->subject->subject_code ?? 'N/A'); ?>)</p>
                            <p class="mb-1"><strong>Teacher:</strong> <?php echo e($currentSubjectAssignment->teacher->name ?? 'N/A'); ?></p>
                            <p class="mb-0">
                                <strong>Unit:</strong> <?php echo e($pervious->unit ?? 'N/A'); ?> |
                                <strong>Lecture No:</strong> <?php echo e($pervious->leacture ?? 'N/A'); ?> | 
                                <strong>Date:</strong> <?php echo e(isset($pervious->date) ? \Carbon\Carbon::parse($pervious->date)->format('d M Y') : 'N/A'); ?>

                            </p>
                        </div>
                        <?php $headerInfoDisplayed = true; ?>
                    <?php else: ?>
                        <div class="alert alert-warning">Could not load lecture details based on previous selection.</div>
                    <?php endif; ?>

                    <?php if($headerInfoDisplayed): ?>
                        <form action="<?php echo e(url('edit_attendendent_counselor')); ?>" method="post"> 
                            <?php echo csrf_field(); ?>
                            
                            <input type="hidden" value="<?php echo e($pervious->subject ?? ''); ?>" name="staff_id">
                            <input type="hidden" value="<?php echo e($pervious->unit ?? ''); ?>" name="unit">
                            <input type="hidden" value="<?php echo e($pervious->leacture ?? ''); ?>" name="leacture"> 
                            <input type="hidden" value="<?php echo e($pervious->date ?? ''); ?>" name="date">

                            <?php if(isset($attendent) && $attendent->count() > 0): ?> 
                                <?php $studentEditCount = 0; ?>
                                <?php $__currentLoopData = $attendent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance_record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($attendance_record->student)): ?> 
                                        <?php $studentEditCount++; ?>
                                        <div class="row align-items-center mb-2 py-2 border-bottom student-attendance-edit-row">
                                            <div class="col-md-1 text-end"><?php echo e($studentEditCount); ?>.</div>
                                            <div class="col-md-7 student-name-display">
                                                <?php echo e($attendance_record->student->name); ?> (<?php echo e($attendance_record->student->enrollment_number); ?>)
                                            </div>
                                            <div class="col-md-4 text-md-end text-center">
                                                
                                                <input type="hidden" name="student_ids[]" value="<?php echo e($attendance_record->student->student_id); ?>">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="attendance_status[<?php echo e($attendance_record->student->student_id); ?>]" value="present" id="edit_p_<?php echo e($attendance_record->student->student_id); ?>"
                                                           <?php echo e($attendance_record->attendance == 'present' ? 'checked' : ''); ?> required>
                                                    <label class="form-check-label" for="edit_p_<?php echo e($attendance_record->student->student_id); ?>">Present</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="attendance_status[<?php echo e($attendance_record->student->student_id); ?>]" value="absent" id="edit_a_<?php echo e($attendance_record->student->student_id); ?>"
                                                           <?php echo e($attendance_record->attendance == 'absent' ? 'checked' : ''); ?> required>
                                                    <label class="form-check-label" for="edit_a_<?php echo e($attendance_record->student->student_id); ?>">Absent</label>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if($studentEditCount == 0): ?>
                                    <div class="alert alert-warning text-center mt-3">
                                        <i class="bi bi-info-circle-fill me-2"></i>
                                        No existing attendance records found for this lecture to edit.
                                    </div>
                                <?php else: ?>
                                    <div class="mt-4 pt-2 text-center">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="bi bi-save-fill me-2"></i>Update Attendance
                                        </button>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert alert-warning text-center mt-3">
                                    <i class="bi bi-info-circle-fill me-2"></i>
                                    No attendance records found for this selection. It might not have been taken yet.
                                    You can <a href="<?php echo e(url('select_counselor')); ?>?subject=<?php echo e($pervious->subject); ?>&unit=<?php echo e($pervious->unit); ?>&leacture=<?php echo e($pervious->leacture); ?>&date=<?php echo e($pervious->date); ?>&submit=submit">take attendance</a> instead.
                                </div>
                            <?php endif; ?>
                            <?php $__errorArgs = ['attendance_status.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="text-danger mt-2 mb-2 d-block text-center">⚠️ <?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </form>
                    <?php elseif(!$headerInfoDisplayed): ?>
                         <div class="alert alert-danger text-center">
                             <h4 class="alert-heading"><i class="bi bi-exclamation-triangle-fill me-2"></i>Selection Error!</h4>
                             <p>Could not load details for the selected subject/lecture. Please go back and try selecting again.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/edit_attendent.blade.php ENDPATH**/ ?>