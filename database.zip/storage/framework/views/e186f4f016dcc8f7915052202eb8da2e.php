 

<?php $__env->startSection('title', 'Student Attendance Details by Subject'); ?>
<?php $__env->startSection('page_title', 'Student Attendance Details'); ?>

<?php $__env->startSection('subject_table_attendent'); ?> 


<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    
    <div>
        <p class="text-muted mb-0">Detailed attendance records for students by selected subject.</p>
    </div>
    <div class="btn-group" role="group" aria-label="Export Actions">
        <?php if(request('subject')): ?> 
            <a href="<?php echo e(url('generate_pdf_counselor/'.request('subject'))); ?>" class="btn btn-danger">
                <i class="bi bi-file-earmark-pdf-fill me-2"></i>Download PDF
            </a>
            <a href="<?php echo e(url('generate_excel_counselor/'.request('subject'))); ?>" class="btn btn-success">
                <i class="bi bi-file-earmark-excel-fill me-2"></i>Download Excel
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="card card-custom mb-4">
        <div class="card-body">
            <form action="<?php echo e(url('attendent_list_counselor')); ?>" method="get" id="filterAttendanceListForm"> 
                <div class="row g-3 align-items-end">
                    <div class="col-md-8">
                        <label for="subject_filter_att_list" class="form-label">Select Subject / Class Context <span class="text-danger">*</span></label>
                        <select name="subject" id="subject_filter_att_list" class="form-select <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="document.getElementById('filterAttendanceListForm').submit()" required>
                            <option value="" disabled <?php echo e(!request('subject') ? 'selected' : ''); ?>>Select Subject and Class</option>
                            <?php if(isset($subject)): ?> 
                                <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subj_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subj_option->id); ?>" <?php echo e(request('subject') == $subj_option->id ? 'selected' : ''); ?>>
                                    <?php echo e($subj_option->subject->short_name ?? 'N/A Sub'); ?> -
                                    <?php echo e($subj_option->subject->student_class->program->name ?? 'N/A Prog'); ?> /
                                    Sem <?php echo e($subj_option->subject->student_class->sem ?? 'N/A'); ?> /
                                    Div <?php echo e($subj_option->subject->student_class->devision ?? 'N/A'); ?>

                                    (Batch: <?php echo e($subj_option->subject->student_class->year ?? 'N/A'); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="" disabled>No subjects assigned to you or your classes found.</option>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                         <button type="submit" class="btn btn-primary w-100">View Attendance</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <?php if(isset($student)): ?> 
    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-table me-2"></i>Student Attendance Summary for Selected Subject
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Enrollment No.</th>
                            <th scope="col">Student Name</th>
                            <th scope="col" class="text-center">Total Lectures</th>
                            <th scope="col">First Attended</th>
                            <th scope="col">Last Attended</th>
                            <th scope="col" class="text-center">Present</th>
                            <th scope="col" class="text-center">Attendance %</th>
                            <th scope="col" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $num=0;
                    ?>
                        
                        <?php $__currentLoopData = $valid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<?php
$sum=0;
$present=0;
$enter=0;
$date=[];
foreach ($student as $d) {
    if ($d->student->enrollment_number == $data && $d->staff_id == $id) {
        $date[]=$d->created_at;
        $sum++;
        $to=explode(" ",$d->created_at);
        $name=$d->student->name;
        $message=$d->student->student_id;
        if($d->attendance=='present'){
            $present++;
        }
    }

    
}
sort($date);
$from=$date[0]; 
$from=explode(" ",$from);
$to = end($date);
$to=explode(" ",$to);
$pertentage=number_format($present/$sum*100,2);
?>
 <td><?php echo e($num=+1); ?></td>
<td><?php echo e($data); ?></td>
<td><?php echo e($name); ?></td>
<td><?php echo e($sum); ?></td>
<td><?php echo e($from[0]); ?></td>
<td><?php echo e($to[0]); ?></td>
   <td><?php echo e($present); ?></td>
   <td><?php echo e($pertentage); ?>%</td>
   <td>
   <a href="<?php echo e('send-watsapp/'.$message.'/'.$pertentage.'/'.$subject_id); ?>"><button type="button"  class="btn btn-sm btn-success" title="Send WhatsApp Message"><i class="bi bi-whatsapp"></i> Message</button></a>
   </td>
</tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
    <?php elseif(request('subject')): ?> 
        <div class="alert alert-warning text-center mt-4 py-4">
            <h4 class="alert-heading"><i class="bi bi-info-circle-fill me-2"></i>No Attendance Data</h4>
            <p>No attendance records found for the selected subject. Please ensure attendance has been taken.</p>
        </div>
    <?php else: ?> 
        <div class="alert alert-info text-center mt-4 py-4">
            <p><i class="bi bi-info-circle-fill me-2"></i>Please select a subject from the dropdown above to view the attendance list.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/attendent_list.blade.php ENDPATH**/ ?>