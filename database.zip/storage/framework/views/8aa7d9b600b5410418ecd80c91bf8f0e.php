

<?php $__env->startSection('title', 'Subject & Teacher Assignment'); ?>
 

<?php $__env->startSection('teachingstaff'); ?>


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Assign Subjects to Teachers</h1>
    <div>
        <a href="https://docs.google.com/spreadsheets/d/1IglJfoj9kI0Co6IUDcqU9OwXHL-19wV7/edit?usp=sharing&ouid=109161218020310229957&rtpof=true&sd=true" target="_blank" class="btn btn-outline-success">
            <i class="bi bi-file-earmark-spreadsheet me-2"></i>Sample Excel for Bulk Assign
        </a>
    </div>
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo session('success'); ?> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo session('error'); ?> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-file-earmark-arrow-up-fill me-2"></i>Bulk Assign Subjects via Excel
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('subject_maping')); ?>" method="post" enctype="multipart/form-data" class="row g-3 align-items-end">
                <?php echo csrf_field(); ?>
                <div class="col-md-8">
                    <label for="excel_subject_maping" class="form-label">Upload Excel File</label>
                    <input type="file" class="form-control <?php $__errorArgs = ['subject_maping'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="excel_subject_maping" name="subject_maping" required accept=".xlsx, .xls, .csv">
                    <?php $__errorArgs = ['subject_maping'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-success w-100" type="submit">
                        <i class="bi bi-upload me-2"></i>Upload & Process
                    </button>
                </div>
            </form>
        </div>
    </div>


    
    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-ui-checks-grid me-2"></i>Manual Subject Assignment
        </div>
        <div class="card-body">
            <p class="text-muted">Select filters to narrow down the class and teacher, then assign subjects.</p>

            <form action="<?php echo e(url('subjectallocated_admin')); ?>" method="GET" id="filterForm">
                 
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <label for="program_filter" class="form-label">Program</label>
                        <select name="program" id="program_filter" class="form-select" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Select Program</option>
                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($program_item->program_id); ?>" <?php echo e(request('program') == $program_item->program_id ? 'selected' : ''); ?>><?php echo e($program_item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php if(isset($sem) && count($sem) > 0): ?>
                    <div class="col-md-2">
                        <label for="semester_filter" class="form-label">Semester</label>
                        <select name="sem" id="semester_filter" class="form-select" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Select Semester</option>
                            <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sem_item->sem); ?>" <?php echo e(request('sem') == $sem_item->sem ? 'selected' : ''); ?>>Semester <?php echo e($sem_item->sem); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($year) && count($year) > 0): ?>
                    <div class="col-md-2">
                        <label for="year_filter" class="form-label">Batch Year</label>
                        <select name="year" id="year_filter" class="form-select" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Select Year</option>
                            <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year_item->year); ?>" <?php echo e(request('year') == $year_item->year ? 'selected' : ''); ?>><?php echo e($year_item->year); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($devision) && count($devision) > 0): ?>
                    <div class="col-md-2">
                        <label for="devision_filter" class="form-label">Division</label>
                        <select name="devision" id="devision_filter" class="form-select" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Select Division</option>
                            <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devision_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($devision_item->devision); ?>" <?php echo e(request('devision') == $devision_item->devision ? 'selected' : ''); ?>><?php echo e($devision_item->devision); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($teacher) && count($teacher)): ?> 
                    <div class="col-md-3">
                        <label for="teacher_filter" class="form-label">Teacher</label>
                        <select name="teacher" id="teacher_filter" class="form-select" onchange="document.getElementById('filterForm').submit()">
                            <option value="">Select Teacher</option>
                            <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($teacher_item->role != 'admin' && $teacher_item->role != 'student'): ?>
                                <option value="<?php echo e($teacher_item->id); ?>" <?php echo e(request('teacher') == $teacher_item->id ? 'selected' : ''); ?>><?php echo e($teacher_item->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if(request('program') && request('sem') && request('year') && request('devision') && request('teacher')): ?>
                    
                    
                    
                 
                    <div class="mb-3">
                        <a href="<?php echo e('/excel_teacher_subject/'.$class_id); ?>" class="btn btn-info btn-sm">
                            <i class="bi bi-download me-2"></i>Download Current Teacher-Subject Assignments
                        </a>
                    </div>
                  
                <?php endif; ?>
            </form>

            <?php if(isset($class_id) && $class_id && isset($subject) && count($subject) > 0 && request('teacher')): ?>
            <hr class="my-4">
            <h5>Assign Subjects for: <strong><?php echo e($teacher->firstWhere('id', request('teacher'))->name ?? 'Selected Teacher'); ?></strong></h5>
            <p class="text-muted">Class: Based on selected filters (Program, Semester, Batch, Division).</p>
            <form action="<?php echo e(url('/subjectallocated_admin')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(request('teacher')); ?>" name="teacher">
                <input type="hidden" value="<?php echo e($class_id); ?>" name="class_id"> 

                <div class="mb-3 border p-3 rounded">
                    <label class="form-label fw-bold">Available Subjects for the Selected Class:</label>
                    <?php $subjectFoundForClass = false; ?>
                    <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($subject_item->class_id == $class_id): ?> 
                            <?php $subjectFoundForClass = true; ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="<?php echo e($subject_item->subject_id); ?>" name="subject[]" id="subject_<?php echo e($subject_item->subject_id); ?>"
                                       <?php echo e((is_array(old('subject')) && in_array($subject_item->subject_id, old('subject'))) || (isset($assigned_subjects) && in_array($subject_item->subject_id, $assigned_subjects)) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="subject_<?php echo e($subject_item->subject_id); ?>">
                                    <?php echo e($subject_item->subject_name); ?> (<?php echo e($subject_item->subject_code); ?>)
                                    - <small class="text-muted"><?php echo e(ucfirst($subject_item->category)); ?>, <?php echo e($subject_item->l_category == 'T' ? 'Theory' : ($subject_item->l_category == 'P' ? 'Practical' : '')); ?></small>
                                </label>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$subjectFoundForClass): ?>
                        <p class="text-warning m-0">No subjects found specifically linked to this exact class configuration. Ensure subjects are correctly associated with classes or programs/semesters.</p>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check2-square me-2"></i>Save 
                </button>
            </form>
            <?php elseif(request('program') && request('teacher')): ?>
                <div class="alert alert-info mt-3">
                    <i class="bi bi-info-circle-fill me-2"></i>Please complete all filters (Semester, Batch, Division) to load subjects for assignment.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/subject_allocated.blade.php ENDPATH**/ ?>