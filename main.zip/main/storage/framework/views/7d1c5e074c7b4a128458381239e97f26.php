

<?php $__env->startSection('title','Subject List'); ?>
<?php $__env->startSection('optional_subject_list'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

</form>
<table class="table">
   <tr>
    <th>Enrollment</th>
    <th>Name</th>
    <th>Subject Code</th>
    <th>Subject Name</th>
    <th>Devision</th>
    <th>Semester</th>
    <th>Program</th>
    <th>Delete</th>
   </tr>
   
   <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($data->student->enrollment_number); ?></td>
    <td><?php echo e($data->student->name); ?></td>
    <td><?php echo e($data->subject->subject_code); ?></td>
    <td><?php echo e($data->subject->subject_name); ?></td>
    <td><?php echo e($data->subject->student_class->devision); ?></td>
    <td><?php echo e($data->subject->student_class->sem); ?></td>
    <td><?php echo e($data->subject->student_class->program->name); ?></td>
    <td>
    <a href="<?php echo e('delete_optional_admin/'.$data->id); ?>"><button type="button" class="btn btn-primary">Delete</button></a></td>
    </td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views/admin/optional_subject_list.blade.php ENDPATH**/ ?>