
<?php $__env->startSection('title','Class Attendent'); ?>
<?php $__env->startSection('classattendent'); ?>

<!-- PDF Button -->

<!-- Success and Error Messages -->
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<!-- Make the table responsive using Bootstrap's .table-responsive class -->
<div class="table-responsive">
        <table class="table">
            <tr>
            <div class="text-center mb-3">
    <a href="class_pdf">
        <button type="button" class="btn btn-info">Download PDF</button>
    </a>
</div>

            </tr>
            <thead>
                <tr>
                    
                    <th>Enrollment Number</th>
                    <th>Name</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Total Class</th>
                    <th>Present</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
               
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $data = explode('&', $data); ?>
                    <tr>
                        <td><?php echo e($data[0]); ?></td>
                        <td><?php echo e($data[1]); ?></td>
                        <td><?php echo e($data[2]); ?></td>
                        <td><?php echo e($data[3]); ?></td>
                        <td><?php echo e($data[4]); ?></td>
                        <td><?php echo e($data[5]); ?></td>
                        <td><?php echo e($data[6]); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/classattendent.blade.php ENDPATH**/ ?>