 

<?php $__env->startSection('title', 'My Subjects List'); ?>
<?php $__env->startSection('page_title', 'Subjects in My Classes'); ?>

<?php $__env->startSection('subject_table'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Showing subjects associated with classes you counsel.</p>
    </div>
    <a href="<?php echo e(url('add_subject')); ?>" class="btn btn-primary"> 
        <i class="bi bi-plus-circle-fill me-2"></i>Add New Subject
    </a>
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card card-custom">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <i class="bi bi-journals me-2"></i>Subjects List
            </div>
            <form action="<?php echo e(url('subject_list_filter')); ?>" method="get" class="d-flex align-items-center ms-auto">
                <label for="filter_class_program" class="form-label me-2 mb-0 visually-hidden">Filter by Program/Class:</label>
                <select name="field" id="filter_class_program" class="form-select form-select-sm" onchange="this.form.submit()" style="min-width: 250px;">
                    <option value="all" <?php echo e(($select ?? 'all') == 'all' ? 'selected' : ''); ?>>All My Classes/Programs</option>
                    <?php if(isset($programs_for_filter) && count($programs_for_filter) > 0 && isset(Auth::user()->id)): ?> 
                        <?php $__currentLoopData = $programs_for_filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class_filter_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($class_filter_option->coundelor_id == Auth::user()->id): ?> 
                                <option value="<?php echo e($class_filter_option->program->program_id); ?>_<?php echo e($class_filter_option->id); ?>" <?php echo e(($select ?? '') == ($class_filter_option->program->program_id . '_' . $class_filter_option->id) ? 'selected' : ''); ?>>
                                    <?php echo e($class_filter_option->program->name ?? 'N/A Program'); ?> / Div: <?php echo e($class_filter_option->devision ?? 'N/A'); ?> (Sem: <?php echo e($class_filter_option->sem ?? 'N/A'); ?>, Batch: <?php echo e($class_filter_option->year ?? 'N/A'); ?>)
                                </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </form>
        </div>
        <div class="card-body p-0">
            <?php
                $counselorSubjects = [];
                if(isset($subjects) && isset(Auth::user()->id)) {
                    foreach($subjects as $subject) {
                        // Check if subject is associated with a class counseled by the current user
                        // This relies on $subject->student_class relationship
                        if(isset($subject->student_class) && $subject->student_class->coundelor_id == Auth::user()->id) {
                            // Further filter if a specific class/program filter is applied via $select
                            if (($select ?? 'all') == 'all') {
                                $counselorSubjects[] = $subject;
                            } elseif (isset($subject->student_class->program)) {
                                $filter_value_parts = explode('_', $select);
                                $selected_program_id = $filter_value_parts[0] ?? null;
                                $selected_class_id_from_filter = $filter_value_parts[1] ?? null; // If filter value includes class_id

                                // Match by program_id and optionally by class_id if the filter is that specific
                                if ($subject->student_class->program->program_id == $selected_program_id) {
                                    if ($selected_class_id_from_filter && $subject->student_class->id == $selected_class_id_from_filter) {
                                        $counselorSubjects[] = $subject;
                                    } elseif (!$selected_class_id_from_filter) { // If filter is just by program_id
                                        $counselorSubjects[] = $subject;
                                    }
                                }
                            }
                        }
                    }
                }
            ?>

            <?php if(count($counselorSubjects) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Subject Name</th>
                            <th scope="col">Short Name</th>
                            <th scope="col">Code</th>
                            <th scope="col">Category</th>
                            <th scope="col">Type (L/P)</th>
                            <th scope="col">Associated Class Details</th>
                            <th scope="col">Last Updated</th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $counselorSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($subject->subject_name); ?></td>
                            <td><?php echo e($subject->short_name ?? 'N/A'); ?></td>
                            <td><?php echo e($subject->subject_code); ?></td>
                            <td><span class="badge bg-info text-dark"><?php echo e(ucfirst($subject->category ?? 'N/A')); ?></span></td>
                            <td>
                                <?php if(isset($subject->lecture_category)): ?>
                                    <?php if($subject->lecture_category == 'T'): ?>
                                        <span class="badge bg-primary">Theory (T)</span>
                                    <?php elseif($subject->lecture_category == 'P'): ?>
                                        <span class="badge bg-success">Practical (P)</span>
                                    <?php else: ?>
                                        <?php echo e($subject->lecture_category); ?>

                                    <?php endif; ?>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($subject->student_class && $subject->student_class->program): ?>
                                    <?php echo e($subject->student_class->program->name); ?> /
                                    Batch: <?php echo e($subject->student_class->year ?? 'N/A'); ?> /
                                    Sem: <?php echo e($subject->student_class->sem ?? 'N/A'); ?> /
                                    Div: <?php echo e($subject->student_class->devision ?? 'N/A'); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($subject->updated_at ? $subject->updated_at->format('d M Y, h:i A') : 'N/A'); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(url('/edit_subject/'.$subject->subject_id)); ?>" class="btn btn-sm btn-outline-warning me-1" title="Edit Subject">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Subject"
                                        data-bs-toggle="modal" data-bs-target="#deleteSubjectModalCounselor"
                                        data-subject-id="<?php echo e($subject->subject_id); ?>" data-subject-name="<?php echo e($subject->subject_name); ?>">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-journal-x display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">
                    <?php if(($select ?? 'all') != 'all'): ?>
                        No subjects found for the selected filter in your classes.
                    <?php else: ?>
                        No subjects found in the classes you counsel.
                    <?php endif; ?>
                </p>
                <p class="small text-muted mt-2">Ensure subjects are assigned to your classes, or try a different filter.</p>
            </div>
            <?php endif; ?>
        </div>
        
    </div>
</div>

<!-- Delete Subject Confirmation Modal -->
<div class="modal fade" id="deleteSubjectModalCounselor" tabindex="-1" aria-labelledby="deleteSubjectModalCounselorLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteSubjectModalCounselorLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete the subject: <strong id="subjectNameToDeleteCounselor"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone and might affect class schedules or student records.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteSubjectFormCounselor" method="get" action=""> 
            <button type="submit" class="btn btn-danger">Yes, Delete Subject</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteModal = document.getElementById('deleteSubjectModalCounselor');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var subjectId = button.getAttribute('data-subject-id');
            var subjectName = button.getAttribute('data-subject-name');

            var modalBodyStrong = deleteModal.querySelector('#subjectNameToDeleteCounselor');
            var deleteForm = deleteModal.querySelector('#deleteSubjectFormCounselor');

            modalBodyStrong.textContent = subjectName;

            // For your current GET route: '<?php echo e(url("delete_subject")); ?>/' + subjectId;
            deleteForm.action = 'delete_subject/' + subjectId; // Using your current GET route

            // If using GET, remove method spoofing and set form method to GET
            const methodInput = deleteForm.querySelector('input[name="_method"]');
            if (methodInput) {
                methodInput.remove();
            }
            deleteForm.method = 'GET';
        });
    }
});
</script>

<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/list_subject.blade.php ENDPATH**/ ?>