
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('dashboard'); ?>


    <style>
        .info-box {
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .info-box i {
            font-size: 30px;
            margin-bottom: 10px;
        }
    </style>

<body>
    <div class="container mt-5">
        <div class="row g-3">
            <!-- Box 1 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #7A3B8E;">
                    <i class="bi bi-person-lines-fill"></i>
                    <h2><?php echo e($students); ?></h2>
                    <p>STUDENTS</p>
                </div>
            </div>
            <!-- Box 2 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #E74C3C;">
                    <i class="bi bi-people"></i>
                    <h2><?php echo e($teachers); ?></h2>
                    <p>TEACHER</p>
                </div>
            </div>
            <!-- Box 3 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #17A589;">
                    <i class="bi bi-book"></i>
                    <h2><?php echo e($counselors); ?> </h2>
                    <p>COUNSELLOR</p>
                </div>
            </div>
            <!-- Box 4 -->
            <div class="col-md-3">
                <div class="info-box" style="background-color: #2980B9;">
                    <i class="bi-classbi bi-hospital"></i>
                    <h2><?php echo e($classes); ?></h2>
                    <p>CLASS</p>
                </div>
            </div>
        </div>
    </div>
    <br>
<center><h2>Total Classes</h2></center>
    <table class="table">
        <tr>
        <th>ID</th>
        <th>Class</th>
        <th>Devision</th>
        <th>Semester</th>
        <th>Batch</th>

        </tr>
        <tr>
            <?php $__currentLoopData = $class_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
            <tr>
                <td><?php echo e($class->id); ?></td>
                <td><?php echo e($class->program->name); ?></td>
                <td><?php echo e($class->devision); ?></td>
                <td><?php echo e($class->sem); ?></td>
                
                <td><?php echo e($class->year); ?></td>
            </tr>
          
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
    
    
    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/admin/welcome.blade.php ENDPATH**/ ?>