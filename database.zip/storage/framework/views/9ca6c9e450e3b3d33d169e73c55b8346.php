
<?php $__env->startSection('title','Subject List'); ?>
<?php $__env->startSection('subject_table'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>


<table class="table">
    <td>
    <form action="subject_list_filter" method="get">
    <select name="field" id="field" onchange="this.form.submit()">
        <option value="all" <?php echo e($select=='all'?'selected':''); ?>>ALL</option>
        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($program->coundelor_id==Auth::user()->id): ?>
         <option value="<?php echo e($program->program->program_id); ?>" <?php echo e($select == $program->program->program_id ? 'selected' : ''); ?>><?php echo e($program->program->name.'/'.$program->devision); ?></option>
         <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>
    </td>
   <tr>
    <th>Subjec Name</th>
    <th>Subject Short Name</th>
    <th>Subject Code</th>
    <th>Field</th>
    <th>Category</th>
    <th>Last Updated</th>
    <th>Operation</th>
    </tr>
    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($subject->student_class->coundelor_id==Auth::user()->id): ?>
    <tr>
        <td><?php echo e($subject->subject_name); ?></td>
        <td><?php echo e($subject->short_name); ?></td>
        <td><?php echo e($subject->subject_code); ?></td>
        <td><?php echo e($subject->student_class->program->name.'/'.$subject->student_class->year.'/'.$subject->student_class->sem.'/'.$subject->student_class->devision); ?></td>
        <td><?php echo e($subject->category); ?></td>
        <td><?php echo e($subject->updated_at); ?></td>
        <td><a href="<?php echo e('/edit_subject/'.$subject->subject_id); ?>"><button type="button" class="btn btn-info">Edit</button></a>
        <a href="<?php echo e('delete_subject/'.$subject->subject_id); ?>"><button type="button" class="btn btn-primary">Delete</button></a></td>
        </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor/layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u298309303/domains/silver-turkey-370320.hostingersite.com/public_html/resources/views/counselor/list_subject.blade.php ENDPATH**/ ?>