

<?php $__env->startSection('title', 'WhatsApp Device Management'); ?>
 

<?php $__env->startSection('subject_table'); ?> 


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title"><i class="bi bi-whatsapp me-2"></i>WhatsApp Device Management</h1>
    
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="card card-custom mb-4">
        <div class="card-header">
            <i class="bi bi-plus-circle-fill me-2"></i>Add New WhatsApp Device
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('whatsapp')); ?>" method="get"> 
                 
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="add_device_name" class="form-label">Device Name <span class="text-danger">*</span></label>
                        <input type="text" id="add_device_name" name="device" class="form-control <?php $__errorArgs = ['device'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('device')); ?>" placeholder="e.g., Marketing Phone" required>
                        <?php $__errorArgs = ['device'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <label for="add_device_number" class="form-label">Mobile Number (with country code) <span class="text-danger">*</span></label>
                        <input type="number" id="add_device_number" name="number" class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('number')); ?>" placeholder="e.g., 919876543210" required>
                        <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-plus-lg me-2"></i>Add Device
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-list-ul me-2"></i>Registered WhatsApp Devices
        </div>
        <div class="card-body p-0">
            <?php if(isset($datas) && count($datas) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Device Name</th>
                            <th scope="col">Registered Number</th>
                            <th scope="col">Remaining Messages (Quota)</th>
                            <th scope="col">Status</th>
                            <th scope="col">Token</th>
                            <?php if(isset($otp_message) && $otp_message == 'yes'): ?>
                            <th scope="col" style="min-width: 250px;">OTP Verification</th>
                            <?php endif; ?>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($row['name'] ?? 'N/A'); ?></td>
                            <td><?php echo e($row['device'] ?? 'N/A'); ?></td>
                            <td><?php echo e($row['quota'] ?? 'N/A'); ?></td>
                            <td>
                                <?php if(isset($row['status']) && $row['status'] == 'disconnect'): ?>
                                    <a href="<?php echo e(url('/whatsapp_img/'.$row['token'].'/'.$row['device'])); ?>" class="btn btn-sm btn-warning" title="Reconnect - Click to see QR">
                                        <i class="bi bi-qr-code-scan me-1"></i> Disconnected
                                    </a>
                                <?php elseif(isset($row['status']) && $row['status'] == 'connect'): ?>
                                    <span class="badge bg-success"><i class="bi bi-check-circle-fill me-1"></i> Connected</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($row['status'] ?? 'Unknown'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-light text-dark text-truncate" style="max-width: 150px;" title="<?php echo e($row['token'] ?? 'N/A'); ?>"><?php echo e($row['token'] ?? 'N/A'); ?></span></td>

                            <?php if(isset($otp_message) && $otp_message == 'yes'): ?>
                            <td>
                                <?php if(isset($otp) && $otp): ?> 
                                    <p class="mb-1"><strong class="text-success">Current OTP: <?php echo e($otp); ?></strong></p>
                                <?php endif; ?>
                                <form action="<?php echo e(url('/otp_whatsapp/'.$row['name'])); ?>" method="get" class="d-flex gap-1">
                                    <input type="number" name="otp" class="form-control form-control-sm <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter OTP" style="max-width: 120px;" required>
                                    <input type="hidden" value="<?php echo e($row['token'] ?? ''); ?>" name="token">
                                    <button type="submit" class="btn btn-sm btn-outline-primary">Submit OTP</button>
                                    <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-hdd-stack-fill display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">No WhatsApp devices have been added yet.</p>
                <p class="small text-muted mt-2">Use the form above to add a new device.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    
    <?php if(isset($img) && $img): ?>
    <div class="card card-custom mt-4">
        <div class="card-header">
            <i class="bi bi-qr-code me-2"></i>Scan QR Code to Connect Device
        </div>
        <div class="card-body text-center">
            <p class="text-muted">Scan this QR code with your WhatsApp application on the device you are trying to connect.</p>
            <img src="data:image/png;base64,<?php echo e($img); ?>" alt="WhatsApp QR Code" class="img-fluid border rounded" style="max-width: 300px;">
            <p class="mt-3">
                <small>If the QR code has expired or is not working, try clicking the "Disconnected" button again for a new one.</small>
            </p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/whatsapp_message.blade.php ENDPATH**/ ?>