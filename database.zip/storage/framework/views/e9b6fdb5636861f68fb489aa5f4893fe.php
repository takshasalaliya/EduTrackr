 

<?php $__env->startSection('title', 'Select Attendance Criteria'); ?>
<?php $__env->startSection('page_title', 'Select Criteria for Attendance'); ?>

<?php $__env->startSection('attendent_before'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Select the subject, unit, lecture, and date to proceed.</p>
    </div>
    
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert"> 
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-8"> 
            <div class="card card-custom">
                <div class="card-header">
                    <i class="bi bi-ui-checks-grid me-2"></i>Specify Your Requirements
                </div>
                <div class="card-body p-4">
                    <form action="<?php echo e(url('selectes_data_counselor')); ?>" method="get"> 
                         

                        <div class="row g-3">
                            <div class="col-md-12 mb-3"> 
                                <label class="form-label" for="subject_select_att">Subject / Class Context <span class="text-danger">*</span></label>
                                <select name="subject" id="subject_select_att" class="form-select <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="" disabled <?php echo e(!request('subject') ? 'selected' : ''); ?>>Select Subject and Class</option>
                                    <?php if(isset($subjects) && count($subjects) > 0): ?>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <option value="<?php echo e($subject_assignment->id); ?>" <?php echo e(request('subject') == $subject_assignment->id ? 'selected' : ''); ?>>
                                            <?php echo e($subject_assignment->subject->short_name ?? 'N/A Sub'); ?> -
                                            <?php echo e($subject_assignment->subject->student_class->program->name ?? 'N/A Prog'); ?> /
                                            Sem <?php echo e($subject_assignment->subject->student_class->sem ?? 'N/A'); ?> /
                                            Div <?php echo e($subject_assignment->subject->student_class->devision ?? 'N/A'); ?>

                                            (Batch: <?php echo e($subject_assignment->subject->student_class->year ?? 'N/A'); ?>)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="" disabled>No subjects assigned to you found.</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="unit_select_att">Unit Number <span class="text-danger">*</span></label>
                                <select name="unit" id="unit_select_att" class="form-select <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="" disabled <?php echo e(!request('unit') ? 'selected' : ''); ?>>Select Unit</option>
                                    <?php for($i = 1; $i <= 6; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(request('unit') == $i ? 'selected' : ''); ?>>Unit <?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="leacture_select_att">Lecture Number <span class="text-danger">*</span></label> 
                                <select name="leacture" id="leacture_select_att" class="form-select <?php $__errorArgs = ['leacture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="" disabled <?php echo e(!request('leacture') ? 'selected' : ''); ?>>Select Lecture</option>
                                    <?php for($i = 1; $i <= 10; $i++): ?> 
                                    <option value="<?php echo e($i); ?>" <?php echo e(request('leacture') == $i ? 'selected' : ''); ?>>Lecture <?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <?php $__errorArgs = ['leacture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="date_select_att">Date <span class="text-danger">*</span></label>
                                <input type="date" name="date" id="date_select_att" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(request('date', date('Y-m-d'))); ?>" required>
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mt-4 pt-2 text-center">
                            <button class="btn btn-primary btn-lg mx-1" name="submit" type="submit" value="submit" title="Proceed to take/add attendance">
                                <i class="bi bi-plus-circle-fill me-2"></i>Take Attendance
                            </button>
                            <button class="btn btn-warning btn-lg mx-1" name="submit" type="submit" value="edit" title="Proceed to edit existing attendance">
                                <i class="bi bi-pencil-square me-2"></i>Edit Attendance
                            </button>
                            <button class="btn btn-info btn-lg mx-1" name="submit" type="submit" value="generate" title="Generate attendance related report or code">
                                <i class="bi bi-file-earmark-text-fill me-2"></i>Generate Report/Code
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/select_operation.blade.php ENDPATH**/ ?>