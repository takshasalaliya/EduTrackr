<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gcode extends Model
{
    //
}
