 

<?php $__env->startSection('title', 'Logged Activities'); ?>
<?php $__env->startSection('page_title', 'Student Activity Log'); ?>

<?php $__env->startSection('content'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">List of logged student activities and participation.</p>
    </div>
    <a href="<?php echo e(url('counselor/leaves/create')); ?>" class="btn btn-primary"> 
        <i class="bi bi-plus-lg me-2"></i>Log New Activity
    </a>
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    


    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-list-stars me-2"></i>Logged Activities
        </div>
        <div class="card-body p-0">
            <?php if(isset($activity_logs) && $activity_logs->count() > 0): ?> 
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Activity Name</th>
                            <th scope="col" class="text-center">Session No.</th>
                            <th scope="col">From Date</th>
                            <th scope="col">To Date</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">Enrollment No.</th>
                            <th scope="col" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $activity_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log_entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1 + ($activity_logs instanceof \Illuminate\Pagination\LengthAwarePaginator ? ($activity_logs->currentPage() - 1) * $activity_logs->perPage() : 0)); ?></td>
                            <td><?php echo e($log_entry->name ?? 'N/A'); ?></td>
                            <td class="text-center"><?php echo e($log_entry->session ?? '-'); ?></td>
                            <td><?php echo e(isset($log_entry->from_date) ? \Carbon\Carbon::parse($log_entry->from_date)->format('d M Y') : 'N/A'); ?></td>
                            <td><?php echo e(isset($log_entry->to_date) ? \Carbon\Carbon::parse($log_entry->to_date)->format('d M Y') : 'N/A'); ?></td>
                            <td><?php echo e($log_entry->student->name ?? 'N/A'); ?></td>
                            <td><?php echo e($log_entry->student->enrollment_number ?? 'N/A'); ?></td>
                            <td class="text-center">
                                
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Remove Student from Activity"
                                        data-bs-toggle="modal" data-bs-target="#deleteActivityParticipationModal"
                                        data-participation-id="<?php echo e($log_entry->id); ?>" 
                                        data-activity-name="<?php echo e($log_entry->activity->name ?? 'Activity'); ?>"
                                        data-student-name="<?php echo e($log_entry->student->name ?? 'Student'); ?>">
                                    <i class="bi bi-person-x-fill"></i> Remove
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-calendar-x display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">No student activities logged yet or matching your filters.</p>
                <p class="small text-muted mt-2">You can <a href="<?php echo e(url('counselor/activity/create')); ?>">log a new activity</a>.</p>
            </div>
            <?php endif; ?>
        </div>
        <?php if(isset($activity_logs) && $activity_logs instanceof \Illuminate\Pagination\LengthAwarePaginator && $activity_logs->hasPages()): ?>
        <div class="card-footer bg-light border-top-0">
            <?php echo e($activity_logs->appends(request()->query())->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Activity Participation Confirmation Modal -->
<div class="modal fade" id="deleteActivityParticipationModal" tabindex="-1" aria-labelledby="deleteActivityParticipationModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteActivityParticipationModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Removal</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to remove student <strong id="studentNameForRemoval"></strong> from activity <strong id="activityNameForRemoval"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteActivityParticipationForm" method="GET" action=""> 
            <button type="submit" class="btn btn-danger">Yes, Remove Student</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteModal = document.getElementById('deleteActivityParticipationModal');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var participationId = button.getAttribute('data-participation-id');
            var activityName = button.getAttribute('data-activity-name');
            var studentName = button.getAttribute('data-student-name');

            var modalStudentName = deleteModal.querySelector('#studentNameForRemoval');
            var modalActivityName = deleteModal.querySelector('#activityNameForRemoval');
            var deleteForm = deleteModal.querySelector('#deleteActivityParticipationForm');

            modalStudentName.textContent = studentName;
            modalActivityName.textContent = activityName;

            // Assuming your delete route is GET: counselor/activity/participation/delete/{id}
            deleteForm.action = '/counselor/activity/participation/delete/' + participationId;
            deleteForm.method = 'GET'; // Explicitly set to GET

            // If you change to POST/DELETE method for the route:
            // deleteForm.action = '<?php echo e(url("counselor/activity/participation")); ?>/' + participationId;
            // deleteForm.method = 'POST';
            // Make sure a hidden input for <?php echo method_field('DELETE'); ?> is present in the form in that case.
        });
    }
});
</script>

<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/activitylist.blade.php ENDPATH**/ ?>