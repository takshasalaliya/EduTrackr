@extends('counselor.layoutcounselor') {{-- Adjusted path --}}

@section('title', 'Class Attendance Summary')
@section('page_title', 'Class Attendance Summary')

@section('classattendent') {{-- Keeping this section name as requested --}}

{{-- Page-specific action buttons or info --}}
<div class="d-flex justify-content-between align-items-center mb-4">
    {{-- The H1 title is now in the layout via @yield('page_title') --}}
    <div>
        <p class="text-muted mb-0">Summary of student attendance for the selected class/period.</p>
        {{-- Add filter display here if filters are active, e.g., "For Class: BCA Sem 3 Div A (2023-2024)" --}}
    </div>
    <a href="{{ url('class_pdf') }}" class="btn btn-danger"> {{-- Use url() helper; btn-danger for PDF often used --}}
        <i class="bi bi-file-earmark-pdf-fill me-2"></i>Download PDF
    </a>
</div>

<div class="container-fluid"> {{-- Use container-fluid for full width --}}

    {{-- Session Messages --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    {{-- Placeholder for Filters: Consider adding filters for specific Class (counseled by user), Date Range --}}
    {{--
    <div class="card card-custom mb-4">
        <div class="card-body">
            <form action="{{ url('counselor/class-attendance/filter') }}" method="get" class="row g-3">
                <div class="col-md-4">
                    <label for="class_filter_summary" class="form-label">Select Class</label>
                    <select name="class_id" id="class_filter_summary" class="form-select form-select-sm">
                        <option value="">All My Classes</option>
                        {{-- Populate with counselor's classes --}}
    {{--                </select>
                </div>
                <div class="col-md-3">
                    <label for="date_from_summary" class="form-label">From Date</label>
                    <input type="date" name="date_from" id="date_from_summary" class="form-control form-control-sm" value="{{ request('date_from') }}">
                </div>
                <div class="col-md-3">
                    <label for="date_to_summary" class="form-label">To Date</label>
                    <input type="date" name="date_to" id="date_to_summary" class="form-control form-control-sm" value="{{ request('date_to') }}">
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-sm btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>
    --}}

    <div class="card card-custom">
        <div class="card-header">
            <i class="bi bi-table me-2"></i>Attendance Data
        </div>
        <div class="card-body p-0">
            @if(isset($datas) && count($datas) > 0)
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0"> {{-- Added table-striped for better readability --}}
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Enrollment Number</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">From Date</th>
                            <th scope="col">To Date</th>
                            <th scope="col" class="text-center">Total Lectures</th>
                            <th scope="col" class="text-center">Present Lectures</th>
                            <th scope="col" class="text-center">Attendance %</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($datas as $index => $data_string)
                            @php
                                // Data parsing should ideally be in the controller
                                $record = explode('&', $data_string);
                                $enrollment = $record[0] ?? 'N/A';
                                $name = $record[1] ?? 'N/A';
                                $from_date = isset($record[2]) ? \Carbon\Carbon::parse($record[2])->format('d M Y') : 'N/A';
                                $to_date = isset($record[3]) ? \Carbon\Carbon::parse($record[3])->format('d M Y') : 'N/A';
                                $total_class = $record[4] ?? 0;
                                $present = $record[5] ?? 0;
                                $percentage = $record[6] ?? 0;
                            @endphp
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $enrollment }}</td>
                                <td>{{ $name }}</td>
                                <td>{{ $from_date }}</td>
                                <td>{{ $to_date }}</td>
                                <td class="text-center">{{ $total_class }}</td>
                                <td class="text-center">{{ $present }}</td>
                                <td class="text-center fw-bold
                                    @if($percentage >= 75) text-success
                                    @elseif($percentage >= 50) text-warning
                                    @else text-danger @endif">
                                    {{ $percentage }}%
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            @else
            <div class="text-center p-4">
                <i class="bi bi-bar-chart-steps display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">No attendance summary data found.</p>
                <p class="small text-muted mt-2">This might be because no attendance has been recorded for the selected criteria or class.</p>
            </div>
            @endif
        </div>
        {{-- Pagination: If $datas is paginated by the controller, add links here --}}
        {{-- Example:
        @if(isset($datas) && $datas instanceof \Illuminate\Pagination\LengthAwarePaginator && $datas->hasPages())
        <div class="card-footer bg-light border-top-0">
            {{ $datas->appends(request()->query())->links() }}
        </div>
        @endif
        --}}
    </div>
</div>
@endsection