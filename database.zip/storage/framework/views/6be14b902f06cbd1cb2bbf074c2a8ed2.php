

<?php $__env->startSection('title', 'Student Optional Subject Mappings'); ?>
 

<?php $__env->startSection('optional_subject_list'); ?>


<div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
    <h1 class="h2 page-header-title">Student Optional Subject Assignments</h1>
    <div>
        <a href="<?php echo e(url('optionalgroup_admin')); ?>" class="btn btn-primary"> 
            <i class="bi bi-plus-circle-fill me-2"></i>Assign Optional Subjects
        </a>
    </div>
</div>

<div class="container-fluid">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card card-custom">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <i class="bi bi-card-checklist me-2"></i>Assigned Optional Subjects List
            </div>
            
            
                
        </div>
        <div class="card-body p-0">
            <?php if(isset($datas) && $datas->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Student Enrollment</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">Optional Subject Code</th>
                            <th scope="col">Optional Subject Name</th>
                            <th scope="col">Subject's Class Context</th> 
                            <th scope="col" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                            <td><?php echo e($index + 1 + ($datas instanceof \Illuminate\Pagination\LengthAwarePaginator ? ($datas->currentPage() - 1) * $datas->perPage() : 0)); ?></td>
                            <td><?php echo e($assignment->student->enrollment_number ?? 'N/A'); ?></td>
                            <td><?php echo e($assignment->student->name ?? 'N/A'); ?></td>
                            <td><?php echo e($assignment->subject->subject_code ?? 'N/A'); ?></td>
                            <td><?php echo e($assignment->subject->subject_name ?? 'N/A'); ?></td>
                            <td>
                                <?php if($assignment->subject->student_class): ?> 
                                <?php echo e($assignment->subject->student_class->program->name ?? 'N/A Program'); ?> /
                                Sem <?php echo e($assignment->subject->student_class->sem ?? 'N/A'); ?> /
                                Div <?php echo e($assignment->subject->student_class->devision ?? 'N/A'); ?>

                                <?php else: ?>
                                General Subject (No specific class context)
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Assignment"
                                        data-bs-toggle="modal" data-bs-target="#deleteOptionalAssignmentModal"
                                        data-assignment-id="<?php echo e($assignment->id); ?>"
                                        data-assignment-info="Subject: <?php echo e($assignment->subject->subject_name ?? 'N/A'); ?> for Student: <?php echo e($assignment->student->name ?? 'N/A'); ?>">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-ui-checks display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">No optional subject assignments found.</p>
                <p class="small text-muted mt-2">You can <a href="<?php echo e(url('optionalgroup_admin')); ?>">assign optional subjects to students</a> to populate this list.</p>
            </div>
            <?php endif; ?>
        </div>
        <?php if(isset($datas) && $datas instanceof \Illuminate\Pagination\LengthAwarePaginator && $datas->hasPages()): ?>
        <div class="card-footer bg-light border-top-0">
            <?php echo e($datas->appends(request()->query())->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Optional Assignment Confirmation Modal -->
<div class="modal fade" id="deleteOptionalAssignmentModal" tabindex="-1" aria-labelledby="deleteOptionalAssignmentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteOptionalAssignmentModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this optional subject assignment: <br><strong id="optionalAssignmentInfoToDelete"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteOptionalAssignmentForm" method="get" action=""> 
            
            <button type="submit" class="btn btn-danger">Yes, Delete Assignment</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteModal = document.getElementById('deleteOptionalAssignmentModal');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var assignmentId = button.getAttribute('data-assignment-id');
            var assignmentInfo = button.getAttribute('data-assignment-info');

            var modalBodyStrong = deleteModal.querySelector('#optionalAssignmentInfoToDelete');
            var deleteForm = deleteModal.querySelector('#deleteOptionalAssignmentForm');

            modalBodyStrong.innerHTML = assignmentInfo; // Use innerHTML if info contains line breaks

            // For your current GET route: '<?php echo e(url("delete_optional_admin")); ?>/' + assignmentId;
            // For RESTful DELETE (recommended): '<?php echo e(url("/admin/optional-subject-assignments")); ?>/' + assignmentId;
            deleteForm.action = 'delete_optional_admin/' + assignmentId; // Using your current GET route

            // If using GET, remove method spoofing and set form method to GET
            const methodInput = deleteForm.querySelector('input[name="_method"]');
            if (methodInput) {
                methodInput.remove();
            }
            deleteForm.method = 'GET';
        });
    }
});
</script>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/admin/optional_subject_list.blade.php ENDPATH**/ ?>