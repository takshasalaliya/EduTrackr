
<?php $__env->startSection('title','Add Student'); ?>
<?php $__env->startSection('add_form'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>.gradient-custom {
/* fallback for old browsers */
background: #ffffff;

/* Chrome 10-25, Safari 5.1-6 */
background: #ffffff;

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: #ffffff;
}

.card-registration .select-input.form-control[readonly]:not([disabled]) {
font-size: 1rem;
line-height: 2.15;
padding-left: .75em;
padding-right: .75em;
}
.card-registration .select-arrow {
top: 13px;
}</style>
</head>
<body>


<section class="vh-100 gradient-custom">
  <div >
    <div >
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Add Student</h3>
            <?php if(session('success')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
              <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                <use xlink:href="#check-circle-fill"/>
              </svg>
              <div>
                <?php echo e(session('success')); ?>

              </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
  <div>
    <?php echo e(session('error')); ?>

  </div>

</div>
<?php endif; ?>

            
<form action="student_data" method="GET">
                                <?php echo csrf_field(); ?>
                                <label for="program">Program</label>
                                <select name="program" id="program" onchange="this.form.submit(); Functionreset();">
                                    <option value="">Select Program</option>
                                    <option value="ITM" <?php echo e(request('program') == 'ITM' ? 'selected' : ''); ?>>ITM</option>
                                    <option value="BBA" <?php echo e(request('program') == 'BBA' ? 'selected' : ''); ?>>BBA</option>
                                    <option value="BCOM" <?php echo e(request('program') == 'BCOM' ? 'selected' : ''); ?>>BCOM</option>
                                    <option value="BCA" <?php echo e(request('program') == 'BCA' ? 'selected' : ''); ?>>BCA</option>
                                    <option value="MCOM" <?php echo e(request('program') == 'MCOM' ? 'selected' : ''); ?>>MCOM</option>
                                </select>

                                <label for="sem">Semester</label>
                                <select name="sem" id="sem" onchange="this.form.submit()">
                                    <?php if(isset($sem)): ?>
                                    <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="">Select Semester</option>
                                    <option value="<?php echo e($semester->sem); ?>" <?php echo e(request('sem') == $semester->sem ? 'selected' : ''); ?>>
                                        Semester <?php echo e($semester->sem); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <label for="year">Year</label>
                          
                                <select name="year" id="year" onchange="this.form.submit()">
                                <option value="">Select Year</option>
                                    <?php if(isset($year)): ?>
                                    <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semyear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($semyear->year); ?>" <?php echo e(request('year') == $semyear->year ? 'selected' : ''); ?>>
                                         <?php echo e($semyear->year); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php if(isset($devision)): ?>
                                <label for="devision">Division</label>
                                  <select name="devision" id="devision" onchange="this.form.submit()">
                                      <option value="">Select Division</option>
                                      <?php $__currentLoopData = $devision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($div->devision); ?>" <?php echo e(request('devision')==$div->devision?'selected':''); ?>>
                                              <?php echo e($div->devision); ?>

                                          </option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                  <?php endif; ?>
                                  
                                  
                                  
                                 
                                  <?php if(isset($form)): ?>
                                  <div class="row">
                <div class="col-md-6 mb-4">

                  <div data-mdb-input-init class="form-outline">
                  <label class="form-label" for="name">Full Name</label>
                  <input type="text" id="name" class="form-control form-control-lg" name="name"/>
                    <span class="alert"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
                <div class="col-md-6 mb-4">

                  <div data-mdb-input-init class="form-outline">
                  <label class="form-label" for="rollnumber">Roll Number</label>
                    <input type="text" id="rollnumber" class="form-control form-control-lg" name="rollnumber" " />
                    <span class="alert"><?php $__errorArgs = ['rollnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center">

                  <div data-mdb-input-init class="form-outline datepicker w-100">
                  <label for="s_phone" class="form-label">Student Phone Number</label>
                  <input type="tel" class="form-control form-control-lg" id="s_phone" name="s_phone"  />
                    <span class="alert"><?php $__errorArgs = ['s_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
                <div class="col-md-6 mb-4 pb-2">

                  <div data-mdb-input-init class="form-outline">
                  <label class="form-label" for="s_email">Student Email ID</label>
                    <input type="email" id="s_email" class="form-control form-control-lg" name="s_email" />
                    <span class="alert"><?php $__errorArgs = ['s_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
              </div>

              <div class="row">
                
                <div class="col-md-6 mb-4 pb-2">

                  <div data-mdb-input-init class="form-outline">
                  <label for="p_phone" class="form-label">Parent Phone Number</label>
                    <input type="tel" class="form-control form-control-lg" id="p_phone" name="p_phone" />
                    <span class="alert"><?php $__errorArgs = ['p_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>

                <div class="col-md-6 mb-4 pb-2">

                  <div data-mdb-input-init class="form-outline">
                  <label for="p_email" class="form-label">Parent Email ID</label>
                    <input type="email" class="form-control form-control-lg" id="p_email" name="p_email"  />
                    <span class="alert"><?php $__errorArgs = ['p_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e("⚠️".$message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                  </div>

                </div>
                
                    </div>
              
              <div class="row">
              <div class="col-md-6 mb-4 pb-2">
                    
                    
              <label for="teacher">Teacher</label>
                                  <select name="teacher" id="teacher" onchange="this.form.submit()">>
                                    
                                      <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($teacher->id); ?>" name="teacher">
                                              <?php echo e($teacher->name); ?>

                                          </option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                    
                  </div>
                  
              </div>
              <div class="mt-4 pt-2">
              <input type="submit" name="submit" value="submit">
              </div>
              
                    <?php endif; ?>
              

            </form>


            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->
<script>
  function Functionreset() {
    // Reset all dropdowns
    document.getElementById('sem').selectedIndex = 0;
    document.getElementById('year').selectedIndex = 0;
    document.getElementById('devision').selectedIndex = 0;

    const teacher = document.getElementById('teacher');
    if (teacher) teacher.selectedIndex = 0;

    // Hide dependent fields
    const semDropdown = document.getElementById('sem');
    const yearDropdown = document.getElementById('year');
    const divisionDropdown = document.getElementById('devision');
    const teacherDropdown = document.getElementById('teacher');
    const formFields = document.querySelectorAll('.form-outline');

    if (semDropdown) semDropdown.parentElement.style.display = 'none';
    if (yearDropdown) yearDropdown.parentElement.style.display = 'none';
    if (divisionDropdown) divisionDropdown.parentElement.style.display = 'none';
    if (teacherDropdown) teacherDropdown.parentElement.style.display = 'none';

    formFields.forEach(field => {
      field.style.display = 'none';
    });
  }

  // Show fields when a selection is made
  document.getElementById('program').addEventListener('change', function () {
    // Unhide the semester dropdown when a program is selected
    const semDropdown = document.getElementById('sem');
    if (this.value) {
      semDropdown.parentElement.style.display = 'block';
    } else {
      Functionreset();
    }
  });

  document.getElementById('sem').addEventListener('change', function () {
    const yearDropdown = document.getElementById('year');
    if (this.value) {
      yearDropdown.parentElement.style.display = 'block';
    } else {
      yearDropdown.parentElement.style.display = 'none';
    }
  });

  document.getElementById('year').addEventListener('change', function () {
    const divisionDropdown = document.getElementById('devision');
    if (this.value) {
      divisionDropdown.parentElement.style.display = 'block';
    } else {
      divisionDropdown.parentElement.style.display = 'none';
    }
  });

  document.getElementById('devision').addEventListener('change', function () {
    const teacherDropdown = document.getElementById('teacher');
    if (this.value) {
      teacherDropdown.parentElement.style.display = 'block';
    } else {
      teacherDropdown.parentElement.style.display = 'none';
    }
  });

  document.getElementById('teacher').addEventListener('change', function () {
    const formFields = document.querySelectorAll('.form-outline');
    if (this.value) {
      formFields.forEach(field => {
        field.style.display = 'block';
      });
    } else {
      formFields.forEach(field => {
        field.style.display = 'none';
      });
    }
  });
</script>


</body>
<body>


<section class="vh-100 gradient-custom">
  <div style="margin-top:20%">
    <div >
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Add Student</h3>
            <?php if(session('success')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
              <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:">
                <use xlink:href="#check-circle-fill"/>
              </svg>
              <div>
                <?php echo e(session('success')); ?>

              </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-success d-flex align-items-center" role="alert">
  <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
  <div>
    <?php echo e(session('error')); ?>

  </div>

</div>
<?php endif; ?>

<form action="add_student_excel" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>

              <label for="excel">Excel</label>
              <input type="file" name="excel_file" id="excel">
              <input type="submit">
            </form>


            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\OneDrive\Desktop\laravel project\main\resources\views//add_student.blade.php ENDPATH**/ ?>