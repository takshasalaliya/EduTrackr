<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Connection Error</title>
</head>
<body>
    <h2>Database Connection Error</h2>
    <p>We're experiencing issues connecting to our database. Please try again later.</p>
</body>
</html>
