 

<?php $__env->startSection('title', 'My Students List'); ?>
<?php $__env->startSection('page_title', 'My Students List'); ?>

<?php $__env->startSection('student_table'); ?> 


<div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
        <p class="text-muted mb-0">Showing students from classes you counsel.</p>
    </div>
    <a href="<?php echo e(url('add_student')); ?>" class="btn btn-primary"> 
        <i class="bi bi-person-plus-fill me-2"></i>Add New Student(s)
    </a>
</div>

<div class="container-fluid"> 

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card card-custom">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <i class="bi bi-people-fill me-2"></i>Students You Counsel
            </div>
            <div class="ms-auto" style="max-width: 400px;">
                <div class="input-group input-group-sm">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="searchInput" class="form-control" placeholder="Search by Name or Enrollment No...">
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <?php
                $counselorStudents = [];
                if(isset($students) && isset(Auth::user()->id)) {
                    foreach($students as $student) {
                        if(isset($student->class) && $student->class->coundelor_id == Auth::user()->id) { // Typo 'coundelor_id' kept
                            $counselorStudents[] = $student;
                        }
                    }
                }
            ?>

            <?php if(count($counselorStudents) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0" id="studentTable">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Enroll. No.</th>
                            <th scope="col">Student Phone</th>
                            <th scope="col">Student Email</th>
                            <th scope="col">Parent Phone</th>
                            <th scope="col">Parent Email</th>
                            <th scope="col">Class Details</th>
                            <th scope="col">Last Updated</th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $counselorStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->enrollment_number); ?></td>
                            <td><?php echo e($student->phone_number ?? 'N/A'); ?></td>
                            <td><?php echo e($student->email ?? 'N/A'); ?></td>
                            <td><?php echo e($student->parents_phone_number ?? 'N/A'); ?></td>
                            <td><?php echo e($student->parents_email ?? 'N/A'); ?></td>
                            <td>
                                <?php if($student->class && $student->class->program): ?>
                                    <?php echo e($student->class->program->name); ?> /
                                    Batch: <?php echo e($student->class->year ?? 'N/A'); ?> /
                                    Sem: <?php echo e($student->class->sem ?? 'N/A'); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($student->updated_at ? $student->updated_at->format('d M Y, h:i A') : 'N/A'); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(url('/edit_student/'.$student->student_id)); ?>" class="btn btn-sm btn-outline-warning me-1" title="Edit Student">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-outline-danger" title="Delete Student"
                                        data-bs-toggle="modal" data-bs-target="#deleteStudentModal"
                                        data-student-id="<?php echo e($student->student_id); ?>" data-student-name="<?php echo e($student->name); ?>">
                                    <i class="bi bi-trash3-fill"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center p-4">
                <i class="bi bi-emoji-frown display-4 text-muted mb-3"></i>
                <p class="text-muted mb-0">No students found in the classes you counsel.</p>
                <p class="small text-muted mt-2">If you have been assigned new classes, the student list might update shortly or after adding students to those classes.</p>
            </div>
            <?php endif; ?>
        </div>
        
        
            
        
    </div>
</div>

<!-- Delete Student Confirmation Modal -->
<div class="modal fade" id="deleteStudentModal" tabindex="-1" aria-labelledby="deleteStudentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteStudentModalLabel"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Confirm Deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete the student: <strong id="studentNameToDeleteInModal"></strong>?
        <p class="text-danger small mt-2">This action cannot be undone and will remove all associated records for this student.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="deleteStudentForm" method="get" action=""> 
            
            <button type="submit" class="btn btn-danger">Yes, Delete Student</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    // Client-side search
    const searchInput = document.getElementById('searchInput');
    const studentTable = document.getElementById('studentTable');
    const tableRows = studentTable ? studentTable.querySelectorAll('tbody tr') : [];

    if (searchInput) {
        searchInput.addEventListener('keyup', function () {
            const filter = this.value.toLowerCase().trim();
            let found = false;
            tableRows.forEach(function (row) {
                const name = row.cells[1].textContent.toLowerCase(); // Name is in index 1 after adding '#'
                const enrollment = row.cells[2].textContent.toLowerCase(); // Enrollment No. is in index 2

                if (name.includes(filter) || enrollment.includes(filter)) {
                    row.style.display = '';
                    found = true;
                } else {
                    row.style.display = 'none';
                }
            });

            // Optional: Show a "no results from search" message if needed
            // This part would require an extra element in the HTML to toggle display
        });
    }

    // Delete Modal
    var deleteStudentModal = document.getElementById('deleteStudentModal');
    if (deleteStudentModal) {
        deleteStudentModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var studentId = button.getAttribute('data-student-id');
            var studentName = button.getAttribute('data-student-name');

            var modalBodyStrong = deleteStudentModal.querySelector('#studentNameToDeleteInModal');
            var deleteForm = deleteStudentModal.querySelector('#deleteStudentForm');

            modalBodyStrong.textContent = studentName;

            // For your current GET route: '<?php echo e(url("delete_student")); ?>/' + studentId;
            // For RESTful DELETE (recommended): '<?php echo e(url("/counselor/students")); ?>/' + studentId;
            deleteForm.action = 'delete_student/' + studentId; // Using your current GET route

            // If using GET, remove method spoofing and set form method to GET
            const methodInput = deleteForm.querySelector('input[name="_method"]');
            if (methodInput) {
                methodInput.remove();
            }
            deleteForm.method = 'GET';
        });
    }
});
</script>

<?php echo $__env->make('counselor.layoutcounselor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/student_list.blade.php ENDPATH**/ ?>