<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    @page {
        size: A4;
        margin: 20mm;
    }
    body {
        font-family: Arial, sans-serif;
        font-size: 12px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 5px;
        text-align: center;
        border: 1px solid #ccc;
    }
    .page-break {
        page-break-before: always;
    }
</style>

</head>
<body>
    <?php
$number=1;
$image=public_path('image/3-removebg-preview.png');
    ?>
   
<img src="<?php echo e('data:image/png;base64,'.base64_encode(file_get_contents($image))); ?>" alt="semcom" style="width:100%;">

    <table class="table table-bordered">
        <tr>
            <th>Class & Semester:</th>
            <td><?php echo e($class); ?></td>
        </tr>
        <tr>
            <th>Class Counselor:</th>
            <td><?php echo e($teacher); ?></td>
        </tr>
        <tr>
            <th>Subject:</th>
            <td><?php echo e($subject); ?></td>
        </tr>
            <th>Class Strength:</th>
            <td><?php echo e($count); ?></td>
        </tr>
    </table>
        <table class="table table-bordered">
            <thead class="text-center">
                <tr>
                    <th>Sr. No.</th>
                    <th>Enrollment Number</th>
                    <th>Name</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Total Classes</th>
                    <th>Present</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $valid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php
                        $sum = 0;
                        $present = 0;
                        $date = [];
                        foreach ($student as $d) {
                            if ($d->student->enrollment_number == $data && $d->staff_id == $id) {
                                $date[] = $d->created_at;
                                $sum++;
                                $name = $d->student->name;
                                
                                if ($d->attendance == 'present') {
                                    $present++;
                                }
                            }
                        }
                        
                        sort($date);
                        $from = $date[0];
                        $from=explode(" ",$from);
                        $to = end($date);
                        $to=explode(" ",$to);
                        $percentage = number_format(($present / $sum) * 100, 2);
                    ?>
                    <td class="text-center"><?php echo e($number++); ?></td>
                    <td class="text-center"><?php echo e($data); ?></td>
                    <td class="text-center"><?php echo e($name); ?></td>
                    <td class="text-center"><?php echo e($from[0]); ?></td>
                    <td class="text-center"><?php echo e($to[0]); ?></td>
                    <td class="text-center"><?php echo e($sum); ?></td>
                    <td class="text-center"><?php echo e($present); ?></td>
                    <td class="text-center"><?php echo e($percentage); ?>%</td>
                </tr>
              
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\TAKSH\Music\laravel project\final semcom\resources\views/counselor/pdf_attendent.blade.php ENDPATH**/ ?>