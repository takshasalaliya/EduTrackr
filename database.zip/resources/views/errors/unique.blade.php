<h2>Duplicate Entry</h2>
<p>The data you entered already exists. Please enter unique data.</p>
